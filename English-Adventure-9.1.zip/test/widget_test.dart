import 'package:english_adventure/core/audio/speech_service.dart';
import 'package:english_adventure/core/letter_strokes.dart';
import 'package:english_adventure/core/storage/progress_store.dart';
import 'package:english_adventure/data/models/level.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('level json parses into typed steps', () {
    final level = Level.fromJson({
      'id': 'isle_test',
      'index': 1,
      'world': 'Letter Village',
      'worldIndex': 1,
      'title': 'Test Island',
      'subtitle': 'Meet s',
      'emoji': '🌞',
      'color': '#FFB703',
      'reward': {'id': 'shell', 'name': 'Shell', 'emoji': '🐚'},
      'steps': [
        {
          'type': 'letterIntro',
          'letter': 's',
          'sound': 'sss',
          'exampleWord': 'sun',
          'exampleEmoji': '🌞',
          'say': 'This is s.',
        },
        {
          'type': 'spell',
          'word': 'sat',
          'emoji': '🪑',
          'distractors': ['p'],
        },
        {
          'type': 'story',
          'emoji': '🐱',
          'sentences': ['The cat sat.'],
          'question': 'Who sat?',
          'options': ['cat', 'dog'],
          'answer': 'cat',
        },
      ],
    });

    expect(level.steps.length, 3);
    expect(level.world, 'Letter Village');
    expect(level.steps.first, isA<LetterIntroStep>());
    expect((level.steps[1] as SpellStep).letters, ['s', 'a', 't']);
    expect(level.steps[2], isA<StoryStep>());
    expect(level.maxStars, 3);
  });

  test('progress keeps the best star result', () {
    var state = const ProgressState(starsByLevel: {'isle_s': 4});
    state = state.copyWith(starsByLevel: {...state.starsByLevel, 'isle_a': 3});

    expect(state.totalStars, 7);
    expect(state.isFinished('isle_s'), isTrue);
    expect(state.isFinished('isle_t'), isFalse);
  });

  test('progress survives a json round trip', () {
    const original = ProgressState(
      starsByLevel: {'isle_s': 4},
      collectibles: {'sun_shell'},
      letterCounts: {'s': 3},
    );
    final restored = ProgressState.fromJson(original.toJson());

    expect(restored.totalStars, 4);
    expect(restored.collectibles, contains('sun_shell'));
    expect(restored.letterCounts['s'], 3);
  });

  test('growth measures are recorded on the state', () {
    final state = ProgressState(
      wordsRead: 448,
      passagesRead: 24,
      readingChecks: [ReadingCheck(date: DateTime(2026, 3, 1), wcpm: 46)],
    );
    expect(state.wordsRead, 448);
    expect(state.passagesRead, 24);
    expect(state.latestCheck?.wcpm, 46);
    expect(state.wcpmHistory, [46]);
    expect(const ProgressState().latestCheck, isNull);
  });

  test('reading steps split into sentences and fill in the name', () {
    const step = ReadingStep(
      title: 'Test',
      emoji: '📖',
      text: 'Sam sat. Sam is glad! Is he?',
    );
    expect(step.sentences.length, 3);
    expect(step.sentences.first, 'Sam sat.');
    expect(step.wordCount, 7);
  });

  test('trace support levels parse and default to guided', () {
    expect(TraceSupport.fromJson('memory'), TraceSupport.memory);
    expect(TraceSupport.fromJson('dots'), TraceSupport.dots);
    expect(TraceSupport.fromJson(null), TraceSupport.guided);
    expect(TraceSupport.fromJson('nonsense'), TraceSupport.guided);
  });

  test('voice clip names are derived from the line itself', () {
    // The filename is how a pre-generated clip is found, so this has to be
    // stable: change it and every recording stops being picked up.
    expect(SpeechService.slugFor('You did it!'), 'you-did-it');
    expect(SpeechService.slugFor('Nearly! Try another one.'),
        'nearly-try-another-one');
  });

  test('letters are spoken as sounds, not letter names', () {
    // The whole point: a phonics app must say "mmm", never "em".
    expect(SpeechService.spellingFor('m'), 'mmm');
    expect(SpeechService.spellingFor('s'), 'sss');
    expect(SpeechService.spellingFor('qu'), 'kwuh');
    expect(SpeechService.spellingFor('sh'), 'shhh');
    // Unknown graphemes fall back rather than throwing.
    expect(SpeechService.spellingFor('zzz'), 'zzz');
  });

  test('s is a single continuous stroke, not two bowls', () {
    // Built from two arcs it came out as a squashed 8 with no middle
    // diagonal, which is how it looked on a real device.
    expect(strokesFor('s').length, 1);
    expect(strokesFor('S', capital: true).length, 1);

    // And the stroke actually travels: right at the top, left at the bottom.
    final points = strokesFor('s').first;
    expect(points.first.dx, greaterThan(points.last.dx));
    expect(points.first.dy, lessThan(points.last.dy));
  });

  test('capitals are taught and traceable', () {
    // Every sentence starts with one, so the app must teach them.
    for (final letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')) {
      expect(capitalStrokes.containsKey(letter), isTrue, reason: letter);
      expect(strokesFor(letter, capital: true).isNotEmpty, isTrue,
          reason: letter);
    }
    // Upper and lower are genuinely different shapes.
    expect(strokesFor('a'), isNot(strokesFor('a', capital: true)));
  });

  test('trace targets cover both cases and a name', () {
    const pair = TraceStep(
      letter: 'm',
      say: '',
      letterCase: TraceCase.both,
    );
    expect(pair.targets(''), [('m', false), ('m', true)]);

    const name = TraceStep(letter: 's', say: '', word: '{name}');
    expect(name.targets('Aarav'),
        [('A', true), ('a', false), ('r', false), ('a', false), ('v', false)]);
    // No name set: falls back rather than writing nothing.
    expect(name.targets('').length, 1);
  });

  test('every letter of the alphabet has traceable strokes', () {
    for (final letter in 'abcdefghijklmnopqrstuvwxyz'.split('')) {
      expect(letterStrokes.containsKey(letter), isTrue, reason: letter);
      expect(strokesFor(letter).isNotEmpty, isTrue, reason: letter);
    }
  });

  test('parent pin hashing is stable and not reversible', () {
    final hash = ProgressController.hashPin('1234');
    expect(hash, ProgressController.hashPin('1234'));
    expect(hash, isNot(ProgressController.hashPin('1235')));
    expect(hash.contains('1234'), isFalse);
  });

  test('placement opens worlds up to the chosen start', () {
    const state = ProgressState(startWorld: 2);
    expect(state.needsSetup, isFalse);
    expect(const ProgressState().needsSetup, isTrue);
  });

  test('a grown-up can open every island for free choice', () {
    const locked = ProgressState();
    const open = ProgressState(openAllIslands: true);
    expect(locked.openAllIslands, isFalse);
    expect(open.openAllIslands, isTrue);
    // Free choice must not hand over the paid worlds.
    expect(open.isWorldPaid(3), isTrue);
  });

  test('worlds 1 and 2 are free, the rest need the unlock', () {
    const locked = ProgressState();
    expect(locked.isWorldPaid(1), isFalse);
    expect(locked.isWorldPaid(2), isFalse);
    expect(locked.isWorldPaid(3), isTrue);
    expect(locked.isWorldPaid(6), isTrue);

    const unlocked = ProgressState(unlockedFullVersion: true);
    expect(unlocked.isWorldPaid(6), isFalse);
  });

  test('settings survive a reset of play progress', () {
    const before = ProgressState(
      starsByLevel: {'l01_s': 4},
      childName: 'Test',
      voiceRate: 0.5,
      unlockedFullVersion: true,
    );
    final after = ProgressState(
      soundOn: before.soundOn,
      startWorld: before.startWorld,
      pinHash: before.pinHash,
      childName: before.childName,
      voiceRate: before.voiceRate,
      dailyGoalMinutes: before.dailyGoalMinutes,
      unlockedFullVersion: before.unlockedFullVersion,
    );
    expect(after.totalStars, 0);
    expect(after.childName, 'Test');
    expect(after.unlockedFullVersion, isTrue);
  });
}
