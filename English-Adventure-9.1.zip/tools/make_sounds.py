#!/usr/bin/env python3
"""Regenerates the star and completion sounds in assets/audio/.

Pure standard library: no samples to license, nothing to download, and the
whole set is under 130 KB. Run from the project root:

    python3 tools/make_sounds.py
"""

import math
import struct
import wave

RATE = 22050


def tone(freq, dur, amp=0.5, decay=6.0, harmonics=(1.0, 0.35, 0.18)):
    """A soft bell-ish tone: fundamental plus two quiet harmonics."""
    out = []
    for i in range(int(RATE * dur)):
        t = i / RATE
        env = math.exp(-decay * t)
        if t < 0.005:            # gentle attack, so it never clicks
            env *= t / 0.005
        value = sum(
            h * math.sin(2 * math.pi * freq * (k + 1) * t)
            for k, h in enumerate(harmonics)
        )
        out.append(amp * env * value / sum(harmonics))
    return out


def mix(*layers):
    out = [0.0] * max(len(layer) for layer in layers)
    for layer in layers:
        for i, value in enumerate(layer):
            out[i] += value
    peak = max(abs(v) for v in out) or 1.0
    return [v / peak * 0.85 for v in out]


def delay(samples, seconds):
    return [0.0] * int(RATE * seconds) + samples


def write(path, samples):
    with wave.open(path, "w") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(RATE)
        handle.writeframes(b"".join(
            struct.pack("<h", int(max(-1.0, min(1.0, s)) * 32000))
            for s in samples
        ))
    print(f"wrote {path}")


if __name__ == "__main__":
    # A star is awarded: rising three-note sparkle (C6 E6 G6).
    write("assets/audio/star_award.wav", mix(
        tone(1046.5, 0.55),
        delay(tone(1318.5, 0.55), 0.09),
        delay(tone(1568.0, 0.75), 0.18),
    ))

    # The child touches the star: one bright glassy ping.
    write("assets/audio/star_touch.wav", mix(
        tone(1760.0, 0.45, decay=9.0),
        delay(tone(2637.0, 0.35, amp=0.3, decay=11.0), 0.02),
    ))

    # Island finished: a fuller four-note flourish.
    write("assets/audio/island_complete.wav", mix(
        tone(523.3, 0.5),
        delay(tone(659.3, 0.5), 0.12),
        delay(tone(784.0, 0.5), 0.24),
        delay(tone(1046.5, 1.1, decay=4.0), 0.36),
    ))
