#!/usr/bin/env python3
"""Builds Stage 2 (islands 31-60): the letter pairs, then blending.

Islands 31-40 teach new code — sh, ch, th, ng, ck and the doubles. From 41
nothing new is taught: the child learns to blend consonants they already
know (st, cr, mp), which is a skill rather than a spelling.

Every passage below is hand-written and then machine-checked against the
code taught at or before its island.

    python3 tools/generate_stage2.py     # writes into assets/content/
    python3 tools/phonics.py assets/content/levels.json
"""

from __future__ import annotations

import json
import sys

from phonics import STAGE_2_ISLANDS, is_readable

# --------------------------------------------------------------------------
# Word bank. Every picture checked against its word by hand: a wrong picture
# teaches a wrong word, because for a pre-reader the picture IS the meaning.
# --------------------------------------------------------------------------
WORD_BANK = {
    # two syllables, both halves decodable: the first step towards longer
    # words in stage 5
    "chicken": "🐔", "sunset": "🌅", "picnic": "🧺", "rocket": "🚀",
    "pocket": "👖", "ticket": "🎫", "muffin": "🧁", "kitten": "🐈",
    "rabbit": "🐇", "napkin": "🧻",

    # sh
    "ship": "🚢", "shop": "🏪", "shed": "🛖", "fish": "🐟", "shell": "🐚",
    "shut": "🚪", "dish": "🍽️",
    # ch
    "chip": "🍟", "chin": "😬", "chop": "🔪", "chest": "🧰", "ched": None,
    "much": "➕", "rich": "💰", "chick": "🐤",
    # th
    "thin": "📏", "this": "👉", "that": "👈", "them": "👥", "moth": "🦋",
    "bath": "🛁", "path": "🛤️", "with": "🤝",
    # ng
    "ring": "💍", "king": "👑", "sing": "🎤", "wing": "🪽", "song": "🎵",
    "long": "📏", "bang": "💥",
    # ck
    "duck": "🦆", "sock": "🧦", "rock": "🪨", "lock": "🔒", "kick": "🦵",
    "clock": "🕐", "truck": "🚚", "black": "⬛", "stick": "🪵",
    # doubles
    "bell": "🔔", "doll": "🪆", "hill": "⛰️", "ball": "⚽", "well": "🪣",
    "puff": "💨", "cliff": "🧗", "off": "🔕", "grass": "🌿", "dress": "👗",
    "kiss": "💋", "buzz": "🐝", "fizz": "🥤", "jazz": "🎷",
    # blends
    "stop": "🛑", "step": "🪜", "star": "⭐", "stamp": "📮", "nest": "🪺",
    "spin": "🌀", "spot": "🔴", "spoon": None, "wasp": "🐝",
    "snap": "📸", "snack": "🍎", "skip": "🤸", "mask": "😷", "desk": "🪑",
    "clap": "👏", "clip": "📎", "crab": "🦀", "crack": "🥚", "cross": "✝️",
    "flag": "🚩", "flat": "🏢", "frog": "🐸", "fresh": "🥬",
    "grab": "🤲", "grin": "😁", "glad": "😊", "glass": "🥛",
    "trap": "🪤", "truck2": None, "drum": "🥁", "drop": "💧", "dress2": None,
    "brick": "🧱", "brush": "🪥", "bring": "🎁", "block": "🧊",
    "plan": "📋", "plum": "🍑", "plus": "➕", "press": "👇",
    "hand": "✋", "band": "🎸", "sand": "🏖️", "pond": "🦆", "wind": "🌬️",
    "tent": "⛺", "ant": "🐜", "plant": "🪴", "print": "🖨️",
    "jump": "🦘", "lamp": "💡", "camp": "🏕️", "stamp2": None,
    "belt": "🩹", "melt": "🫠", "milk": "🥛", "help": "🆘",
    "soft": "🧸", "gift": "🎁", "lift": "🛗", "left": "⬅️",
    "best": "🥇", "fast": "🏃", "last": "🏁", "list": "📝", "must": "❗",
}
WORD_BANK = {word: emoji for word, emoji in WORD_BANK.items() if emoji}

# --------------------------------------------------------------------------
# What each island teaches, and how it is spoken.
# --------------------------------------------------------------------------
NEW_CODE = {
    "sh": ("shh", "ship", "🚢", "Put a finger on your lips: shhh."),
    "ch": ("ch", "chips", "🍟", "Like a little train: ch ch ch."),
    "th": ("th", "thumb", "👍", "Poke your tongue out and blow gently."),
    "ng": ("ng", "ring", "💍", "It hums at the back, like the end of ring."),
    "ck": ("k", "duck", "🦆", "Two letters, one sound: k. It hides at the end."),
    "ff": ("fff", "cliff", "🧗", "Two f's, still just fff."),
    "ll": ("lll", "bell", "🔔", "Two l's, still just lll."),
    "ss": ("sss", "grass", "🌿", "Two s's, still just sss."),
    "zz": ("zzz", "buzz", "🐝", "Two z's, still just zzz."),
}

# Blend islands: no new code, a new skill. (title, focus, words to build)
BLENDS = {
    41: ("Stepping Stones", "st", ["stop", "step", "nest", "best"]),
    42: ("Spinning Bay", "sp", ["spin", "spot", "wasp"]),
    43: ("Snack Cove", "sn and sk", ["snap", "skip", "mask", "desk"]),
    44: ("Crab Rocks", "cl and cr", ["clap", "clip", "crab", "crack"]),
    46: ("Frog Pond", "fl and fr", ["flag", "flat", "frog", "fresh"]),
    47: ("Glad Grove", "gr and gl", ["grab", "grin", "glad", "glass"]),
    48: ("Drum Point", "tr and dr", ["trap", "drum", "drop"]),
    49: ("Brick Beach", "br and bl", ["brick", "brush", "bring", "block"]),
    51: ("Plum Hill", "pl and pr", ["plan", "plum", "plus", "press"]),
    52: ("Sand Bank", "-nd and -nt", ["hand", "sand", "pond", "tent", "ant"]),
    53: ("Camp Ridge", "-mp", ["jump", "lamp", "camp", "stamp"]),
    54: ("Milk Bay", "-lt and -lk", ["belt", "melt", "milk", "help"]),
    55: ("Gift Shore", "-ft and -st", ["soft", "gift", "lift", "fast"]),
    56: ("Mask Reef", "-sk and -sp", ["mask", "desk", "wasp"]),
    57: ("Three Sounds", "three sounds together", ["stamp", "print", "plant"]),
    59: ("Long Words", "longer words", ["chicken", "sunset", "picnic"]),
}

# --------------------------------------------------------------------------
# Passages, hand-written. Key = island index.
# --------------------------------------------------------------------------
PASSAGES = {
    31: ("The Shop", "🏪",
         "I shop and get a fish. The fish is in a dish. "
         "I run to the shed and shut it in.", ("fish", "shop", "fish")),
    32: ("Chips", "🍟",
         "Chad has chips. The chips are hot. "
         "Chad has a chip and I have a chip. Much fun!", ("chips", "fish", "chips")),
    33: ("The Moth", "🦋",
         "This is a moth. That is a thin moth. "
         "The moths sit on the path. I am thin, said the moth.",
         ("moth", "fish", "moth")),
    34: ("The King Sang", "👑",
         "The king had a ring. The king can sing! "
         "He sang a long song and the men sang with him.",
         ("king", "chip", "king")),
    35: ("Fish and Chips", "🐟",
         "Chad and Meg run to the shop. Chad gets fish and chips. "
         "Meg gets a bun. They sit and munch on the path.",
         ("chips", "moths", "chips")),
    36: ("The Duck", "🦆",
         "A duck sat on a rock. Tick tock, said the clock. "
         "The duck got up and ran back to the pond?",
         ("duck", "chick", "duck")),
    37: ("Off the Cliff", "🧗",
         "The wind can huff and puff. It huffs off the cliff. "
         "My hat is off! It is stuck in a bush.", ("wind", "duck", "wind")),
    38: ("The Bell", "🔔",
         "A bell is on the hill. Bill can ring the bell. "
         "Ding! The bell rings and all the ducks run off.",
         ("bell", "doll", "bell")),
    39: ("In the Grass", "🌿",
         "A bug sits in the grass. The grass is long and thick. "
         "The bug is glad. The grass is a soft bed!",
         ("grass", "rocks", "grass")),
    40: ("Buzz and Fizz", "🐝",
         "A bug can buzz. Buzz, buzz! It sits on a cup and the fizz "
         "in the cup pops. Do come and get it!", ("bug", "moth", "bug")),
    41: ("Stop!", "🛑",
         "Step up, step up! Stop at the top. A nest is on the step. "
         "In the nest sit six eggs. That is the best nest!",
         ("nest", "shop", "nest")),
    42: ("The Wasp", "🐝",
         "A wasp can spin and buzz. It has a spot on its back. "
         "Stop! Do not hit the wasp. Let it spin off.",
         ("wasp", "crab", "wasp")),
    43: ("Snack Time", "🍎",
         "I skip to my desk. On the desk is a snack. Snap! I snap it up. "
         "It was the best snack.", ("snack", "mask", "snack")),
    44: ("The Crab", "🦀",
         "A crab sat on a rock. Clap! Clap! The crab ran. "
         "It can run fast and it hid in a crack.", ("crab", "frog", "crab")),
    45: ("Best Friends", "🤝",
         "Chad and Meg skip to the shop. When they get in, Chad claps. "
         "One big fish! Meg grins. They run back with the fish and "
         "munch it up!", ("fish", "crab", "fish")),
    46: ("The Frog", "🐸",
         "A frog sat on a flat rock. The rock was fresh and wet. "
         "The frog got a bug and then it hid in the grass.",
         ("frog", "crab", "frog")),
    47: ("Glad Glass", "🥛",
         "Meg has a glass of milk. She grabs it fast and grins. "
         "The milk is fresh. Meg is glad.", ("milk", "fizz", "milk")),
    48: ("The Drum", "🥁",
         "Chad has a drum. He hits it with his hand. Bang, bang! "
         "A drop of milk lands on the drum.", ("drum", "flag", "drum")),
    49: ("Bricks", "🧱",
         "We bring the bricks. Meg can lift a brick. "
         "We stack them up in a big block. It is a den!",
         ("bricks", "socks", "bricks")),
    50: ("The Plan", "📋",
         "There is a little shed on the hill. Chad has a plan. "
         "We will fix the shed and then we can sit in it. "
         "Meg grabs a brush and we get to it.", ("shed", "ship", "shed")),
    51: ("Plums", "🍑",
         "Plums! I plan to pick ten plums. I press them in a dish "
         "and mash them up. Plum jam! Yum.", ("plums", "socks", "plums")),
    52: ("On the Sand", "🏖️",
         "We put up a tent on the sand. An ant runs past my hand. "
         "The pond is next to us and a duck lands in it.",
         ("tent", "shop", "tent")),
    53: ("Camp", "🏕️",
         "At camp we jump and run. Meg has a lamp. "
         "When it gets dim, the lamp lands on the path back.",
         ("lamp", "drum", "lamp")),
    54: ("Milk and Belts", "🥛",
         "Help! My belt is stuck. Meg helps and it is fixed. "
         "We drink milk and it melts the last of the chill.",
         ("belt", "brick", "belt")),
    55: ("The Gift", "🎁",
         "I lift the soft gift. What is in it? I rip the top off "
         "fast. A drum! It is the best gift.", ("gift", "lamp", "gift")),
    56: ("At the Desk", "🪑",
         "My mask is on the desk. A wasp buzzes past the desk. "
         "I sit still and it lands, then it zips off.",
         ("mask", "flag", "mask")),
    57: ("Stamps", "📮",
         "I print my list. Then I stamp the last stamp on it. "
         "Meg has a plant in a pot and puts it next to the stamps.",
         ("stamp", "brick", "stamp")),
    58: ("The Best Camp", "⛺",
         "Chad and Meg set up camp. They put up the tent and get "
         "the lamp. When it is dim, they sit and munch fresh chips. "
         "Some ducks come to the pond. It was the best camp!",
         ("camp", "shop", "camp")),
    59: ("The Picnic", "🧺",
         "At sunset we had a picnic. We had chicken and a plum. "
         "A little chick ran past us and we all had a big grin.",
         ("picnic", "gift", "picnic")),
    60: ("Chad and the Ship", "🚢",
         "Chad ran fast to the dock. A big ship sat in the sun. "
         "The ship had a red flag on top and a bell that rang. "
         "Chad had a plan. He must get on the ship! "
         "The man at the dock said, I have a job, Chad. "
         "Chad got on with a grin. Off went the ship, out to the sun.",
         ("ship", "shed", "ship")),
}

PLACES = ["Cove", "Bay", "Point", "Beach", "Nook", "Hill", "Shore", "Isle",
          "Reef", "Sands", "Lagoon", "Cliff"]
PALETTE = ["#06D6A0", "#118AB2", "#9B5DE5", "#FF7F51", "#8AC926", "#3A86FF",
           "#F72585", "#7209B7", "#2FD08D", "#FB8500", "#FFB703", "#EF476F"]

WORLD = "Sound Forest"
WORLD_INDEX = 2

TRACEABLE = set("abcdefghijklmnopqrstuvwxyz")


def picture_words(contains: str, index: int, limit: int = 3):
    found = []
    for word, emoji in WORD_BANK.items():
        if contains in word and is_readable(word, index):
            found.append({"text": word, "emoji": emoji})
        if len(found) == limit:
            break
    return found


def mission_options(target: str, pool: list[str]):
    others = [w for w in pool if w != target][:3]
    options = [target, target] + others[:2]
    return options


def build():
    levels = []

    for index, graphemes, note in STAGE_2_ISLANDS:
        steps = []
        grapheme = graphemes[0] if graphemes else None

        if grapheme:
            sound, example, emoji, cue = NEW_CODE[grapheme]
            title = f"{example.capitalize()} {PLACES[index % 12]}"
            subtitle = f"Meet {grapheme}"

            steps.append({
                "type": "letterIntro",
                "letter": grapheme,
                "sound": sound,
                "exampleWord": example,
                "exampleEmoji": emoji,
                "say": f"Two letters, one sound. {grapheme} says {sound}. "
                       f"{cue}",
            })
            steps.append({
                "type": "trace",
                "letter": grapheme,
                "support": "guided",
                "case": "both",
                "say": f"Write {grapheme}. Two letters, one sound.",
            })

            words = picture_words(grapheme, index)
            if words:
                steps.append({
                    "type": "wordCard",
                    "prompt": f"These have {grapheme} in them.",
                    "words": words,
                })
            if words:
                first = words[0]["text"]
                if len(first) <= 4:
                    steps.append({
                        "type": "spell",
                        "word": first,
                        "emoji": words[0]["emoji"],
                        "distractors": ["m" if "m" not in first else "p"],
                    })

        elif index in BLENDS:
            title, focus, words = BLENDS[index]
            subtitle = f"Blend {focus}"
            emoji = WORD_BANK.get(words[0], "🔤")

            usable = [
                {"text": w, "emoji": WORD_BANK[w]}
                for w in words
                if w in WORD_BANK and is_readable(w, index)
            ]
            if usable:
                steps.append({
                    "type": "wordCard",
                    "prompt": f"Push the sounds together: {focus}.",
                    "words": usable[:3],
                })
                for word in usable[:2]:
                    if len(word["text"]) <= 4:
                        steps.append({
                            "type": "spell",
                            "word": word["text"],
                            "emoji": word["emoji"],
                            "distractors": ["z"],
                        })
                steps.append({
                    "type": "mission",
                    "prompt": f"Find {usable[0]['text']}!",
                    "target": usable[0]["text"],
                    "options": mission_options(
                        usable[0]["text"], [u["text"] for u in usable[1:]]
                    ),
                })
        else:
            first_read = note == "first read"
            title = "First Read Two" if first_read else f"Practice {PLACES[index % 12]}"
            subtitle = ("Read it on your own" if first_read
                        else "Read what you know")
            emoji = "🏆" if first_read else "🔁"
            focus_letter = {35: "sh", 45: "ch", 50: "th", 58: "ng"}.get(
                index, "s")

            # A practice island should be a proper session, not one activity.
            # Words are pulled from everything taught so far, so review really
            # does revisit rather than repeat the last island.
            revisit = [
                {"text": word, "emoji": emoji_for}
                for word, emoji_for in WORD_BANK.items()
                if is_readable(word, index) and 3 <= len(word) <= 5
            ]
            revisit = revisit[max(0, (index * 3) % max(1, len(revisit) - 3)):][:3]

            if revisit:
                steps.append({
                    "type": "wordCard",
                    "prompt": "You can read all of these now.",
                    "words": revisit,
                })

            steps.append({
                "type": "trace",
                "letter": focus_letter,
                "support": "dots",
                "case": "both",
                "say": "Write it from memory this time.",
            })

            short = [w for w in revisit if len(w["text"]) <= 4]
            if short:
                steps.append({
                    "type": "spell",
                    "word": short[0]["text"],
                    "emoji": short[0]["emoji"],
                    "distractors": ["z" if "z" not in short[0]["text"] else "b"],
                })

            if revisit:
                target = revisit[0]["text"]
                others = [w["text"] for w in revisit[1:]][:2] or ["ship"]
                steps.append({
                    "type": "mission",
                    "prompt": f"Find the word {target}!",
                    "target": target,
                    "options": [target, target] + others,
                })

        if index in PASSAGES:
            passage_title, passage_emoji, text, question = PASSAGES[index]
            step = {
                "type": "reading",
                "title": passage_title,
                "emoji": passage_emoji,
                "text": text,
                "support": "guided" if index < 45 else "independent",
            }
            if question:
                target, other, answer = question
                step["question"] = "What is it about?"
                step["options"] = [target, other]
                step["answer"] = answer
            steps.append(step)

        levels.append({
            "id": f"s2_{index:02d}",
            "index": index,
            "world": WORLD,
            "worldIndex": WORLD_INDEX,
            "title": title,
            "subtitle": subtitle,
            "emoji": emoji,
            "color": PALETTE[(index - 1) % len(PALETTE)],
            "reward": {
                "id": f"t2_{index:02d}",
                "name": f"{title.split()[0]} Leaf",
                "emoji": "🍃" if index % 3 else "🌟",
            },
            "steps": steps,
        })

    return levels


if __name__ == "__main__":
    # Stage 1 stays exactly as authored; stage 2 is appended after it.
    existing = json.load(open("assets/content/levels.json", encoding="utf-8"))
    stage1 = [level for level in existing if level["worldIndex"] == 1]

    levels = stage1 + build()

    with open("assets/content/levels.json", "w", encoding="utf-8") as handle:
        json.dump(levels, handle, ensure_ascii=False, indent=1)

    passages = [s for l in levels for s in l["steps"] if s["type"] == "reading"]
    words = sum(len(p["text"].split()) for p in passages)

    print(f"{len(levels)} islands: {len(stage1)} in stage 1, "
          f"{len(levels) - len(stage1)} in stage 2")
    print(f"{sum(len(l['steps']) for l in levels)} activities")
    print(f"{len(passages)} passages, {words} words of connected text")
    sys.exit(0)
