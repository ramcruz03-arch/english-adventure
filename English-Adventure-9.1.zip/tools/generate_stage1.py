#!/usr/bin/env python3
"""Builds Stage 1 (30 islands) of the reading course.

Every passage below is hand-written, then machine-checked by tools/phonics.py
against the code taught at or before its island. Nothing here is templated:
`The sat is on a tap` cannot happen, because a nonsense sentence is a
sentence somebody wrote, and nobody wrote these except by hand.

    python3 tools/generate_stage1.py
    python3 tools/phonics.py assets/content/levels.json
"""

from __future__ import annotations

import json
import sys

from phonics import STAGE_1, is_readable

# --------------------------------------------------------------------------
# Word bank: only words a child meets in Stage 1, each with a picture.
# Words without a good picture are still usable inside passages.
# --------------------------------------------------------------------------
WORD_BANK = {
    "sun": "🌞", "sit": "🪑", "sat": "🪑", "sip": "🥤", "six": "6️⃣",
    "ant": "🐜", "an": "🐜", "at": "🎯",
    "tap": "👆", "tin": "🥫", "ten": "🔟", "top": "🔝",
    "pig": "🐷", "pin": "📌", "pan": "🍳", "pen": "🖊️", "pot": "🍲",
    "pup": "🐶", "pat": "🤚",
    "it": "👉", "in": "📥",
    "nap": "😴", "net": "🥅", "nut": "🌰",
    "map": "🗺️", "mat": "🟫", "mad": "😠", "mud": "💩", "mix": "🥣",
    "dog": "🐶", "dad": "👨", "dig": "⛏️", "dot": "⚫",
    "gas": "⛽", "got": "✅", "gum": "🍬",
    "on": "🔛", "hop": "🐰", "hot": "🔥",
    "cat": "🐱", "cap": "🧢", "can": "🥫", "cup": "☕", "cut": "✂️",
    "kid": "🧒", "kit": "🎒",
    "red": "🔴", "bed": "🛏️", "leg": "🦵", "hen": "🐔", "get": "🎁",
    "up": "⬆️", "bus": "🚌", "bun": "🍞", "rug": "🧶", "run": "🏃",
    "rat": "🐀", "ran": "🏃", "rip": "📄",
    "hat": "🎩", "ham": "🍖", "hug": "🤗",
    "bag": "🎒", "big": "🐘", "bin": "🗑️", "bat": "🦇", "bug": "🐛",
    "fan": "🪭", "fig": "🍈", "fun": "🎉", "fit": "💪",
    "log": "🪵", "lip": "👄", "lid": "🥫", "lot": "➕",
    "jam": "🍯", "jet": "✈️", "jug": "🫙", "job": "🔧",
    "van": "🚐", "vet": "🩺",
    "web": "🕸️", "wet": "💧", "wig": "💇", "win": "🏆",
    "yes": "✅", "yak": "🐂", "yum": "😋",
    "zip": "🤐", "zap": "⚡",
    "quiz": "❓",
    "fox": "🦊", "box": "📦", "wax": "🕯️",
}

# --------------------------------------------------------------------------
# Letter teaching data: sound, and a picture word for the introduction.
# The example word is HEARD, not read, so it does not have to be decodable.
# --------------------------------------------------------------------------
LETTERS = {
    "s": ("sss", "sun", "🌞"),
    "a": ("ah", "apple", "🍎"),
    "t": ("t", "turtle", "🐢"),
    "p": ("p", "pig", "🐷"),
    "i": ("ih", "igloo", "🧊"),
    "n": ("nnn", "nest", "🪺"),
    "m": ("mmm", "moon", "🌙"),
    "d": ("d", "dog", "🐶"),
    "g": ("g", "goat", "🐐"),
    "o": ("o", "octopus", "🐙"),
    "c": ("k", "cat", "🐱"),
    "k": ("k", "key", "🔑"),
    "e": ("eh", "egg", "🥚"),
    "u": ("uh", "umbrella", "☂️"),
    "r": ("rrr", "rainbow", "🌈"),
    "h": ("h", "hat", "🎩"),
    "b": ("b", "bee", "🐝"),
    "f": ("fff", "fish", "🐟"),
    "l": ("lll", "lion", "🦁"),
    "j": ("j", "jam", "🍯"),
    "v": ("vvv", "van", "🚐"),
    "w": ("wuh", "wave", "🌊"),
    "y": ("yuh", "yo-yo", "🪀"),
    "z": ("zzz", "zebra", "🦓"),
    "qu": ("kw", "queen", "👑"),
    "x": ("ks", "fox", "🦊"),
}

# --------------------------------------------------------------------------
# Passages, hand-written. Key = island index.
# Reading only begins once there is enough code to say something real: the
# first six islands get single words and labels instead of a pretend story.
# --------------------------------------------------------------------------
PASSAGES = {
    7: ("I Sit", "🪑", "I sit. I sip. I tap the tin.", None),
    8: ("I Am Sam", "🧍", "I am Sam. I tap. I nap.", None),
    9: ("Dad Is Sad", "😢", "Dad is sad. I pat Dad. Dad and I nap.",
        ("Dad", "Sam", "Dad")),
    10: ("I Dig", "⛏️", "I dig. Dad digs a pit. I am in the pit!",
         ("pit", "pin", "pit")),
    11: ("On the Mat", "🟫",
         "I go to Dad. Dad is on a mat. I sit on the mat.", ("mat", "pot", "mat")),
    12: ("The Cat", "🐱",
         "A cat sat on a cot. I pat the cat. The cat naps.",
         ("cat", "dog", "cat")),
    13: ("Kim Can Dig", "🧒",
         "The kid is Kim. Kim can dig. Kim digs a pit and sits in it.",
         ("Kim", "Sam", "Kim")),
    14: ("Sam Naps", "😴",
         "Sam is in his cot. The cat sits on Sam. Sam naps and the cat naps.",
         ("cat", "pig", "cat")),
    15: ("Meg Gets a Net", "🥅",
         "I get a pen. Meg gets a net. Meg is sad. Meg is set to go!",
         ("net", "pen", "net")),
    16: ("The Pup", "🐶",
         "The pup is in the mud. Dad gets the pup. The pup is not sad. "
         "The pup naps on a mat.", ("mud", "cot", "mud")),
    17: ("The Rat Ran", "🐀",
         "The rat ran. The rat got a nut. The rat sat on a rug and ate...",
         None),
    18: ("He Has a Hat", "🎩",
         "He has a hat. The hat is red. He puts it on and sits.",
         None),
    19: ("Ben and the Bag", "🎒",
         "Ben has a big bag. In the bag he has a bun and a nut. "
         "Ben sits on a bed and gets the bun.", ("bun", "bug", "bun")),
    20: ("It Is Hot", "🔥",
         "It is hot. Ben gets a fan. The fan is fun. Ben and Meg sit and "
         "the fan is on.", ("fan", "fig", "fan")),
    21: ("You Can Help", "🤝",
         "It was hot. Ben ran to get us a fan. You can put it on. "
         "We sit and the fan hums.", ("fan", "bus", "fan")),
    22: ("The Log", "🪵",
         "The log is big. A bug is on the log. The bug is red. "
         "Sam and Meg let the bug be.", ("bug", "bat", "bug")),
    23: ("Jam in a Jug", "🍯",
         "Jen has jam in a jug. The jam is red. Jen gets a bun and puts "
         "jam on it.", ("jam", "gum", "jam")),
    24: ("The Vet", "🩺",
         "The vet has a van. A dog is sad, so the vet gets in the van. "
         "The vet can help the dog.", ("van", "bus", "van")),
    25: ("All Is Wet", "💧",
         "It is wet. The web is wet. All the bugs are wet. "
         "They run and hide in a big log.", ("web", "bed", "web")),
    26: ("The Yak", "🐂",
         "Yes! Sam has a yak. The yak is big and red. Sam and the yak "
         "run up a bank and sit on the top.", ("yak", "yam", "yak")),
    27: ("Zak Can Zip", "🤐",
         "Zak has a bag. The bag has a zip on it. Zak can zip up his bag. "
         "In it he puts a bun, a fig and a red pen.", ("zip", "zap", "zip")),
    28: ("The Quiz", "❓",
         "Quin has a quiz. The quiz is fun. Quin gets ten of ten! "
         "Dad hugs Quin and gets him a bun.", ("quiz", "quit", "quiz")),
    29: ("The Fox and the Box", "🦊",
         "A fox got in a box. Six bugs sit in it! "
         "The fox hops up and runs. The bugs win!", ("fox", "ox", "fox")),
    30: ("Max the Fox", "🦊",
         "Max the fox has a big red box. In the box he has a bun, a nut "
         "and a hat. Max sits on a log. He gets the bun and the nut. Yum! "
         "Max puts the hat on and naps in the sun. Max is glad.",
         ("Max", "Sam", "Max")),
}

# Very early islands: labels rather than sentences, because there is not yet
# enough code for a sentence that means anything.
EARLY_WORDS = {
    3: ["sat", "at"],
    4: ["sat", "tap", "pat"],
    5: ["sit", "tip", "sip"],
    6: ["pin", "tin", "nap"],
}

PLACES = ["Cove", "Bay", "Point", "Beach", "Nook", "Hill", "Shore", "Isle",
          "Reef", "Sands", "Lagoon", "Cliff"]
PALETTE = ["#FFB703", "#EF476F", "#06D6A0", "#118AB2", "#9B5DE5", "#FF7F51",
           "#8AC926", "#3A86FF", "#F72585", "#7209B7", "#2FD08D", "#FB8500"]

WORLD = "Sound Island"
WORLD_INDEX = 1


def picture_words(letter: str, index: int, limit: int = 3):
    """Decodable words containing this letter, newest code first."""
    found = []
    for word, emoji in WORD_BANK.items():
        if letter in word and is_readable(word, index):
            found.append({"text": word, "emoji": emoji})
        if len(found) == limit:
            break
    return found


def spellable(letter: str, index: int):
    for word, emoji in WORD_BANK.items():
        if letter in word and 2 <= len(word) <= 3 and is_readable(word, index):
            return word, emoji
    return None


def mission_options(letter: str):
    others = [c for c in "abcdefghijklmnopqrstuvwxyz" if c != letter]
    seed = sum(ord(c) for c in letter)
    picks = [others[(seed + i * 7) % len(others)] for i in range(3)]
    options = [letter] * 3 + picks
    return options


def build():
    levels = []

    for index, graphemes, note in STAGE_1:
        steps = []
        letter = graphemes[0] if graphemes else None

        if letter:
            sound, example, example_emoji = LETTERS[letter]
            title = f"{example.capitalize()} {PLACES[(index - 1) % 12]}"
            subtitle = f"Meet {letter}"
            emoji = example_emoji

            steps.append({
                "type": "letterIntro",
                "letter": letter,
                "sound": sound,
                "exampleWord": example,
                "exampleEmoji": example_emoji,
                "say": f"This is {letter}. It says {sound}. "
                       f"{sound.capitalize()}, like {example}.",
            })
            steps.append({
                "type": "trace",
                "letter": letter,
                "support": "guided",
                # Little one, then the big one. Every sentence starts with a
                # capital, so teaching only lowercase leaves a child unable
                # to read the text we hand them.
                "case": "both",
                "say": f"Now write {letter}. Watch me first.",
            })
            steps.append({
                "type": "mission",
                "prompt": f"Find every {letter}!",
                "target": letter,
                "options": mission_options(letter),
            })

            words = picture_words(letter, index)
            if words:
                steps.append({
                    "type": "wordCard",
                    "prompt": "Tap a card to hear it.",
                    "words": words,
                })

            pair = spellable(letter, index)
            if pair and index >= 4:
                word, word_emoji = pair
                steps.append({
                    "type": "spell",
                    "word": word,
                    "emoji": word_emoji,
                    "distractors": ["s" if letter != "s" else "t"],
                })
        else:
            # Review and First Read islands.
            first_read = note == "first read"
            title = "First Read" if first_read else f"Practice {PLACES[index % 12]}"
            subtitle = ("Read it on your own" if first_read
                        else "Read what you know")
            emoji = "🏆" if first_read else "🔁"
            if index in (14, 30):
                # The most motivating handwriting task there is: a capital
                # first letter and lowercase after, exactly like a name.
                steps.append({
                    "type": "trace",
                    "letter": "s",
                    "word": "{name}",
                    "support": "guided",
                    "say": "Let us write your name!",
                })
            else:
                steps.append({
                    "type": "trace",
                    "letter": {7: "a", 21: "e"}.get(index, "s"),
                    "support": "dots",
                    "case": "both",
                    "say": "Write it from memory this time.",
                })

        if index in EARLY_WORDS:
            steps.append({
                "type": "wordCard",
                "prompt": "You can read these now!",
                "words": [
                    {"text": w, "emoji": WORD_BANK.get(w, "🔤")}
                    for w in EARLY_WORDS[index]
                ],
            })

        if index in PASSAGES:
            title_text, passage_emoji, text, question = PASSAGES[index]
            step = {
                "type": "reading",
                "title": title_text,
                "emoji": passage_emoji,
                "text": text,
                "support": "guided" if index < 20 else "independent",
            }
            if question:
                target, other, answer = question
                step["question"] = "What is it about?"
                step["options"] = [target, other]
                step["answer"] = answer
            steps.append(step)

        levels.append({
            "id": f"s1_{index:02d}",
            "index": index,
            "world": WORLD,
            "worldIndex": WORLD_INDEX,
            "title": title,
            "subtitle": subtitle,
            "emoji": emoji,
            "color": PALETTE[(index - 1) % len(PALETTE)],
            "reward": {
                "id": f"t1_{index:02d}",
                "name": f"{title.split()[0]} Shell",
                "emoji": "🐚" if index % 3 else "⭐",
            },
            "steps": steps,
        })

    return levels


if __name__ == "__main__":
    levels = build()
    with open("assets/content/levels.json", "w", encoding="utf-8") as handle:
        json.dump(levels, handle, ensure_ascii=False, indent=1)

    total_steps = sum(len(l["steps"]) for l in levels)
    words = sum(
        len(s["text"].split())
        for l in levels for s in l["steps"] if s["type"] == "reading"
    )
    print(f"Stage 1: {len(levels)} islands, {total_steps} activities")
    print(f"Reading: {sum(1 for l in levels for s in l['steps'] if s['type'] == 'reading')} "
          f"passages, {words} words of connected text")
    sys.exit(0)


# --------------------------------------------------------------------------
# Assessment material (parent-facing, never shown as a score to the child).
#
# Reading checks are UNPRACTICED passages: they must never appear in the
# course itself, or we would be measuring memory instead of reading.
# Code checks are made-up words, which cannot be memorised at all, so they
# prove decoding. This is why England's phonics screening check uses them.
# --------------------------------------------------------------------------
READING_CHECKS = [
    (10, "Dad Naps", "Dad naps. I sit and pat Dad. A pin is in the tin. "
                     "I tip the tin and the pin is in a pit."),
    (14, "The Cat and the Mat",
     "A cat sat on a mat. Sam got a cap. The cat got in the cap! "
     "Sam and his dad sit and pat the cat."),
    (20, "Ben Gets a Bun",
     "Ben is hot. He gets a big red cup. In the cup is a bun. "
     "Ben sits on a mat and he has the bun. It is fun."),
    (26, "The Yak and the Bug",
     "A yak ran up to the log. On the log sat a red bug. "
     "The yak did not get the bug. The bug hid in the log and the yak ran on."),
    (30, "Six Bugs",
     "Six bugs sat in a big box. A fox got up on the box. "
     "The bugs did not run. The fox ran and the six bugs had a nap."),
]

CODE_CHECKS = [
    (10, ["sid", "nid", "tam", "pim", "gat", "nim"]),
    (18, ["ked", "rup", "ras", "hep", "dut", "nug"]),
    (26, ["vem", "jat", "wug", "yod", "lin", "bap"]),
    (30, ["quz", "zog", "vix", "jul", "wem", "yat"]),
]


def build_checks():
    return {
        "reading": [
            {"minIsland": index, "title": title, "text": text}
            for index, title, text in READING_CHECKS
        ],
        "code": [
            {"minIsland": index, "words": words}
            for index, words in CODE_CHECKS
        ],
    }
