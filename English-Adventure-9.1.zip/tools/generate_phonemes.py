#!/usr/bin/env python3
"""
Azure Neural TTS Phoneme Generator
==================================
Generates 26 isolated phoneme clips using Microsoft Azure Neural TTS.

Voice:      en-US-AriaNeural
Format:     24 kHz, 16-bit, mono WAV
Output:     phonemes/ directory
Rate:       Slightly slower than normal (-15%)

Prerequisites:
    pip install azure-cognitiveservices-speech

Environment variables:
    AZURE_SPEECH_KEY      Your Azure Speech Services subscription key
    AZURE_SPEECH_REGION   Your Azure region (e.g., eastus, westus2)

Usage:
    export AZURE_SPEECH_KEY="your-key"
    export AZURE_SPEECH_REGION="your-region"
    python generate_phonemes.py
"""

import os
import sys

# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------
VOICE_NAME = "en-US-AriaNeural"
OUTPUT_FORMAT = "Riff24Khz16BitMonoPcm"   # 24 kHz, 16-bit, mono WAV
OUTPUT_DIR = "phonemes"
RATE = "-15%"                             # Slightly slower than normal

# 26 phonemes in exact order (order identifies each clip)
# Each tuple: (filename_stem, display_text, ipa_phoneme)
# Use IPA for precise pronunciation; set ipa_phoneme to None to use plain text.
PHONEMES = [
    ("01_sss",  "sss",  "s"),      # 1.  voiceless alveolar fricative
    ("02_ah",   "ah",   "ɑ"),      # 2.  open back unrounded vowel
    ("03_tuh",  "tuh",  "tʌ"),     # 3.  alveolar plosive + schwa
    ("04_puh",  "puh",  "pʌ"),     # 4.  bilabial plosive + schwa
    ("05_ihh",  "ihh",  "ɪ"),      # 5.  near-close near-front vowel
    ("06_nnn",  "nnn",  "n"),      # 6.  alveolar nasal
    ("07_mmm",  "mmm",  "m"),      # 7.  bilabial nasal
    ("08_duh",  "duh",  "dʌ"),     # 8.  voiced alveolar plosive + schwa
    ("09_guh",  "guh",  "gʌ"),     # 9.  voiced velar plosive + schwa
    ("10_awh",  "awh",  "ɔ"),      # 10. open-mid back rounded vowel
    ("11_kuh",  "kuh",  "kʌ"),     # 11. voiceless velar plosive + schwa
    ("12_kuh2", "kuh",  "kʌ"),     # 12. duplicate of 11
    ("13_ehh",  "ehh",  "ɛ"),      # 13. open-mid front unrounded vowel
    ("14_uhh",  "uhh",  "ʌ"),      # 14. open-mid back unrounded vowel
    ("15_rrr",  "rrr",  "ɹ"),      # 15. alveolar approximant
    ("16_huh",  "huh",  "hʌ"),     # 16. voiceless glottal fricative + schwa
    ("17_buh",  "buh",  "bʌ"),     # 17. voiced bilabial plosive + schwa
    ("18_fff",  "fff",  "f"),      # 18. voiceless labiodental fricative
    ("19_lll",  "lll",  "l"),      # 19. alveolar lateral approximant
    ("20_juh",  "juh",  "dʒʌ"),    # 20. voiced postalveolar affricate + schwa
    ("21_vvv",  "vvv",  "v"),      # 21. voiced labiodental fricative
    ("22_wuh",  "wuh",  "wʌ"),     # 22. labial-velar approximant + schwa
    ("23_yuh",  "yuh",  "jʌ"),     # 23. palatal approximant + schwa
    ("24_zzz",  "zzz",  "z"),      # 24. voiced alveolar fricative
    ("25_kwuh", "kwuh", "kwʌ"),    # 25. labialized velar plosive + schwa
    ("26_ks",   "ks",   "ks"),     # 26. voiceless velar + alveolar fricative
]

# ---------------------------------------------------------------------------
# SSML BUILDER
# ---------------------------------------------------------------------------

def build_ssml(text: str, ipa: str | None, voice: str, rate: str) -> str:
    """Build SSML string. Uses <phoneme> when IPA is provided, else plain text."""
    if ipa:
        inner = f'<phoneme alphabet="ipa" ph="{ipa}">{text}</phoneme>'
    else:
        inner = text

    return f"""<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">
  <voice name="{voice}">
    <prosody rate="{rate}">
      {inner}
    </prosody>
  </voice>
</speak>"""


# ---------------------------------------------------------------------------
# AZURE TTS SYNTHESIS
# ---------------------------------------------------------------------------

def synthesize_phoneme(speech_config, filename: str, ssml: str) -> bool:
    """Synthesize a single phoneme clip to disk. Returns True on success."""
    audio_config = speechsdk.audio.AudioOutputConfig(filename=filename)
    synthesizer = speechsdk.SpeechSynthesizer(
        speech_config=speech_config,
        audio_config=audio_config
    )

    result = synthesizer.speak_ssml_async(ssml).get()

    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print(f"  ✓ {os.path.basename(filename)}")
        return True
    elif result.reason == speechsdk.ResultReason.Canceled:
        cancellation = result.cancellation_details
        print(f"  ✗ {os.path.basename(filename)} — CANCELED")
        print(f"    Reason: {cancellation.reason}")
        if cancellation.reason == speechsdk.CancellationReason.Error:
            print(f"    Error details: {cancellation.error_details}")
        return False
    else:
        print(f"  ? {os.path.basename(filename)} — {result.reason}")
        return False


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    key = os.environ.get("AZURE_SPEECH_KEY")
    region = os.environ.get("AZURE_SPEECH_REGION")

    if not key or not region:
        print("Error: Set AZURE_SPEECH_KEY and AZURE_SPEECH_REGION environment variables.")
        sys.exit(1)

    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output directory: {os.path.abspath(OUTPUT_DIR)}\n")

    # Configure speech service
    speech_config = speechsdk.SpeechConfig(subscription=key, region=region)
    speech_config.set_speech_synthesis_output_format(
        getattr(speechsdk.SpeechSynthesisOutputFormat, OUTPUT_FORMAT)
    )

    print(f"Voice:  {VOICE_NAME}")
    print(f"Format: {OUTPUT_FORMAT}")
    print(f"Rate:   {RATE}")
    print(f"Count:  {len(PHONEMES)} phonemes\n")
    print("Generating...")

    success_count = 0
    for stem, text, ipa in PHONEMES:
        filepath = os.path.join(OUTPUT_DIR, f"{stem}.wav")
        ssml = build_ssml(text, ipa, VOICE_NAME, RATE)
        if synthesize_phoneme(speech_config, filepath, ssml):
            success_count += 1

    print(f"\nDone. {success_count}/{len(PHONEMES)} files written to ./{OUTPUT_DIR}/")


if __name__ == "__main__":
    import azure.cognitiveservices.speech as speechsdk
    main()
