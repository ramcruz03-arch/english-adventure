#!/usr/bin/env python3
"""Prepares the generated Android project for a Play Store release.

Run from the Flutter project root, after `flutter create --platforms=android`:

    python3 tools/configure_android.py \
        --app-id com.ramcruz.englishadventure \
        --app-label "English Adventure" \
        --sign

What it does:

1. Sets `applicationId` — this is the identity Google Play uses. It can
   never be changed after your first release, so choose carefully.
2. Sets the launcher label shown under the icon.
3. Points the release build at a real signing key read from `key.properties`
   (Flutter's standard pattern), instead of the debug key.

Note on `namespace`: this script deliberately leaves it as the generated
value. The namespace is internal to the build and must match the package
declared in MainActivity.kt; changing one without the other breaks launch.
Play only ever sees `applicationId`. If you later want them to match, do a
full rename with `flutter create --org` and move MainActivity.kt yourself.
"""

import argparse
import pathlib
import re
import sys

KTS_SIGNING = """
    signingConfigs {
        create("release") {
            val keystoreProperties = java.util.Properties()
            val keystorePropertiesFile = rootProject.file("key.properties")
            if (keystorePropertiesFile.exists()) {
                keystorePropertiesFile.inputStream().use {
                    keystoreProperties.load(it)
                }
            }
            keyAlias = keystoreProperties.getProperty("keyAlias")
            keyPassword = keystoreProperties.getProperty("keyPassword")
            storeFile = keystoreProperties.getProperty("storeFile")?.let {
                file(it)
            }
            storePassword = keystoreProperties.getProperty("storePassword")
        }
    }
"""

GROOVY_SIGNING = """
    signingConfigs {
        release {
            def keystoreProperties = new Properties()
            def keystorePropertiesFile = rootProject.file('key.properties')
            if (keystorePropertiesFile.exists()) {
                keystorePropertiesFile.withInputStream {
                    keystoreProperties.load(it)
                }
            }
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
"""


def fail(message: str) -> "NoReturn":  # type: ignore[valid-type]
    print(f"configure_android: {message}", file=sys.stderr)
    sys.exit(1)


def find_gradle() -> pathlib.Path:
    for name in ("android/app/build.gradle.kts", "android/app/build.gradle"):
        path = pathlib.Path(name)
        if path.exists():
            return path
    fail("no android/app/build.gradle(.kts) found — run flutter create first")


def set_application_id(text: str, app_id: str, kotlin: bool) -> str:
    pattern = (
        r'applicationId\s*=\s*"[^"]+"' if kotlin else r'applicationId\s+"[^"]+"'
    )
    replacement = (
        f'applicationId = "{app_id}"' if kotlin else f'applicationId "{app_id}"'
    )
    updated, count = re.subn(pattern, replacement, text)
    if count == 0:
        fail("could not find applicationId in the Gradle file")
    return updated


def add_signing(text: str, kotlin: bool) -> str:
    if "signingConfigs" in text and "release" in text.split("buildTypes")[0]:
        print("  signing config already present, leaving it alone")
    else:
        block = KTS_SIGNING if kotlin else GROOVY_SIGNING
        updated, count = re.subn(
            r"(\n\s*buildTypes\s*\{)", block + r"\1", text, count=1
        )
        if count == 0:
            fail("could not find buildTypes to anchor the signing config")
        text = updated

    debug_ref = (
        r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)'
        if kotlin
        else r"signingConfig\s+signingConfigs\.debug"
    )
    release_ref = (
        'signingConfig = signingConfigs.getByName("release")'
        if kotlin
        else "signingConfig signingConfigs.release"
    )
    text, count = re.subn(debug_ref, release_ref, text)
    if count == 0:
        print("  warning: release build was not pointing at the debug key; "
              "check the signingConfig by hand")
    return text


def set_label(label: str) -> None:
    manifest = pathlib.Path("android/app/src/main/AndroidManifest.xml")
    if not manifest.exists():
        fail("AndroidManifest.xml not found")
    text = manifest.read_text(encoding="utf-8")
    text, count = re.subn(
        r'android:label="[^"]*"', f'android:label="{label}"', text, count=1
    )
    if count == 0:
        fail("could not find android:label in the manifest")
    manifest.write_text(text, encoding="utf-8")
    print(f"  label      -> {label}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--app-id", required=True)
    parser.add_argument("--app-label", required=True)
    parser.add_argument(
        "--sign",
        action="store_true",
        help="point the release build at key.properties",
    )
    args = parser.parse_args()

    if args.app_id.startswith("com.example."):
        fail("com.example.* is rejected by Google Play — pick a real id")

    gradle = find_gradle()
    kotlin = gradle.suffix == ".kts"
    text = gradle.read_text(encoding="utf-8")

    text = set_application_id(text, args.app_id, kotlin)
    print(f"  package    -> {args.app_id}")

    if args.sign:
        text = add_signing(text, kotlin)
        print("  signing    -> key.properties")
    else:
        print("  signing    -> debug key (no keystore supplied)")

    gradle.write_text(text, encoding="utf-8")
    set_label(args.app_label)
    print("configure_android: done")


if __name__ == "__main__":
    main()
