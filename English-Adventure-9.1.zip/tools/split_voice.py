#!/usr/bin/env python3
"""Splits one generated audio file into the app's individual voice clips.

Generate a single file containing every line in order, separated by pauses,
then cut it back up:

    python3 tools/split_voice.py downloaded.mp3 --tier 1

Tier 1 writes assets/audio/phonemes/<letter>.wav.
Any other tier takes a name list and writes assets/audio/vo/<slug>.wav.

Needs ffmpeg on the PATH. The split is by silence, so the pauses in the
script matter — if the count comes out wrong, adjust --silence or --min-gap
rather than re-recording.
"""

from __future__ import annotations

import argparse
import pathlib
import subprocess
import sys
import wave

import numpy as np

TIER1 = ["s", "a", "t", "p", "i", "n", "m", "d", "g", "o", "c", "k",
         "e", "u", "r", "h", "b", "f", "l", "j", "v", "w", "y", "z",
         "qu", "x"]

RATE = 22050


def to_wav(source: pathlib.Path) -> pathlib.Path:
    """Decode anything ffmpeg understands into mono 22.05k 16-bit."""
    target = source.with_suffix(".converted.wav")
    subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-i", str(source),
         "-ac", "1", "-ar", str(RATE), "-sample_fmt", "s16", str(target)],
        check=True,
    )
    return target


def read(path: pathlib.Path) -> np.ndarray:
    with wave.open(str(path)) as handle:
        frames = handle.readframes(handle.getnframes())
    return np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0


def write(path: pathlib.Path, samples: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    clipped = np.clip(samples, -1.0, 1.0)
    with wave.open(str(path), "w") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(RATE)
        handle.writeframes((clipped * 32000).astype(np.int16).tobytes())


def segments(audio: np.ndarray, threshold: float, min_gap: float,
             min_len: float) -> list[tuple[int, int]]:
    """Find the loud stretches, separated by gaps of at least `min_gap`."""
    window = int(RATE * 0.02)
    energy = np.sqrt(
        np.convolve(audio ** 2, np.ones(window) / window, mode="same")
    )
    loud = energy > threshold

    found: list[tuple[int, int]] = []
    start = None
    silence = 0
    gap_samples = int(RATE * min_gap)

    for i, is_loud in enumerate(loud):
        if is_loud:
            if start is None:
                start = i
            silence = 0
        elif start is not None:
            silence += 1
            if silence >= gap_samples:
                found.append((start, i - silence))
                start = None
    if start is not None:
        found.append((start, len(audio) - 1))

    return [(a, b) for a, b in found if (b - a) / RATE >= min_len]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("audio")
    parser.add_argument("--tier", default="1")
    parser.add_argument("--names", help="file of slugs, one per line")
    parser.add_argument("--silence", type=float, default=0.012,
                        help="loudness below this counts as silence")
    parser.add_argument("--min-gap", type=float, default=0.35,
                        help="seconds of silence that separate two clips")
    parser.add_argument("--min-len", type=float, default=0.08,
                        help="ignore blips shorter than this")
    parser.add_argument("--pad", type=float, default=0.05,
                        help="seconds of air kept either side")
    args = parser.parse_args()

    source = pathlib.Path(args.audio)
    if not source.exists():
        print(f"no such file: {source}", file=sys.stderr)
        return 1

    audio = read(to_wav(source))
    found = segments(audio, args.silence, args.min_gap, args.min_len)

    if args.names:
        names = [n.strip() for n in
                 pathlib.Path(args.names).read_text().splitlines() if n.strip()]
        out_dir = pathlib.Path("assets/audio/vo")
    else:
        names = TIER1
        out_dir = pathlib.Path("assets/audio/phonemes")

    print(f"found {len(found)} clips, expected {len(names)}")

    if len(found) != len(names):
        print(
            "\nCounts do not match, so nothing was written — writing them in\n"
            "the wrong order would be worse than writing nothing.\n"
            "  too many : raise --silence (e.g. 0.02) or --min-len\n"
            "  too few  : lower --min-gap (e.g. 0.25) or --silence\n",
            file=sys.stderr,
        )
        for i, (a, b) in enumerate(found, 1):
            print(f"  {i:>3}  {a / RATE:6.2f}s  to {b / RATE:6.2f}s  "
                  f"({(b - a) / RATE:.2f}s)")
        return 1

    pad = int(RATE * args.pad)
    for name, (a, b) in zip(names, found):
        start = max(0, a - pad)
        end = min(len(audio), b + pad)
        write(out_dir / f"{name}.wav", audio[start:end])
        print(f"  {out_dir}/{name}.wav  ({(end - start) / RATE:.2f}s)")

    print(f"\nwrote {len(names)} clips to {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
