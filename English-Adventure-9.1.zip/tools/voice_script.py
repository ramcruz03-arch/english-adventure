#!/usr/bin/env python3
"""Builds the list of every line the app can speak, ready for a voice tool.

    python3 tools/voice_script.py

Writes `voice_script.txt`: one line per clip, as `slug<TAB>text`. Paste the
text into TTSMaker (or any generator), download the audio, and save it as
`assets/audio/vo/<slug>.wav` — or `assets/audio/phonemes/<letter>.wav` for
the sounds. The app picks clips up automatically and falls back to the
device voice for anything missing, so you can do this in batches.

Work in tier order: tier 1 is 27 clips and fixes most of what sounds wrong.
"""

from __future__ import annotations

import json
import re
import sys

from phonics import STAGE_1

PHONEME_SPELLING = {
    "s": "sss", "a": "ah", "t": "tuh", "p": "puh", "i": "ihh",
    "n": "nnn", "m": "mmm", "d": "duh", "g": "guh", "o": "awh",
    "c": "kuh", "k": "kuh", "e": "ehh", "u": "uhh", "r": "rrr",
    "h": "huh", "b": "buh", "f": "fff", "l": "lll", "j": "juh",
    "v": "vvv", "w": "wuh", "y": "yuh", "z": "zzz", "qu": "kwuh",
    "x": "ks",
}

# Spoken lines from lib/core/copy.dart. Keep in step when you edit copy.
COPY_LINES = [
    "Nice one!", "You did it!", "Wow!", "Super!", "Great listening!",
    "Look at you go!", "Brilliant!", "High five!",
    "Nearly! Try another one.", "Good try! Have another go.",
    "Hmm, keep looking!", "Almost there!", "That one is sleepy. Try again!",
    "Listen again, then choose.", "The first sound helps!",
    "Say it slowly: push the sounds together.",
    "My turn. Listen to the sound.", "Your turn! Say it back to me.",
    "Watch how it is made.", "Now you write it. Start on the green dot.",
    "Let me show you again.", "Little one first.",
    "Listen first. I will read it to you.",
    "Now you read it. Tap a word if you need me.",
    "Your turn. Read it on your own!", "Let us read it again.",
    "Build the word.", "Tap a card to hear it.",
    "Finish the island before this one first!",
    "Ask a grown-up to open this world!",
    "It goes in your treasure bag.",
]


def slug(text: str) -> str:
    cleaned = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return cleaned[:60]


def main() -> int:
    levels = json.load(open("assets/content/levels.json", encoding="utf-8"))

    words: list[str] = []
    sentences: list[str] = []
    instructions: list[str] = []

    for level in levels:
        for step in level["steps"]:
            kind = step["type"]
            if kind == "letterIntro":
                instructions.append(step["say"])
                words.append(step["exampleWord"])
            elif kind == "wordCard":
                instructions.append(step["prompt"])
                words += [w["text"] for w in step["words"]]
            elif kind == "spell":
                words.append(step["word"])
            elif kind == "trace":
                instructions.append(step["say"])
            elif kind == "mission":
                instructions.append(step["prompt"])
            elif kind == "reading":
                for sentence in re.findall(r"[^.!?]+[.!?]", step["text"]):
                    sentences.append(sentence.strip())
                if step.get("question"):
                    instructions.append(step["question"])

    def unique(items: list[str]) -> list[str]:
        seen: dict[str, str] = {}
        for item in items:
            key = slug(item)
            if key and key not in seen:
                seen[key] = item
        return list(seen.values())

    tiers = [
        ("TIER 1 - the sounds (save to assets/audio/phonemes/<letter>.wav)",
         [(letter, spelling)
          for letter, spelling in PHONEME_SPELLING.items()]),
        ("TIER 2 - what Pip says (save to assets/audio/vo/<slug>.wav)",
         [(slug(t), t) for t in unique(COPY_LINES + instructions)]),
        ("TIER 3 - words (assets/audio/vo/)",
         [(slug(t), t) for t in unique(words)]),
        ("TIER 4 - passages, sentence by sentence (assets/audio/vo/)",
         [(slug(t), t) for t in unique(sentences)]),
    ]

    with open("voice_script.txt", "w", encoding="utf-8") as handle:
        for title, rows in tiers:
            handle.write(f"\n### {title}  ({len(rows)} clips)\n\n")
            for name, text in rows:
                handle.write(f"{name}\t{text}\n")

    total = sum(len(rows) for _, rows in tiers)
    print("wrote voice_script.txt")
    for title, rows in tiers:
        print(f"  {len(rows):>4}  {title.split(' - ')[0]}")
    print(f"  {total:>4}  total")
    print()
    print("Tier 1 alone fixes most of what sounds wrong: 27 clips.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
