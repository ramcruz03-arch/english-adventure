#!/usr/bin/env python3
"""The phonics engine: what code is taught when, and what a child can read.

This is the single source of truth for the curriculum sequence. Both the
content generator and the CI decodability check import it, so a passage can
never contain a word the child has not been taught to decode.

Vocabulary used here:
  grapheme   a letter or letter group spelling one sound: s, sh, igh, a-e
  tricky     a high-frequency word that cannot be fully decoded yet (the, I)
  taught     everything introduced at or before a given island index
"""

from __future__ import annotations

import json
import re
import sys

# ---------------------------------------------------------------------------
# The code progression
# ---------------------------------------------------------------------------
# Ordered by usefulness, not alphabet: after s, a, t, p a child can already
# read and build sat, at, tap, pat. Alphabetical order would mean weeks of
# letters with nothing to read. b and d are kept well apart because they are
# the most confused pair in early reading.
#
# Letter NAMES and ABC order are taught separately, on ABC Island, which is
# open from day one. Sounds are for reading; names are for talking about
# letters.

STAGE_1 = [
    # (island index, graphemes introduced, note)
    (1, ["s"], "sss"),
    (2, ["a"], "ah"),
    (3, ["t"], "t"),
    (4, ["p"], "p"),
    (5, ["i"], "ih"),
    (6, ["n"], "nnn"),
    (7, [], "review"),
    (8, ["m"], "mmm"),
    (9, ["d"], "d"),
    (10, ["g"], "g"),
    (11, ["o"], "o"),
    (12, ["c"], "k"),
    (13, ["k"], "k"),
    (14, [], "review"),
    (15, ["e"], "eh"),
    (16, ["u"], "uh"),
    (17, ["r"], "rrr"),
    (18, ["h"], "h"),
    (19, ["b"], "b"),
    (20, ["f"], "fff"),
    (21, [], "review"),
    (22, ["l"], "lll"),
    (23, ["j"], "j"),
    (24, ["v"], "vvv"),
    (25, ["w"], "wuh"),
    (26, ["y"], "yuh"),
    (27, ["z"], "zzz"),
    (28, ["qu"], "kw"),
    (29, ["x"], "ks"),
    (30, [], "first read"),
]

# ---------------------------------------------------------------------------
# Stage 2 (islands 31-60): the letter pairs, then blending
# ---------------------------------------------------------------------------
# Islands 31-40 add new code. From 41 the child learns to blend consonants
# that are already known (st, cr, mp) — a skill, not new spellings — so no
# graphemes are introduced there.
STAGE_2_ISLANDS = [
    (31, ["sh"], "shh"),
    (32, ["ch"], "ch"),
    (33, ["th"], "th"),
    (34, ["ng"], "ng"),
    (35, [], "review"),
    (36, ["ck"], "k"),
    (37, ["ff"], "fff"),
    (38, ["ll"], "lll"),
    (39, ["ss"], "sss"),
    (40, ["zz"], "zzz"),
    (41, [], "st blend"),
    (42, [], "sp blend"),
    (43, [], "sn sk blend"),
    (44, [], "cl cr blend"),
    (45, [], "review"),
    (46, [], "fl fr blend"),
    (47, [], "gr gl blend"),
    (48, [], "tr dr blend"),
    (49, [], "br bl blend"),
    (50, [], "review"),
    (51, [], "pl pr blend"),
    (52, [], "nd nt ending"),
    (53, [], "mp mp ending"),
    (54, [], "lt lp ending"),
    (55, [], "ft st ending"),
    (56, [], "sk sp ending"),
    (57, [], "three sounds"),
    (58, [], "review"),
    (59, [], "longer words"),
    (60, [], "first read"),
]

STAGE_2 = ["ch", "sh", "th", "ng", "ck", "ff", "ll", "ss", "zz"]
STAGE_3 = ["ai", "ee", "igh", "oa", "oo", "a-e", "i-e", "o-e", "u-e", "e-e"]
STAGE_4 = ["ar", "or", "ur", "er", "ow", "oi", "ear", "air", "ure", "ay",
           "ou", "ie", "ea", "oy", "ir", "ue", "aw", "wh", "ph", "ew", "oe",
           "au", "ey"]
STAGE_5 = ["-s", "-ing", "-ed", "-er", "-est", "-ly", "-y", "un-", "re-"]

# Tricky words: high-frequency, not yet fully decodable. Taught as
# "mostly regular with one odd bit", never as a whole shape to memorise.
TRICKY = [
    (3, ["a"]),
    (6, ["I"]),
    (7, ["the"]),
    (9, ["is"]),
    (11, ["to", "go", "no"]),
    (14, ["into", "his"]),
    (18, ["he", "she", "we", "me", "be"]),
    (21, ["was", "you"]),
    (25, ["they", "all", "are"]),
    (29, ["my", "her"]),
    # Stage 2
    (33, ["said", "so"]),
    (36, ["have", "like"]),
    (40, ["do", "some", "come"]),
    (45, ["one", "when", "out"]),
    (50, ["there", "little"]),
    (55, ["what", "were"]),
]

# Suffixes a child can read once the base word is decodable.
INFLECTIONS = ["s"]

# The child's own name is registered as tricky word zero: it cannot be
# sounded out, but it is usually the first word a child recognises, and the
# letters in it are learned faster than others.
NAME_TOKEN = "{name}"


ALL_ISLANDS = STAGE_1 + STAGE_2_ISLANDS


def taught_graphemes(through_index: int) -> set[str]:
    """Every grapheme introduced at or before `through_index`."""
    result: set[str] = set()
    for index, graphemes, _ in ALL_ISLANDS:
        if index <= through_index:
            result.update(graphemes)
    return result


def taught_tricky(through_index: int) -> set[str]:
    result: set[str] = set()
    for index, words in TRICKY:
        if index <= through_index:
            result.update(w.lower() for w in words)
    return result


def segment(word: str, graphemes: set[str]) -> list[str] | None:
    """Split a word into taught graphemes, longest match first.

    Returns the segmentation, or None if some part of the word uses code the
    child has not met. This checks spelling coverage, not pronunciation: it
    will accept `as` even though the s says /z/, so hand-check the word
    lists too.
    """
    word = word.lower()
    if not word:
        return []

    ordered = sorted(graphemes, key=len, reverse=True)

    def walk(position: int) -> list[str] | None:
        if position == len(word):
            return []
        for grapheme in ordered:
            if word.startswith(grapheme, position):
                rest = walk(position + len(grapheme))
                if rest is not None:
                    return [grapheme] + rest
        return None

    return walk(0)


# Letter pairs that LOOK decodable letter-by-letter but are not: a child who
# has not met `sh` will sound `ship` as s-h-i-p. The segmenter alone would
# wave that through, so any untaught digraph in a word disqualifies it.
TRAPS = [g for g in STAGE_2 + STAGE_3 + STAGE_4 if "-" not in g]


def has_untaught_trap(word: str, graphemes: set[str]) -> bool:
    return any(
        trap in word and trap not in graphemes
        for trap in TRAPS
    )


def is_readable(word: str, through_index: int) -> bool:
    """True if the child can read this word at this point in the course.

    Capitals count. Every sentence starts with one and every name has one,
    so a passage using `T` before `t` has been taught is asking the child to
    read a shape they have never met. Capitals are introduced alongside
    their lowercase, so the test is the same letter either way — but it is
    checked explicitly here so a later stage cannot quietly drift.
    """
    cleaned = re.sub(r"[^A-Za-z{}\-']", "", word)
    if not cleaned:
        return True
    if cleaned == NAME_TOKEN or "{name}" in word:
        return True  # tricky word zero, always allowed

    lowered = cleaned.lower()

    # Tricky words are learned whole, capital and all, so they are exempt
    # from the capital rule below.
    if lowered in taught_tricky(through_index):
        return True

    # A capital is only fair once its letter has been taught. `Q` counts as
    # taught once `qu` is, so match the first letter of any taught grapheme.
    graphemes_so_far = taught_graphemes(through_index)
    first_letters = {g[0] for g in graphemes_so_far}
    for character in cleaned:
        if character.isupper() and character.lower() not in first_letters:
            return False

    graphemes = taught_graphemes(through_index)
    if has_untaught_trap(lowered, graphemes):
        return False
    if segment(lowered, graphemes) is not None:
        return True

    # a plural or verb -s on an otherwise readable word
    for suffix in INFLECTIONS:
        if lowered.endswith(suffix):
            stem = lowered[: -len(suffix)]
            if stem and segment(stem, graphemes) is not None:
                return True

    return False


def unreadable_words(text: str, through_index: int) -> list[str]:
    """Every word in `text` the child could not decode yet."""
    words = re.findall(r"\{name\}|[A-Za-z][A-Za-z'\-]*", text)
    return [w for w in words if not is_readable(w, through_index)]


# ---------------------------------------------------------------------------
# CLI: check an authored levels.json
# ---------------------------------------------------------------------------

TEXT_FIELDS = ("text", "sentences")


def check_file(path: str) -> int:
    with open(path, encoding="utf-8") as handle:
        levels = json.load(handle)

    problems: list[str] = []
    checked = 0

    for level in levels:
        index = level["index"]
        for step in level["steps"]:
            texts: list[str] = []

            if step["type"] == "reading":
                # The question is spoken by Pip, so it need not be decodable.
                # The answer options are read by the child, so they must be.
                texts.append(step.get("text", ""))
                texts.extend(step.get("options", []))
            elif step["type"] == "story":
                texts.extend(step.get("sentences", []))
                texts.extend(step.get("options", []))
            elif step["type"] == "wordCard":
                texts.extend(w["text"] for w in step.get("words", []))
            elif step["type"] == "spell":
                texts.append(step.get("word", ""))
            elif step["type"] == "mission":
                texts.append(step.get("target", ""))

            for text in texts:
                if not text:
                    continue
                checked += 1
                bad = unreadable_words(text, index)
                if bad:
                    problems.append(
                        f"  island {index:>3} ({step['type']}): "
                        f"{', '.join(sorted(set(bad)))}\n"
                        f"      in: {text}"
                    )

    if problems:
        print("Decodability check FAILED", file=sys.stderr)
        print(
            "These words use code the child has not been taught yet:\n",
            file=sys.stderr,
        )
        for problem in problems:
            print(problem, file=sys.stderr)
        print(
            f"\n{len(problems)} problem(s) across {len(levels)} islands.",
            file=sys.stderr,
        )
        return 1

    print(f"Decodability OK - {checked} texts across {len(levels)} islands.")
    print("Every word is decodable with code taught at or before its island.")
    return 0


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "assets/content/levels.json"
    sys.exit(check_file(target))
