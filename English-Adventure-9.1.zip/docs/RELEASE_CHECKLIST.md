# Release checklist

Everything between "it builds" and "it's on Google Play".

---

## 1. Create your upload keystore (once, and never lose it)

On any machine with Java installed:

```bash
keytool -genkey -v \
  -keystore upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias upload
```

It asks for a password and some name/organisation details — the details are
not shown publicly.

**This file is irreplaceable.** Lose it and you can never update the app
under the same listing; you would have to publish a new one and lose every
install and review. Back it up somewhere that is not only your laptop, and
store the password separately.

(If you enrol in Play App Signing, which is the default, Google holds the
*app* signing key and this is your *upload* key. Recovery is possible in that
case but slow — still, treat it as irreplaceable.)

## 2. Put it in GitHub as secrets

Turn the keystore into text:

```bash
base64 -w 0 upload-keystore.jks > keystore.txt
```

Then in the repo: **Settings → Secrets and variables → Actions → New
repository secret**, four times:

| Secret | Value |
|---|---|
| `KEYSTORE_BASE64` | the whole contents of `keystore.txt` |
| `KEYSTORE_PASSWORD` | the store password you chose |
| `KEY_ALIAS` | `upload` |
| `KEY_PASSWORD` | the key password (usually the same) |

The workflow detects these automatically. Without them it still builds, but
with the debug key — fine for sideloading, rejected by Play.

Never commit the keystore or `key.properties` to the repository.

## 3. Set your package name

In `.github/workflows/build.yml`:

```yaml
env:
  APP_ID: com.ramcruz.englishadventure
  APP_LABEL: English Adventure
```

Change `APP_ID` before your first release — **it can never be changed
afterwards**. Convention is a domain you control, reversed. If you own
nothing, `com.<yourname>.<appname>` is accepted.

## 4. Create the in-app product

In Play Console → **Monetise → In-app products → Create product**:

- Product ID: `english_adventure_full` (must match `kFullVersionProductId` in
  `lib/core/purchase/purchase_service.dart`)
- Type: one-time purchase, non-consumable
- Price: around ₹399 / $4.99
- Activate it

Billing only works on a build installed **from Play** (internal testing
track counts). Sideloaded APKs always report the store as unavailable — the
paywall handles this gracefully and says so.

## 5. Store listing assets

- App icon 512×512 PNG
- Feature graphic 1024×500
- At least 2 phone screenshots (4–8 is better)
- Short description (80 chars) and full description
- Privacy policy URL — required. Yours is genuinely short: no accounts, no
  analytics, no ads, no data leaves the device; purchases handled by Google
  Play.

## 6. Declarations

- **Target audience**: children's age band. This triggers Families policy
  review — expect a slower, stricter review.
- **Data safety**: no data collected, no data shared. Say so honestly; a
  wrong answer here is the most common cause of enforcement later.
- **Ads**: none.
- **Content rating** questionnaire: answer honestly, expect "Everyone".
- **In-app purchases**: yes, one one-time product, behind a parental gate.

## 7. Testing before production

New personal developer accounts must run **closed testing with 12 testers
for 14 continuous days** before applying for production access. Start this
early — it is a wall-clock delay you cannot compress.

Use the time to watch real children use it and tune:

- tracing forgiveness (`_touchRadius`, `_successRatio` in `trace_view.dart`)
- voice speed default
- whether World 1 is finished at all

## 8. Before you would actually want people to see it

- Replace the emoji with real artwork. Reviewers and parents both read emoji
  as placeholder.
- Record a human voice for letter sounds; keep TTS as fallback.
- Have a literacy teacher read every line of `levels.json`.

---

## Order of work

1. Keystore + secrets + `APP_ID` → a signed AAB (an afternoon)
2. Internal testing track, install from Play, verify the purchase flow
3. Artwork and voice
4. Closed testing, 12 testers, 14 days
5. Production
