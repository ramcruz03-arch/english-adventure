# Adding content

All learning content lives in `assets/content/levels.json`. No Dart changes
are needed to add an island.

## An island

```json
{
  "id": "l61_q",
  "index": 61,
  "world": "Word Forest",
  "worldIndex": 4,
  "title": "Goat Hill",
  "subtitle": "Meet g",
  "emoji": "🐐",
  "color": "#FFB703",
  "reward": { "id": "goat_bell", "name": "Goat Bell", "emoji": "🔔" },
  "steps": [ ... ]
}
```

Islands unlock in `index` order. Keep 4–5 steps: about 3–5 minutes of play.

## Step types

| type | fields | what the child does |
|---|---|---|
| `letterIntro` | letter, sound, exampleWord, exampleEmoji, say | hears the sound, taps the letter |
| `wordCard` | prompt, words[{text, emoji}] | taps each card to hear the word and its letters |
| `spell` | word, emoji, distractors[] | drags letter tiles into the word |
| `trace` | letter, say, support, case, word? | writes the letter — `case` is `lower`, `upper` or `both`; `word: "{name}"` writes the child's own name |
| `mission` | prompt, target, options[] | finds every target bubble |
| `story` | emoji, sentences[], question, options[], answer | taps each line to hear it, then answers one question |
| `reading` | title, emoji, text, support, question?, options?, answer? | listens, reads together, then reads alone |

## Rules the validator enforces

- unique level ids and reward ids
- every island has a world and worldIndex
- story answers must be one of the story options
- colour in `#RRGGBB` form
- at most 6 steps per island
- `trace` letters must have strokes in `lib/core/letter_strokes.dart`
- `spell` words of 4 letters or fewer
- `mission` targets must appear in the options

Run it: `dart run tools/validate_content.dart`

## The decodability rule

Every word of every passage must be decodable with code taught at or before
its island, or be a tricky word already introduced. This is enforced by the
build, not by good intentions:

    python3 tools/phonics.py assets/content/levels.json

`tools/phonics.py` holds the code progression and is the single source of
truth for what is taught when. It catches three kinds of mistake:

- a word using an untaught letter (`big` before `b`)
- a word using an untaught digraph — `ship` is rejected before `sh` even
  though s, h, i and p are all known, because the child would sound it out
  wrongly
- a tricky word used before it is introduced (`the` before island 7)
- a capital whose letter has not been taught (`T` before `t`). Tricky words
  are exempt, since they are learned whole

The child's name is registered as tricky word zero: `{name}` in a passage is
always allowed, and is replaced at runtime with the name a parent set (or
`Sam` if they set none).

Two things are deliberately NOT checked: the spoken comprehension question
(Pip reads it aloud, so it need not be decodable) and the picture word in a
`letterIntro` (it is heard, not read).

## Regenerating everything

`python3 tools/generate_stage1.py` rebuilds `levels.json` from the word bank
and hand-written passages at the top of that script, then check it with
`python3 tools/phonics.py assets/content/levels.json`.

Passages are hand-written on purpose. Templated sentence generation is what
produced `The sat is on a tap` in an earlier version: a sentence is
something a person wrote, or it is word salad.

## Adding a new letter shape

All 26 lowercase letters already have strokes in
`lib/core/letter_strokes.dart`. For digraphs or capitals, add an entry there
(a list of strokes; each stroke is a list of points in a 0..1 box, y
downwards) and add the key to `traceableLetters` in the validator.

## Adding a new activity type

1. Add a subclass of `LessonStep` in `lib/data/models/level.dart` and a case
   in `LessonStep.fromJson`.
2. Add a view under `lib/features/lesson/steps/`.
3. Add the case to `_viewFor` in `lesson_screen.dart` — the compiler will
   tell you if you forget, because `LessonStep` is sealed.
