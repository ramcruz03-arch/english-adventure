# Pre-generated voice lines

Any line the app speaks can be replaced by an audio file here. The app looks
for a clip first and falls back to the device's own voice when there isn't
one, so this can be filled in over time rather than all at once.

    "You did it!"  ->  assets/audio/vo/you-did-it.wav

The filename is the line, lowercased, with everything that isn't a letter or
number turned into a hyphen. `tools/voice_script.py` prints the exact name
for every line, so there is no guesswork.

## Why bother, when the app already has a voice

Two reasons, and the second is the bigger one:

1. **It sounds the same on every phone.** Device text-to-speech varies wildly
   — a cheap Android may have a thin, fast voice, or none installed at all.
2. **You can listen before shipping.** With device speech you write "mmm" and
   hope. With clips you hear each one, and regenerate the ones that come out
   wrong. For isolated sounds, that difference is everything.

## The quick way: one file, split automatically

TTSMaker makes one audio file per submission, so generating 26 clips would
mean 26 submissions. Instead, generate them as a single file and cut it up:

1. Paste `tier1-sounds-PASTE-INTO-TTSMAKER.txt` in one go — the blank lines
   become the pauses that mark where one sound ends and the next begins
2. Download the audio (WAV if offered, MP3 is fine)
3. Split it:

       python3 tools/split_voice.py downloaded.mp3 --tier 1

It writes `assets/audio/phonemes/s.wav`, `a.wav`, `t.wav` and so on, in the
script's order. If the clip count comes out wrong it writes nothing and
tells you which setting to change — putting clips under the wrong names
would be worse than writing none.

Order is what identifies each clip, so don't reorder the script.

## Making them

`python3 tools/voice_script.py` writes `voice_script.txt` — every line, with
its filename, grouped into tiers. Work in tier order:

| Tier | What | Clips |
|---|---|---|
| 1 | the letter sounds | 26 |
| 2 | what Pip says: praise, nudges, instructions | 113 |
| 3 | the words | 85 |
| 4 | the passages, sentence by sentence | 86 |

**Tier 1 is the one that matters.** 26 clips, and the thing that sounds most
synthetic today stops being synthetic.

Tier 1 goes in `assets/audio/phonemes/` (named `m.wav`, `s.wav`, `qu.wav`).
Tiers 2–4 go here, named by slug.

## Using TTSMaker

TTSMaker's own terms grant full commercial rights to generated audio at no
cost, which is unusual and makes it a reasonable fit. Two cautions:

- At least one third-party licensing summary claims attribution is required,
  while TTSMaker's site says it is not. **Read their terms page yourself
  before release** and, if in doubt, credit them in the app's about screen —
  it costs nothing.
- The free tier is capped per week (about 20,000 characters), which is
  plenty for tier 1 and 2 but may need spreading over a couple of weeks for
  all four tiers.

Tips that matter more than the tool you pick:

- **Use one voice for everything.** Mixing voices across tiers is worse than
  a consistent synthetic one.
- **Pick a warm, slower voice**, and set the rate slightly below normal.
- **Audition every tier 1 clip.** If `t` comes out as "tee", try "tuh", "t'",
  or a short pause after. Keep whichever sounds like the sound.
- Trim the silence at both ends, or every prompt feels sluggish.

## Format

Mono, 22050 Hz, 16-bit WAV, or MP3 if you prefer smaller files — both work.

    ffmpeg -i downloaded.mp3 -ac 1 -ar 22050 -sample_fmt s16 you-did-it.wav

The folder is already listed in `pubspec.yaml`, so files are picked up with
no code change.
