# Recorded phonemes — INSTALLED

The 26 letter sounds ship in this folder as 16-bit mono WAV at 22.05 kHz,
about 690 KB in total. The app plays these instead of the device voice, so
every sound is identical on every phone.

Generated with Azure Neural TTS (en-US-AriaNeural, rate -15%), using IPA
rather than spelled-out approximations — see `tools/generate_phonemes.py`,
which regenerates the whole set. Trimmed of silence, level-matched and
fade-topped afterwards.

Stretchable sounds are held (s, f, l, n, r, v, z run 0.8-1.0s); stops are
short (b, d, k, p, t around 0.4-0.5s). That is what it should look like.

## Replacing one

Drop a new `s.wav` in and the app uses it. To regenerate everything:

    export AZURE_SPEECH_KEY=... AZURE_SPEECH_REGION=...
    python3 tools/generate_phonemes.py

Then trim and level-match before shipping, or short clips will sit quiet
against the long ones.

## Still to do

Stage 2 is now written and needs five more recordings: `sh`, `ch`, `th`,
`ng` and `ck`. Until they exist the app speaks them with the device voice,
which is noticeably worse than the 26 that are recorded — `th` especially.
Same folder, same naming: `sh.wav`, `ch.wav`, `th.wav`, `ng.wav`, `ck.wav`.

Generate them the same way as the first 26 (`tools/generate_phonemes.py`,
Azure Neural with IPA: ʃ, tʃ, θ, ŋ, k).

 without recording them

Two workable sources, in order of preference.

**1. Wikimedia Commons / Wiktionary IPA recordings** — public domain or CC,
made by linguists, and reusable commercially with attribution. Search for
the IPA symbol (`voiceless alveolar fricative` for /s/). Cleanest licence of
anything available.

**2. Freesound.org, pack "English Phonemes" by margo_heston**
`https://freesound.org/people/margo_heston/packs/12249/`
About 40 single-phoneme clips of exactly the right kind — "shh" as in
washboard, "vvv" as in very, "kss" as in box. A free account is needed to
download.

**Check the licence on every single file before you ship it.** Freesound
mixes CC0 (use freely), CC-BY (credit required — put it in the app's
about screen) and CC-BY-NC (**cannot be used**, because you are selling an
unlock). The licence is shown per sound, not per pack.

Avoid: YouTube rips, "free download" phonics sites, and anything from a
commercial phonics scheme. A children's app on a store with a paid unlock is
exactly the case where a rights holder will object.

**Honest recommendation:** record them yourself anyway. Thirty sounds is
about an hour, the voice will be consistent across every file, and you own
it outright. Sourced clips come from different mouths, rooms and microphones
and sound like a patchwork next to each other.

## Converting what you download

    # to the format the app expects
    ffmpeg -i shh.wav -ac 1 -ar 22050 -sample_fmt s16 sh.wav

    # trim silence at both ends
    ffmpeg -i sh.wav -af silenceremove=1:0:-50dB:1:0:-50dB sh_trimmed.wav
