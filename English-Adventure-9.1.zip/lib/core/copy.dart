import 'dart:math';

/// Every word the child sees or hears lives here.
///
/// One place to keep the voice warm, short and pressure-free — and one place
/// to translate later.
class Copy {
  static final _random = Random();

  // Buttons
  static const start = "Let's go!";
  static const next = 'Next';
  static const again = 'Again';
  static const hear = 'Hear it';
  static const backToMap = 'Back to the map';
  static const playAgain = 'Play again';
  static const grownUps = 'Grown-ups';
  static const keepGoing = 'Keep going';
  static const imDone = "I'm done!";

  // Encouragement after a correct or completed action
  static const _praise = [
    'Nice one!',
    'You did it!',
    'Wow!',
    'Super!',
    'Great listening!',
    'Look at you go!',
    'Brilliant!',
    'High five!',
  ];

  /// Gentle nudges. Never "wrong", never "no", never a red X.
  static const _nudges = [
    'Nearly! Try another one.',
    'Good try! Have another go.',
    'Hmm, keep looking!',
    'Almost there!',
    'That one is sleepy. Try again!',
  ];

  static const _hints = [
    'Listen again, then choose.',
    'The first sound helps!',
    'Say it slowly: push the sounds together.',
  ];

  static String praise() => _praise[_random.nextInt(_praise.length)];

  static String nudge() => _nudges[_random.nextInt(_nudges.length)];

  static String hint() => _hints[_random.nextInt(_hints.length)];

  // Writing
  static const watchMe = 'Watch how it is made.';
  static const yourTurnToWrite = 'Now you write it. Start on the green dot.';
  static const watchAgain = 'Let me show you again.';

  static String writingPraise(String letter, String name) => name.isEmpty
      ? 'You wrote $letter! ${praise()}'
      : 'You wrote $letter, $name!';

  // Reading
  static const listenFirst = 'Listen first. I will read it to you.';
  static const nowYouRead = 'Now you read it. Tap a word if you need me.';
  static const readAlone = 'Your turn. Read it on your own!';
  static const readItAgain = 'Let us read it again.';
  static const readToMe = 'Read it to me';
  static const listening = 'Listening...';
  static const iReadIt = 'I read it!';

  static String readingPraise(String name) =>
      name.isEmpty ? 'You read it! ${praise()}' : 'You read it, $name!';

  // Phonics class
  static const myTurn = 'My turn. Listen to the sound.';
  static const parrotIt = 'Parrot it back to me!';
  static const yourTurn = 'Your turn! Say it back to me.';
  static const iSaidIt = 'I said it!';

  // Stars
  static const touchTheStar = 'Touch your star!';

  static const _starLines = [
    'You earned a star!',
    'A star for you!',
    'Here is your star!',
    'Star!',
  ];

  static String starEarned() => _starLines[_random.nextInt(_starLines.length)];

  // Rewards
  static String rewardFound(String name) => 'You found the $name!';

  static const rewardSub = 'It goes in your treasure bag.';

  // Map
  static const mapTitle = 'English Adventure';

  static const lockedMessage = 'Finish the island before this one first!';

  /// Shown when a world needs the grown-up to unlock it. Never mentions
  /// money to the child.
  static const askAGrownUp = 'Ask a grown-up to open this world!';

  static String islandDone(String title) => '$title is all done!';
}
