import 'dart:math' as math;
import 'dart:ui' show Offset;

/// Hand-authored letter shapes in a unit square (0..1, y grows downward).
///
/// Each letter is a list of strokes; each stroke is an ordered list of guide
/// points. The tracing activity turns these into dots the child colours in
/// with a fingertip, so the shapes only need to be recognisable, not
/// typographically perfect.
///
/// Writing band: ascender 0.14, x-height top 0.42, baseline 0.82,
/// descender 0.97.
const double _xTop = 0.42;
const double _base = 0.82;
const double _asc = 0.14;
const double _desc = 0.97;
const double _pi = math.pi;

List<Offset> _line(Offset a, Offset b, {int steps = 14}) =>
    List<Offset>.generate(steps + 1, (i) => Offset.lerp(a, b, i / steps)!);

/// One continuous stroke through several points (used for v, w, x, y, z).
List<Offset> _poly(List<Offset> points, {int stepsPerLeg = 10}) {
  final result = <Offset>[];
  for (var i = 0; i < points.length - 1; i++) {
    final leg = _line(points[i], points[i + 1], steps: stepsPerLeg);
    result.addAll(i == 0 ? leg : leg.skip(1));
  }
  return result;
}

/// A smooth curve through the given points (Catmull-Rom).
///
/// Needed for letters like `s`, whose shape is one continuous sweep rather
/// than a set of circular arcs. Built from two arcs, an `s` comes out as two
/// disconnected bowls with no middle diagonal — it reads as a squashed 8,
/// which is exactly how it looked on a real device.
List<Offset> _curve(List<Offset> points, {int per = 10}) {
  final padded = <Offset>[points.first, ...points, points.last];
  final out = <Offset>[];

  for (var i = 0; i < padded.length - 3; i++) {
    final p0 = padded[i];
    final p1 = padded[i + 1];
    final p2 = padded[i + 2];
    final p3 = padded[i + 3];

    for (var j = 0; j <= per; j++) {
      final t = j / per;
      final t2 = t * t;
      final t3 = t2 * t;
      final x = 0.5 *
          ((2 * p1.dx) +
              (-p0.dx + p2.dx) * t +
              (2 * p0.dx - 5 * p1.dx + 4 * p2.dx - p3.dx) * t2 +
              (-p0.dx + 3 * p1.dx - 3 * p2.dx + p3.dx) * t3);
      final y = 0.5 *
          ((2 * p1.dy) +
              (-p0.dy + p2.dy) * t +
              (2 * p0.dy - 5 * p1.dy + 4 * p2.dy - p3.dy) * t2 +
              (-p0.dy + 3 * p1.dy - 3 * p2.dy + p3.dy) * t3);
      final point = Offset(x, y);
      if (out.isEmpty || (point - out.last).distance > 0.002) out.add(point);
    }
  }
  return out;
}

List<Offset> _arc(
  Offset center,
  double rx,
  double ry,
  double startAngle,
  double sweep, {
  int steps = 26,
}) =>
    List<Offset>.generate(steps + 1, (i) {
      final t = startAngle + sweep * (i / steps);
      return Offset(
        center.dx + rx * math.cos(t),
        center.dy + ry * math.sin(t),
      );
    });

/// Full lowercase alphabet, so any letter in the content can be traced.
final Map<String, List<List<Offset>>> letterStrokes = {
  'a': [
    _arc(const Offset(0.46, 0.62), 0.17, 0.20, -0.25 * _pi, -2.0 * _pi),
    _line(const Offset(0.63, _xTop), const Offset(0.63, _base)),
  ],
  'b': [
    _line(const Offset(0.34, _asc), const Offset(0.34, _base)),
    _arc(const Offset(0.52, 0.62), 0.18, 0.20, -0.5 * _pi, 2.0 * _pi),
  ],
  'c': [
    _arc(const Offset(0.52, 0.62), 0.18, 0.20, -0.25 * _pi, -1.5 * _pi),
  ],
  'd': [
    _arc(const Offset(0.44, 0.62), 0.17, 0.20, -0.25 * _pi, -2.0 * _pi),
    _line(const Offset(0.61, _asc), const Offset(0.61, _base)),
  ],
  'e': [
    _line(const Offset(0.33, 0.62), const Offset(0.68, 0.62)),
    _arc(const Offset(0.50, 0.62), 0.18, 0.20, 0, -1.6 * _pi),
  ],
  'f': [
    _line(const Offset(0.50, 0.27), const Offset(0.50, _base)),
    _arc(const Offset(0.62, 0.27), 0.12, 0.13, _pi, 0.8 * _pi, steps: 16),
    _line(const Offset(0.34, 0.45), const Offset(0.66, 0.45), steps: 10),
  ],
  'g': [
    _arc(const Offset(0.46, 0.62), 0.17, 0.20, -0.25 * _pi, -2.0 * _pi),
    _line(const Offset(0.63, _xTop), const Offset(0.63, 0.92)),
    _arc(const Offset(0.48, 0.92), 0.15, 0.06, 0, 0.9 * _pi, steps: 14),
  ],
  'h': [
    _line(const Offset(0.34, _asc), const Offset(0.34, _base)),
    _arc(const Offset(0.50, 0.55), 0.16, 0.13, _pi, _pi),
    _line(const Offset(0.66, 0.55), const Offset(0.66, _base)),
  ],
  'i': [
    _line(const Offset(0.50, _xTop), const Offset(0.50, _base)),
    _arc(const Offset(0.50, 0.28), 0.025, 0.025, 0, 2.0 * _pi, steps: 10),
  ],
  'j': [
    _line(const Offset(0.55, _xTop), const Offset(0.55, 0.88)),
    _arc(const Offset(0.42, 0.88), 0.13, 0.08, 0, 0.9 * _pi, steps: 16),
    _arc(const Offset(0.55, 0.28), 0.025, 0.025, 0, 2.0 * _pi, steps: 10),
  ],
  'k': [
    _line(const Offset(0.34, _asc), const Offset(0.34, _base)),
    _line(const Offset(0.68, 0.45), const Offset(0.36, 0.64), steps: 12),
    _line(const Offset(0.44, 0.58), const Offset(0.70, _base), steps: 12),
  ],
  'l': [
    _line(const Offset(0.50, _asc), const Offset(0.50, _base)),
  ],
  'm': [
    _line(const Offset(0.24, _xTop), const Offset(0.24, _base)),
    _arc(const Offset(0.37, 0.54), 0.13, 0.12, _pi, _pi, steps: 20),
    _line(const Offset(0.50, 0.54), const Offset(0.50, _base)),
    _arc(const Offset(0.63, 0.54), 0.13, 0.12, _pi, _pi, steps: 20),
    _line(const Offset(0.76, 0.54), const Offset(0.76, _base)),
  ],
  'n': [
    _line(const Offset(0.34, _xTop), const Offset(0.34, _base)),
    _arc(const Offset(0.50, 0.55), 0.16, 0.13, _pi, _pi),
    _line(const Offset(0.66, 0.55), const Offset(0.66, _base)),
  ],
  'o': [
    _arc(const Offset(0.50, 0.62), 0.18, 0.20, -0.5 * _pi, 2.0 * _pi),
  ],
  'p': [
    _line(const Offset(0.34, _xTop), const Offset(0.34, _desc)),
    _arc(const Offset(0.52, 0.62), 0.18, 0.20, -0.5 * _pi, 2.0 * _pi),
  ],
  'q': [
    _arc(const Offset(0.46, 0.62), 0.17, 0.20, -0.25 * _pi, -2.0 * _pi),
    _line(const Offset(0.63, _xTop), const Offset(0.63, _desc)),
  ],
  'r': [
    _line(const Offset(0.38, _xTop), const Offset(0.38, _base)),
    _arc(const Offset(0.52, 0.53), 0.14, 0.11, _pi, 0.7 * _pi, steps: 16),
  ],
  's': [
    _curve(const [
      Offset(0.66, 0.48),
      Offset(0.56, 0.43),
      Offset(0.42, 0.44),
      Offset(0.36, 0.52),
      Offset(0.46, 0.59),
      Offset(0.58, 0.65),
      Offset(0.64, 0.73),
      Offset(0.55, 0.80),
      Offset(0.38, 0.78),
      Offset(0.33, 0.72),
    ]),
  ],
  't': [
    _line(const Offset(0.50, 0.16), const Offset(0.50, _base)),
    _line(const Offset(0.33, _xTop), const Offset(0.67, _xTop), steps: 10),
  ],
  'u': [
    _line(const Offset(0.34, _xTop), const Offset(0.34, 0.72), steps: 10),
    _arc(const Offset(0.50, 0.72), 0.16, 0.10, _pi, -_pi, steps: 20),
    _line(const Offset(0.66, _xTop), const Offset(0.66, _base)),
  ],
  'v': [
    _poly(
      const [Offset(0.32, _xTop), Offset(0.50, _base), Offset(0.68, _xTop)],
      stepsPerLeg: 12,
    ),
  ],
  'w': [
    _poly(const [
      Offset(0.22, _xTop),
      Offset(0.35, _base),
      Offset(0.50, 0.55),
      Offset(0.65, _base),
      Offset(0.78, _xTop),
    ]),
  ],
  'x': [
    _line(const Offset(0.32, _xTop), const Offset(0.68, _base)),
    _line(const Offset(0.68, _xTop), const Offset(0.32, _base)),
  ],
  'y': [
    _line(const Offset(0.32, _xTop), const Offset(0.52, 0.72), steps: 12),
    _line(const Offset(0.70, _xTop), const Offset(0.38, _desc), steps: 18),
  ],
  'z': [
    _poly(const [
      Offset(0.32, 0.45),
      Offset(0.68, 0.45),
      Offset(0.32, 0.80),
      Offset(0.68, 0.80),
    ], stepsPerLeg: 12),
  ],
};

// ---------------------------------------------------------------------------
// Capitals
// ---------------------------------------------------------------------------
// Every sentence starts with one and every name has one, so a child who is
// only ever taught lowercase cannot read the text we ask them to read.
// Capitals sit between the cap line (0.14) and the baseline (0.82).

const double _cap = 0.14;

final Map<String, List<List<Offset>>> capitalStrokes = {
  'A': [
    _poly(const [Offset(0.24, _base), Offset(0.50, _cap), Offset(0.76, _base)],
        stepsPerLeg: 14),
    _line(const Offset(0.34, 0.60), const Offset(0.66, 0.60), steps: 10),
  ],
  'B': [
    _line(const Offset(0.30, _cap), const Offset(0.30, _base)),
    _arc(const Offset(0.30, 0.31), 0.21, 0.17, -0.5 * _pi, _pi, steps: 18),
    _arc(const Offset(0.30, 0.65), 0.24, 0.17, -0.5 * _pi, _pi, steps: 18),
  ],
  'C': [
    _arc(const Offset(0.52, 0.48), 0.22, 0.34, -0.28 * _pi, -1.44 * _pi),
  ],
  'D': [
    _line(const Offset(0.30, _cap), const Offset(0.30, _base)),
    _arc(const Offset(0.30, 0.48), 0.30, 0.34, -0.5 * _pi, _pi, steps: 22),
  ],
  'E': [
    _line(const Offset(0.32, _cap), const Offset(0.32, _base)),
    _line(const Offset(0.32, _cap), const Offset(0.70, _cap), steps: 10),
    _line(const Offset(0.32, 0.48), const Offset(0.64, 0.48), steps: 10),
    _line(const Offset(0.32, _base), const Offset(0.70, _base), steps: 10),
  ],
  'F': [
    _line(const Offset(0.32, _cap), const Offset(0.32, _base)),
    _line(const Offset(0.32, _cap), const Offset(0.70, _cap), steps: 10),
    _line(const Offset(0.32, 0.48), const Offset(0.64, 0.48), steps: 10),
  ],
  'G': [
    _arc(const Offset(0.52, 0.48), 0.22, 0.34, -0.28 * _pi, -1.44 * _pi),
    _line(const Offset(0.74, 0.50), const Offset(0.74, 0.62), steps: 8),
    _line(const Offset(0.56, 0.50), const Offset(0.74, 0.50), steps: 8),
  ],
  'H': [
    _line(const Offset(0.30, _cap), const Offset(0.30, _base)),
    _line(const Offset(0.70, _cap), const Offset(0.70, _base)),
    _line(const Offset(0.30, 0.48), const Offset(0.70, 0.48), steps: 10),
  ],
  'I': [
    _line(const Offset(0.50, _cap), const Offset(0.50, _base)),
    _line(const Offset(0.34, _cap), const Offset(0.66, _cap), steps: 8),
    _line(const Offset(0.34, _base), const Offset(0.66, _base), steps: 8),
  ],
  'J': [
    _line(const Offset(0.62, _cap), const Offset(0.62, 0.68), steps: 12),
    _arc(const Offset(0.44, 0.68), 0.18, 0.14, 0, 0.9 * _pi, steps: 14),
  ],
  'K': [
    _line(const Offset(0.30, _cap), const Offset(0.30, _base)),
    _line(const Offset(0.70, _cap), const Offset(0.32, 0.50), steps: 12),
    _line(const Offset(0.42, 0.42), const Offset(0.72, _base), steps: 12),
  ],
  'L': [
    _line(const Offset(0.34, _cap), const Offset(0.34, _base)),
    _line(const Offset(0.34, _base), const Offset(0.70, _base), steps: 10),
  ],
  'M': [
    _poly(const [
      Offset(0.22, _base),
      Offset(0.22, _cap),
      Offset(0.50, 0.56),
      Offset(0.78, _cap),
      Offset(0.78, _base),
    ]),
  ],
  'N': [
    _poly(const [
      Offset(0.28, _base),
      Offset(0.28, _cap),
      Offset(0.72, _base),
      Offset(0.72, _cap),
    ], stepsPerLeg: 12),
  ],
  'O': [
    _arc(const Offset(0.50, 0.48), 0.24, 0.34, -0.5 * _pi, 2.0 * _pi),
  ],
  'P': [
    _line(const Offset(0.32, _cap), const Offset(0.32, _base)),
    _arc(const Offset(0.32, 0.31), 0.24, 0.17, -0.5 * _pi, _pi, steps: 18),
  ],
  'Q': [
    _arc(const Offset(0.48, 0.48), 0.24, 0.34, -0.5 * _pi, 2.0 * _pi),
    _line(const Offset(0.56, 0.66), const Offset(0.78, 0.88), steps: 10),
  ],
  'R': [
    _line(const Offset(0.32, _cap), const Offset(0.32, _base)),
    _arc(const Offset(0.32, 0.31), 0.24, 0.17, -0.5 * _pi, _pi, steps: 18),
    _line(const Offset(0.40, 0.48), const Offset(0.72, _base), steps: 12),
  ],
  'S': [
    _curve(const [
      Offset(0.68, 0.25),
      Offset(0.56, 0.16),
      Offset(0.40, 0.19),
      Offset(0.33, 0.30),
      Offset(0.46, 0.42),
      Offset(0.60, 0.53),
      Offset(0.67, 0.65),
      Offset(0.57, 0.79),
      Offset(0.39, 0.80),
      Offset(0.31, 0.70),
    ]),
  ],
  'T': [
    _line(const Offset(0.30, _cap), const Offset(0.70, _cap), steps: 10),
    _line(const Offset(0.50, _cap), const Offset(0.50, _base)),
  ],
  'U': [
    _line(const Offset(0.30, _cap), const Offset(0.30, 0.66), steps: 12),
    _arc(const Offset(0.50, 0.66), 0.20, 0.16, _pi, -_pi, steps: 20),
    _line(const Offset(0.70, _cap), const Offset(0.70, 0.66), steps: 12),
  ],
  'V': [
    _poly(const [Offset(0.26, _cap), Offset(0.50, _base), Offset(0.74, _cap)],
        stepsPerLeg: 14),
  ],
  'W': [
    _poly(const [
      Offset(0.18, _cap),
      Offset(0.34, _base),
      Offset(0.50, 0.42),
      Offset(0.66, _base),
      Offset(0.82, _cap),
    ]),
  ],
  'X': [
    _line(const Offset(0.28, _cap), const Offset(0.72, _base)),
    _line(const Offset(0.72, _cap), const Offset(0.28, _base)),
  ],
  'Y': [
    _line(const Offset(0.28, _cap), const Offset(0.50, 0.48), steps: 10),
    _line(const Offset(0.72, _cap), const Offset(0.50, 0.48), steps: 10),
    _line(const Offset(0.50, 0.48), const Offset(0.50, _base), steps: 10),
  ],
  'Z': [
    _poly(const [
      Offset(0.28, _cap),
      Offset(0.72, _cap),
      Offset(0.28, _base),
      Offset(0.72, _base),
    ], stepsPerLeg: 12),
  ],
};

/// Strokes for a letter in either case.
///
/// Falls back to a gentle circle so a missing letter never crashes the app.
List<List<Offset>> strokesFor(String letter, {bool capital = false}) {
  if (capital) {
    return capitalStrokes[letter.toUpperCase()] ?? capitalStrokes['O']!;
  }
  return letterStrokes[letter.toLowerCase()] ?? letterStrokes['o']!;
}
