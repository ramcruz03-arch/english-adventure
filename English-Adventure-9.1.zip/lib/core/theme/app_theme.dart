import 'package:flutter/material.dart';

/// Bright, warm, high-contrast. Large type, round corners, big targets.
class AppColors {
  static const sky = Color(0xFF62C7F5);
  static const skyDeep = Color(0xFF2E9BD6);
  static const sand = Color(0xFFFFF2D8);
  static const sunshine = Color(0xFFFFB703);
  static const coral = Color(0xFFFF6B5B);
  static const mint = Color(0xFF2FD08D);
  static const grape = Color(0xFF8A5CF6);
  static const ink = Color(0xFF2B3A55);
  static const inkSoft = Color(0xFF6B7A99);
  static const cloud = Color(0xFFFFFFFF);
}

class AppRadii {
  static const card = 28.0;
  static const button = 999.0;
  static const tile = 22.0;
}

/// Minimum tap target for small fingers.
const double kChildTapTarget = 72.0;

ThemeData buildAppTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.sky,
      primary: AppColors.skyDeep,
      secondary: AppColors.sunshine,
    ),
    scaffoldBackgroundColor: AppColors.sand,
  );

  return base.copyWith(
    textTheme: base.textTheme
        .apply(bodyColor: AppColors.ink, displayColor: AppColors.ink)
        .copyWith(
          displayLarge: const TextStyle(
            fontSize: 96,
            fontWeight: FontWeight.w800,
            height: 1.05,
            color: AppColors.ink,
          ),
          headlineMedium: const TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w800,
            color: AppColors.ink,
          ),
          titleLarge: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w700,
            color: AppColors.ink,
          ),
          bodyLarge: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            height: 1.35,
            color: AppColors.ink,
          ),
          bodyMedium: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w500,
            color: AppColors.inkSoft,
          ),
        ),
    cardTheme: CardThemeData(
      color: AppColors.cloud,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
    ),
  );
}

/// The sky-to-sand backdrop used behind every screen.
class SeaSkyBackground extends StatelessWidget {
  const SeaSkyBackground({super.key, required this.child, this.tint});

  final Widget child;
  final Color? tint;

  @override
  Widget build(BuildContext context) {
    final top = tint ?? AppColors.sky;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            top.withValues(alpha: 0.85),
            top.withValues(alpha: 0.35),
            AppColors.sand,
          ],
          stops: const [0.0, 0.45, 1.0],
        ),
      ),
      child: child,
    );
  }
}
