import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Everything we remember about the child's journey.
///
/// Deliberately tiny and local: no accounts, no network, no personal data.
class ProgressState {
  const ProgressState({
    this.starsByLevel = const {},
    this.collectibles = const {},
    this.secondsByDay = const {},
    this.letterCounts = const {},
    this.soundOn = true,
    this.startWorld = 0,
    this.pinHash,
    this.childName = '',
    this.voiceRate = 0.42,
    this.dailyGoalMinutes = 10,
    this.unlockedFullVersion = false,
    this.openAllIslands = false,
    this.wordsRead = 0,
    this.passagesRead = 0,
    this.readingChecks = const [],
    this.codeChecks = const [],
    this.milestones = const [],
  });

  /// levelId -> best number of stars earned.
  final Map<String, int> starsByLevel;

  /// Collectible ids the child has found.
  final Set<String> collectibles;

  /// yyyy-MM-dd -> seconds played that day.
  final Map<String, int> secondsByDay;

  /// letter -> how many times it has been practised.
  final Map<String, int> letterCounts;

  final bool soundOn;

  /// Chosen by a grown-up during setup: worlds up to and including this one
  /// are open from the start. 0 means setup has not happened yet.
  final int startWorld;

  /// SHA-256 of the parent PIN, or null when no PIN has been set.
  final String? pinHash;

  bool get needsSetup => startWorld == 0;

  bool get hasPin => pinHash != null;

  /// Optional. Used only to say the child's name out loud; never leaves
  /// the device.
  final String childName;

  /// Text-to-speech rate. Lower is slower and clearer.
  final double voiceRate;

  /// A gentle target, not a limit. Nothing is ever cut off mid-activity.
  final int dailyGoalMinutes;

  /// True once the paid worlds have been unlocked on this device.
  final bool unlockedFullVersion;

  /// Total words of connected text the child has read. The single best
  /// everyday indicator of reading growth, and nothing else counts it.
  final int wordsRead;

  final int passagesRead;

  /// One-minute timed reads, run by a parent. Oldest first.
  final List<ReadingCheck> readingChecks;

  /// Nonsense-word decoding checks. Nonsense words cannot be memorised, so
  /// they prove decoding rather than recall.
  final List<CodeCheck> codeChecks;

  /// Moments worth remembering: "read Max the Fox with no help".
  final List<Milestone> milestones;

  ReadingCheck? get latestCheck =>
      readingChecks.isEmpty ? null : readingChecks.last;

  /// Words correct per minute over time, oldest first.
  List<int> get wcpmHistory => readingChecks.map((c) => c.wcpm).toList();

  /// Lets a grown-up open every island so a child (or they) can pick
  /// freely, instead of only ever playing the next one in order.
  final bool openAllIslands;

  /// Worlds 1 and 2 are always free.
  static const int freeWorlds = 2;

  bool isWorldPaid(int worldIndex) =>
      worldIndex > freeWorlds && !unlockedFullVersion;

  int get secondsToday =>
      secondsByDay[_dayKey(DateTime.now())] ?? 0;

  bool get metGoalToday => secondsToday >= dailyGoalMinutes * 60;

  int get totalStars =>
      starsByLevel.values.fold(0, (sum, stars) => sum + stars);

  int get islandsFinished => starsByLevel.length;

  bool isFinished(String levelId) => starsByLevel.containsKey(levelId);

  int starsFor(String levelId) => starsByLevel[levelId] ?? 0;

  int get secondsThisWeek {
    final today = DateTime.now();
    var total = 0;
    for (var i = 0; i < 7; i++) {
      total += secondsByDay[_dayKey(today.subtract(Duration(days: i)))] ?? 0;
    }
    return total;
  }

  /// Seconds played for each of the last 7 days, oldest first.
  List<int> get weeklySeconds {
    final today = DateTime.now();
    return List<int>.generate(7, (i) {
      final day = today.subtract(Duration(days: 6 - i));
      return secondsByDay[_dayKey(day)] ?? 0;
    });
  }

  ProgressState copyWith({
    Map<String, int>? starsByLevel,
    Set<String>? collectibles,
    Map<String, int>? secondsByDay,
    Map<String, int>? letterCounts,
    bool? soundOn,
    int? startWorld,
    String? pinHash,
    bool clearPin = false,
    String? childName,
    double? voiceRate,
    int? dailyGoalMinutes,
    bool? unlockedFullVersion,
    bool? openAllIslands,
    int? wordsRead,
    int? passagesRead,
    List<ReadingCheck>? readingChecks,
    List<CodeCheck>? codeChecks,
    List<Milestone>? milestones,
  }) {
    return ProgressState(
      starsByLevel: starsByLevel ?? this.starsByLevel,
      collectibles: collectibles ?? this.collectibles,
      secondsByDay: secondsByDay ?? this.secondsByDay,
      letterCounts: letterCounts ?? this.letterCounts,
      soundOn: soundOn ?? this.soundOn,
      startWorld: startWorld ?? this.startWorld,
      pinHash: clearPin ? null : (pinHash ?? this.pinHash),
      childName: childName ?? this.childName,
      voiceRate: voiceRate ?? this.voiceRate,
      dailyGoalMinutes: dailyGoalMinutes ?? this.dailyGoalMinutes,
      unlockedFullVersion: unlockedFullVersion ?? this.unlockedFullVersion,
      openAllIslands: openAllIslands ?? this.openAllIslands,
      wordsRead: wordsRead ?? this.wordsRead,
      passagesRead: passagesRead ?? this.passagesRead,
      readingChecks: readingChecks ?? this.readingChecks,
      codeChecks: codeChecks ?? this.codeChecks,
      milestones: milestones ?? this.milestones,
    );
  }

  Map<String, dynamic> toJson() => {
    'starsByLevel': starsByLevel,
    'collectibles': collectibles.toList(),
    'secondsByDay': secondsByDay,
    'letterCounts': letterCounts,
    'soundOn': soundOn,
    'startWorld': startWorld,
    'pinHash': pinHash,
    'childName': childName,
    'voiceRate': voiceRate,
    'dailyGoalMinutes': dailyGoalMinutes,
    'unlockedFullVersion': unlockedFullVersion,
    'openAllIslands': openAllIslands,
    'wordsRead': wordsRead,
    'passagesRead': passagesRead,
    'readingChecks': readingChecks.map((c) => c.toJson()).toList(),
    'codeChecks': codeChecks.map((c) => c.toJson()).toList(),
    'milestones': milestones.map((m) => m.toJson()).toList(),
  };

  factory ProgressState.fromJson(Map<String, dynamic> json) => ProgressState(
    starsByLevel: _intMap(json['starsByLevel']),
    collectibles: ((json['collectibles'] as List<dynamic>?) ?? const [])
        .map((e) => e as String)
        .toSet(),
    secondsByDay: _intMap(json['secondsByDay']),
    letterCounts: _intMap(json['letterCounts']),
    soundOn: json['soundOn'] as bool? ?? true,
    startWorld: (json['startWorld'] as num?)?.toInt() ?? 0,
    pinHash: json['pinHash'] as String?,
    childName: json['childName'] as String? ?? '',
    voiceRate: (json['voiceRate'] as num?)?.toDouble() ?? 0.42,
    dailyGoalMinutes: (json['dailyGoalMinutes'] as num?)?.toInt() ?? 10,
    unlockedFullVersion: json['unlockedFullVersion'] as bool? ?? false,
    openAllIslands: json['openAllIslands'] as bool? ?? false,
    wordsRead: (json['wordsRead'] as num?)?.toInt() ?? 0,
    passagesRead: (json['passagesRead'] as num?)?.toInt() ?? 0,
    readingChecks: ((json['readingChecks'] as List<dynamic>?) ?? const [])
        .map((e) => ReadingCheck.fromJson(e as Map<String, dynamic>))
        .toList(),
    codeChecks: ((json['codeChecks'] as List<dynamic>?) ?? const [])
        .map((e) => CodeCheck.fromJson(e as Map<String, dynamic>))
        .toList(),
    milestones: ((json['milestones'] as List<dynamic>?) ?? const [])
        .map((e) => Milestone.fromJson(e as Map<String, dynamic>))
        .toList(),
  );

  static Map<String, int> _intMap(Object? raw) {
    if (raw is! Map) return const {};
    return raw.map((key, value) =>
        MapEntry(key.toString(), (value as num?)?.toInt() ?? 0));
  }

  static String _dayKey(DateTime date) {
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '${date.year}-$month-$day';
  }
}

class ProgressController extends StateNotifier<ProgressState> {
  ProgressController(this._prefs) : super(const ProgressState()) {
    _load();
  }

  static const String _key = 'progress_v1';

  final SharedPreferences _prefs;

  void _load() {
    final raw = _prefs.getString(_key);
    if (raw == null) return;
    try {
      state = ProgressState.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      // Corrupt data should never block a child from playing.
      state = const ProgressState();
    }
  }

  Future<void> _save() => _prefs.setString(_key, jsonEncode(state.toJson()));

  /// Keeps the child's best result; replays never take stars away.
  Future<void> finishLevel({
    required String levelId,
    required int stars,
    required String collectibleId,
  }) async {
    final best = <String, int>{...state.starsByLevel};
    final current = best[levelId] ?? 0;
    best[levelId] = stars > current ? stars : current;

    state = state.copyWith(
      starsByLevel: best,
      collectibles: {...state.collectibles, collectibleId},
    );
    await _save();
  }

  Future<void> notePractice(List<String> letters) async {
    final counts = <String, int>{...state.letterCounts};
    for (final letter in letters) {
      final clean = letter.trim().toLowerCase();
      if (clean.isEmpty) continue;
      counts[clean] = (counts[clean] ?? 0) + 1;
    }
    state = state.copyWith(letterCounts: counts);
    await _save();
  }

  Future<void> addPlaySeconds(int seconds) async {
    if (seconds <= 0) return;
    final key = ProgressState._dayKey(DateTime.now());
    final byDay = <String, int>{...state.secondsByDay};
    byDay[key] = (byDay[key] ?? 0) + seconds;
    state = state.copyWith(secondsByDay: byDay);
    await _save();
  }

  Future<void> setSound(bool enabled) async {
    state = state.copyWith(soundOn: enabled);
    await _save();
  }

  Future<void> setChildName(String name) async {
    state = state.copyWith(childName: name.trim());
    await _save();
  }

  Future<void> setVoiceRate(double rate) async {
    state = state.copyWith(voiceRate: rate);
    await _save();
  }

  Future<void> setDailyGoal(int minutes) async {
    state = state.copyWith(dailyGoalMinutes: minutes);
    await _save();
  }

  /// Called after a successful purchase or a restore.
  Future<void> setUnlocked(bool unlocked) async {
    state = state.copyWith(unlockedFullVersion: unlocked);
    await _save();
  }

  /// Clears the stars for one world so a child can play it fresh.
  Future<void> resetWorld(Iterable<String> levelIds) async {
    final stars = <String, int>{...state.starsByLevel};
    for (final id in levelIds) {
      stars.remove(id);
    }
    state = state.copyWith(starsByLevel: stars);
    await _save();
  }

  /// Called when a passage is finished. This is reading volume, the number
  /// that tracks growth better than minutes played.
  Future<void> recordReading(int words) async {
    state = state.copyWith(
      wordsRead: state.wordsRead + words,
      passagesRead: state.passagesRead + 1,
    );
    await _save();
  }

  Future<void> addMilestone(String text) async {
    final entry = Milestone(date: DateTime.now(), text: text);
    // Keep the most recent 30 so the file cannot grow without limit.
    final all = [...state.milestones, entry];
    state = state.copyWith(
      milestones: all.length > 30 ? all.sublist(all.length - 30) : all,
    );
    await _save();
  }

  Future<void> recordReadingCheck(int wcpm) async {
    state = state.copyWith(
      readingChecks: [
        ...state.readingChecks,
        ReadingCheck(date: DateTime.now(), wcpm: wcpm),
      ],
    );
    await _save();
  }

  Future<void> recordCodeCheck(int correct, int total) async {
    state = state.copyWith(
      codeChecks: [
        ...state.codeChecks,
        CodeCheck(date: DateTime.now(), correct: correct, total: total),
      ],
    );
    await _save();
  }

  Future<void> setOpenAllIslands(bool open) async {
    state = state.copyWith(openAllIslands: open);
    await _save();
  }

  Future<void> setStartWorld(int world) async {
    state = state.copyWith(startWorld: world);
    await _save();
  }

  static String hashPin(String pin) =>
      sha256.convert(utf8.encode('pip-salt-$pin')).toString();

  Future<void> setPin(String pin) async {
    state = state.copyWith(pinHash: hashPin(pin));
    await _save();
  }

  bool checkPin(String pin) => state.pinHash == hashPin(pin);

  Future<void> clearPin() async {
    state = state.copyWith(clearPin: true);
    await _save();
  }

  /// Clears play progress. Keeps the sound setting, the PIN and the chosen
  /// starting world so a grown-up does not have to set those up again.
  Future<void> resetEverything() async {
    state = ProgressState(
      soundOn: state.soundOn,
      startWorld: state.startWorld,
      pinHash: state.pinHash,
      childName: state.childName,
      voiceRate: state.voiceRate,
      dailyGoalMinutes: state.dailyGoalMinutes,
      unlockedFullVersion: state.unlockedFullVersion,
      openAllIslands: state.openAllIslands,
      readingChecks: state.readingChecks,
      codeChecks: state.codeChecks,
    );
    await _save();
  }
}

/// A one-minute timed read, scored by a parent.
class ReadingCheck {
  const ReadingCheck({required this.date, required this.wcpm});

  final DateTime date;

  /// Words correct per minute. Around 40 is the point at which a beginning
  /// reader is considered to be at low risk of difficulty.
  final int wcpm;

  Map<String, dynamic> toJson() => {
    'date': date.toIso8601String(),
    'wcpm': wcpm,
  };

  factory ReadingCheck.fromJson(Map<String, dynamic> json) => ReadingCheck(
    date: DateTime.tryParse(json['date'] as String? ?? '') ?? DateTime.now(),
    wcpm: (json['wcpm'] as num?)?.toInt() ?? 0,
  );
}

/// A nonsense-word decoding check.
class CodeCheck {
  const CodeCheck({
    required this.date,
    required this.correct,
    required this.total,
  });

  final DateTime date;
  final int correct;
  final int total;

  Map<String, dynamic> toJson() => {
    'date': date.toIso8601String(),
    'correct': correct,
    'total': total,
  };

  factory CodeCheck.fromJson(Map<String, dynamic> json) => CodeCheck(
    date: DateTime.tryParse(json['date'] as String? ?? '') ?? DateTime.now(),
    correct: (json['correct'] as num?)?.toInt() ?? 0,
    total: (json['total'] as num?)?.toInt() ?? 0,
  );
}

class Milestone {
  const Milestone({required this.date, required this.text});

  final DateTime date;
  final String text;

  Map<String, dynamic> toJson() => {
    'date': date.toIso8601String(),
    'text': text,
  };

  factory Milestone.fromJson(Map<String, dynamic> json) => Milestone(
    date: DateTime.tryParse(json['date'] as String? ?? '') ?? DateTime.now(),
    text: json['text'] as String? ?? '',
  );
}
