import 'dart:async';

import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';

import 'sfx_service.dart';

/// All spoken audio.
///
/// Three things were wrong with the old version, and all three showed up as
/// "the voice is unclear":
///
/// 1. **Every line cut off the one before it.** `say()` called `stop()`
///    first, so a praise line spoken while an instruction was still playing
///    truncated it mid-word. Lines are now queued and spoken in order.
/// 2. **Letter sounds were spoken at sentence speed.** A phoneme needs to
///    be slower and more separated than running speech; it now drops the
///    rate for the phoneme and restores it afterwards.
/// 3. **No voice was ever chosen.** The device default is often a fast,
///    thin voice. We now look for a good English voice and prefer it.
class SpeechService {
  final FlutterTts _tts = FlutterTts();

  bool _ready = false;
  bool _available = true;
  bool enabled = true;

  double _rate = 0.42;

  /// Serialises speech so lines never talk over each other.
  Future<void> _queue = Future<void>.value();

  /// Bumped whenever we abandon queued speech. Anything queued under an old
  /// generation is dropped rather than spoken, which is what stops a line
  /// from an activity the child has already finished arriving over the top
  /// of the next one.
  int _generation = 0;

  /// Optional recorded phonemes. Used when a recording exists.
  SfxService? sfx;

  /// False when the device has no usable text-to-speech voice, so the parent
  /// area can say so instead of the app being mysteriously silent.
  bool get voiceAvailable => _available;

  set rate(double value) {
    if ((value - _rate).abs() < 0.01) return;
    _rate = value;
    _apply(_rate);
  }

  Future<void> _apply(double rate) async {
    try {
      await _tts.setSpeechRate(rate);
    } catch (_) {}
  }

  Future<void> init() async {
    if (_ready) return;
    try {
      await _tts.setLanguage('en-US');
      await _tts.awaitSpeakCompletion(true);
      await _tts.setSpeechRate(_rate);
      await _tts.setPitch(1.12);
      await _tts.setVolume(1.0);
      await _pickBestVoice();
      _ready = true;
      _available = true;
    } catch (_) {
      _ready = false;
      _available = false;
    }
  }

  /// Prefers a natural-sounding English voice over the device default.
  ///
  /// Names vary wildly by device, so this scores what is on offer rather
  /// than asking for one by name, and silently keeps the default if nothing
  /// scores well.
  Future<void> _pickBestVoice() async {
    try {
      final voices = await _tts.getVoices;
      if (voices is! List) return;

      Map<String, String>? best;
      var bestScore = -1;

      for (final raw in voices) {
        if (raw is! Map) continue;
        final name = (raw['name'] ?? '').toString().toLowerCase();
        final locale = (raw['locale'] ?? '').toString().toLowerCase();
        if (!locale.startsWith('en')) continue;

        var score = 0;
        // Local voices do not need a network connection.
        if (name.contains('local')) score += 3;
        // Higher-quality synthesis on most Android builds.
        if (name.contains('neural') || name.contains('enhanced')) score += 4;
        if (name.contains('female') || name.endsWith('-f')) score += 1;
        if (locale.startsWith('en-gb') || locale.startsWith('en-us')) {
          score += 2;
        }
        // en-IN reads Indian names far better; prefer it when present.
        if (locale.startsWith('en-in')) score += 2;

        if (score > bestScore) {
          bestScore = score;
          best = {
            'name': (raw['name'] ?? '').toString(),
            'locale': (raw['locale'] ?? '').toString(),
          };
        }
      }

      if (best != null && bestScore > 0) await _tts.setVoice(best);
    } catch (_) {
      // Any device that dislikes this keeps its default voice.
    }
  }

  /// Speaks [text], after anything already queued.
  Future<void> say(String text) {
    if (!enabled || text.trim().isEmpty) return Future<void>.value();
    return _enqueue(() => _speak(text));
  }

  /// Speaks immediately, dropping anything queued. For a child's own tap,
  /// where waiting would feel broken.
  Future<void> sayNow(String text) async {
    if (!enabled || text.trim().isEmpty) return;
    await interrupt();
    await _speak(text);
  }

  /// Turns a line into the filename a pre-generated clip would use.
  ///
  /// "You did it!" -> you-did-it
  static String slugFor(String text) {
    final cleaned = text
        .toLowerCase()
        .replaceAll(RegExp('[^a-z0-9]+'), '-')
        .replaceAll(RegExp(r'^-+|-+$'), '');
    return cleaned.length > 60 ? cleaned.substring(0, 60) : cleaned;
  }

  Future<void> _speak(String text) async {
    // Prefer a recorded or pre-generated clip. It sounds the same on every
    // device, which the device's own voice never does.
    if (await sfx?.playVoice(slugFor(text)) ?? false) return;

    await init();
    if (!_available) return;
    try {
      await _tts.speak(text);
    } catch (_) {}
  }

  Future<void> _enqueue(Future<void> Function() action) {
    final generation = _generation;
    final next = _queue.then((_) {
      if (generation != _generation) return null; // abandoned
      return action();
    }).catchError((_) {});
    _queue = next;
    return next;
  }

  /// Stops immediately and throws away anything still waiting.
  ///
  /// Called when an activity ends or a screen closes, so speech never
  /// carries over into what the child is doing next.
  Future<void> interrupt() async {
    _generation++;
    _queue = Future<void>.value();
    await sfx?.stopVoice();
    await stop();
  }

  // ------------------------------------------------------------------
  // Phonics
  // ------------------------------------------------------------------

  /// Spellings that make a text-to-speech engine produce the *sound* rather
  /// than the letter name. Getting these right is most of what "clear
  /// voiceover" means in a phonics app.
  static const Map<String, String> _phonemeSpelling = {
    's': 'sss', 'a': 'ah', 't': 'tuh', 'p': 'puh', 'i': 'ihh',
    'n': 'nnn', 'm': 'mmm', 'd': 'duh', 'g': 'guh', 'o': 'awh',
    'c': 'kuh', 'k': 'kuh', 'e': 'ehh', 'u': 'uhh', 'r': 'rrr',
    'h': 'huh', 'b': 'buh', 'f': 'fff', 'l': 'lll', 'j': 'juh',
    'v': 'vvv', 'w': 'wuh', 'y': 'yuh', 'z': 'zzz', 'qu': 'kwuh',
    'x': 'ks', 'sh': 'shhh', 'ch': 'ch', 'th': 'th', 'ng': 'ng',
  };

  static String spellingFor(String grapheme, {String? fallback}) =>
      _phonemeSpelling[grapheme.toLowerCase()] ?? fallback ?? grapheme;

  /// Says a single sound, slower and lower than running speech.
  Future<void> sayPhoneme(String grapheme, {String? sound}) {
    if (!enabled) return Future<void>.value();
    final spoken = spellingFor(grapheme, fallback: sound);

    return _enqueue(() async {
      // A real recording beats anything a speech engine can do with an
      // isolated sound, so use one if it has been added.
      // playPhoneme waits for the clip to finish, so nothing else is needed.
      if (await sfx?.playPhoneme(grapheme) ?? false) return;

      await init();
      if (!_available) return;

      // Slower, and at a flat pitch: a raised pitch smears a short sound.
      await _apply(_rate * 0.7);
      try {
        await _tts.setPitch(1.0);
        await _tts.speak(spoken);
        await _tts.setPitch(1.12);
      } catch (_) {}
      await _apply(_rate);
    });
  }

  /// Sounds a word out and then says it whole: "mmm... aah... tuh... mat!"
  ///
  /// This is what a teacher does at the front of a phonics class, and it is
  /// the single most useful thing the voice can model.
  Future<void> sayBlend(String word, {List<String>? graphemes}) {
    if (!enabled) return Future<void>.value();
    final parts = graphemes ?? word.split('');

    return _enqueue(() async {
      await init();
      if (!_available) return;

      await _apply(_rate * 0.7);
      for (final part in parts) {
        try {
          await _tts.speak(spellingFor(part));
        } catch (_) {}
        await Future<void>.delayed(const Duration(milliseconds: 260));
      }
      await _apply(_rate);
      try {
        await _tts.speak(word);
      } catch (_) {}
    });
  }

  /// A word, then its letters slowly, then the word again.
  Future<void> sayWordThenLetters(String word) => _enqueue(() async {
        await init();
        if (!_available) return;
        try {
          await _tts.speak(word);
          await _apply(_rate * 0.72);
          for (final letter in word.split('')) {
            await _tts.speak(spellingFor(letter));
            await Future<void>.delayed(const Duration(milliseconds: 200));
          }
          await _apply(_rate);
          await _tts.speak(word);
        } catch (_) {}
      });

  /// Used by the parent area's "test the voice" button.
  Future<void> test() =>
      sayNow('Hello! This is how I sound. The cat sat on the mat.');

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }

  void cheerHaptic() => HapticFeedback.mediumImpact();

  void softHaptic() => HapticFeedback.selectionClick();
}
