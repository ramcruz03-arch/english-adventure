import 'dart:async';

import 'package:in_app_purchase/in_app_purchase.dart';

/// The one-time unlock for Worlds 3–6.
///
/// Create this exact product id in the Play Console as a **one-time**
/// (non-consumable) in-app product before release.
const String kFullVersionProductId = 'english_adventure_full';

/// Result of an attempted purchase, in terms the UI can act on.
enum PurchaseOutcome { success, cancelled, pending, unavailable, error }

class PurchaseResult {
  const PurchaseResult(this.outcome, [this.message]);

  final PurchaseOutcome outcome;
  final String? message;
}

/// Thin wrapper over `in_app_purchase`.
///
/// Everything is defensive on purpose: if the store is missing, the product
/// has not been published yet, or billing errors out, the app keeps working
/// and simply reports that the unlock is unavailable. A child must never see
/// a crash or a raw billing error.
class PurchaseService {
  PurchaseService();

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _subscription;

  ProductDetails? _product;

  /// Price string for the UI, e.g. "₹399.00". Null until [loadProduct] runs.
  String? get priceLabel => _product?.price;

  Future<bool> isAvailable() async {
    try {
      return await _iap.isAvailable();
    } catch (_) {
      return false;
    }
  }

  /// Looks up the product so the paywall can show the real localised price.
  Future<bool> loadProduct() async {
    try {
      if (!await isAvailable()) return false;
      final response =
          await _iap.queryProductDetails({kFullVersionProductId});
      if (response.productDetails.isEmpty) return false;
      _product = response.productDetails.first;
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Starts a purchase and completes when the store reports back.
  ///
  /// [onUnlocked] fires for a successful purchase *or* a restore, so the
  /// caller can persist the entitlement in one place.
  Future<PurchaseResult> buy({required Future<void> Function() onUnlocked}) async {
    if (_product == null && !await loadProduct()) {
      return const PurchaseResult(
        PurchaseOutcome.unavailable,
        'The unlock is not available on this device yet.',
      );
    }

    final completer = Completer<PurchaseResult>();

    await _subscription?.cancel();
    _subscription = _iap.purchaseStream.listen((purchases) async {
      for (final purchase in purchases) {
        if (purchase.productID != kFullVersionProductId) continue;

        switch (purchase.status) {
          case PurchaseStatus.pending:
            // Waiting on the store sheet or a slow payment method.
            break;
          case PurchaseStatus.purchased:
          case PurchaseStatus.restored:
            await onUnlocked();
            if (purchase.pendingCompletePurchase) {
              await _iap.completePurchase(purchase);
            }
            if (!completer.isCompleted) {
              completer.complete(
                const PurchaseResult(PurchaseOutcome.success),
              );
            }
          case PurchaseStatus.canceled:
            if (!completer.isCompleted) {
              completer.complete(
                const PurchaseResult(PurchaseOutcome.cancelled),
              );
            }
          case PurchaseStatus.error:
            if (!completer.isCompleted) {
              completer.complete(
                PurchaseResult(
                  PurchaseOutcome.error,
                  purchase.error?.message ?? 'The purchase did not complete.',
                ),
              );
            }
        }
      }
    });

    try {
      await _iap.buyNonConsumable(
        purchaseParam: PurchaseParam(productDetails: _product!),
      );
    } catch (error) {
      return PurchaseResult(PurchaseOutcome.error, error.toString());
    }

    // Never hang the UI forever if the store goes quiet.
    return completer.future.timeout(
      const Duration(minutes: 3),
      onTimeout: () => const PurchaseResult(
        PurchaseOutcome.pending,
        'Still waiting on the store. If payment goes through, use Restore.',
      ),
    );
  }

  /// Re-applies a previous purchase on a new device or after a reinstall.
  Future<PurchaseResult> restore({
    required Future<void> Function() onUnlocked,
  }) async {
    if (!await isAvailable()) {
      return const PurchaseResult(
        PurchaseOutcome.unavailable,
        'The store is not available on this device.',
      );
    }

    final completer = Completer<PurchaseResult>();

    await _subscription?.cancel();
    _subscription = _iap.purchaseStream.listen((purchases) async {
      for (final purchase in purchases) {
        if (purchase.productID != kFullVersionProductId) continue;
        if (purchase.status == PurchaseStatus.restored ||
            purchase.status == PurchaseStatus.purchased) {
          await onUnlocked();
          if (purchase.pendingCompletePurchase) {
            await _iap.completePurchase(purchase);
          }
          if (!completer.isCompleted) {
            completer.complete(const PurchaseResult(PurchaseOutcome.success));
          }
        }
      }
    });

    try {
      await _iap.restorePurchases();
    } catch (error) {
      return PurchaseResult(PurchaseOutcome.error, error.toString());
    }

    return completer.future.timeout(
      const Duration(seconds: 20),
      onTimeout: () => const PurchaseResult(
        PurchaseOutcome.unavailable,
        'No earlier purchase was found for this Google account.',
      ),
    );
  }

  void dispose() {
    _subscription?.cancel();
  }
}
