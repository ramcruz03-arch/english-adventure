import 'package:flutter/material.dart';

import '../core/theme/app_theme.dart';

/// A row of stars. Empty stars are soft grey outlines — never red, never a
/// cross.
class StarRow extends StatelessWidget {
  const StarRow({
    super.key,
    required this.earned,
    required this.total,
    this.size = 26,
  });

  final int earned;
  final int total;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List<Widget>.generate(total, (i) {
        final filled = i < earned;
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: AnimatedScale(
            scale: filled ? 1.0 : 0.85,
            duration: const Duration(milliseconds: 250),
            child: Icon(
              filled ? Icons.star_rounded : Icons.star_outline_rounded,
              size: size,
              color: filled
                  ? AppColors.sunshine
                  : AppColors.inkSoft.withValues(alpha: 0.35),
            ),
          ),
        );
      }),
    );
  }
}

/// Dots showing where the child is inside an island. No numbers, no percent.
class StepDots extends StatelessWidget {
  const StepDots({
    super.key,
    required this.count,
    required this.current,
    this.color = AppColors.skyDeep,
  });

  final int count;
  final int current;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List<Widget>.generate(count, (i) {
        final done = i <= current;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: i == current ? 30 : 14,
          height: 14,
          decoration: BoxDecoration(
            color: done ? color : color.withValues(alpha: 0.25),
            borderRadius: BorderRadius.circular(8),
          ),
        );
      }),
    );
  }
}

/// The star counter shown in the top corner of the map.
class StarPill extends StatelessWidget {
  const StarPill({super.key, required this.stars});

  final int stars;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.button),
        boxShadow: [
          BoxShadow(
            color: AppColors.ink.withValues(alpha: 0.12),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star_rounded, color: AppColors.sunshine, size: 26),
          const SizedBox(width: 6),
          Text(
            '$stars',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
            ),
          ),
        ],
      ),
    );
  }
}
