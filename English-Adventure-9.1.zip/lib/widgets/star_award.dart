import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/copy.dart';
import '../core/providers.dart';
import '../core/theme/app_theme.dart';

/// The star a child earns for finishing an activity.
///
/// It arrives with a chime, waits to be touched, and when touched it glows,
/// rings and scatters sparks. Waiting for the touch is the point: the child
/// does something to collect the reward instead of watching it happen, and
/// it gives a natural pause between activities.
///
/// It never blocks: if nobody taps, it drifts up to the star counter by
/// itself after a few seconds.
Future<void> showStarAward(BuildContext context, WidgetRef ref) async {
  final overlay = Overlay.maybeOf(context);
  if (overlay == null) return;

  final completer = Completer<void>();
  late OverlayEntry entry;

  entry = OverlayEntry(
    builder: (_) => _StarAward(
      onFinished: () {
        if (entry.mounted) entry.remove();
        if (!completer.isCompleted) completer.complete();
      },
      onDisposed: () {
        if (!completer.isCompleted) completer.complete();
      },
      ref: ref,
    ),
  );

  overlay.insert(entry);

  // Never let the reward block the lesson. If anything goes wrong — the
  // overlay is torn down by a navigation, an animation is cut short — the
  // wait ends by itself instead of freezing the app on a finished activity.
  return completer.future.timeout(
    const Duration(seconds: 8),
    onTimeout: () {
      if (entry.mounted) entry.remove();
    },
  );
}

class _StarAward extends StatefulWidget {
  const _StarAward({
    required this.onFinished,
    required this.onDisposed,
    required this.ref,
  });

  final VoidCallback onFinished;
  final VoidCallback onDisposed;
  final WidgetRef ref;

  @override
  State<_StarAward> createState() => _StarAwardState();
}

class _StarAwardState extends State<_StarAward>
    with TickerProviderStateMixin {
  late final AnimationController _arrive = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 600),
  )..forward();

  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1200),
  )..repeat(reverse: true);

  late final AnimationController _touch = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );

  bool _touched = false;

  @override
  void initState() {
    super.initState();
    // Chime only: the activity has just spoken its praise line, and a
    // second spoken line on top of it is what made the voice feel laggy.
    widget.ref.read(sfxProvider).starAward();

    // Nobody has to tap: collect it for them after a moment.
    Future<void>.delayed(const Duration(milliseconds: 2600), () {
      if (mounted && !_touched) _collect();
    });
  }

  @override
  void dispose() {
    // If this is torn down before the star is collected, release whoever is
    // waiting on it rather than leaving them hanging.
    widget.onDisposed();
    _arrive.dispose();
    _pulse.dispose();
    _touch.dispose();
    super.dispose();
  }

  Future<void> _collect() async {
    if (_touched) return;
    setState(() => _touched = true);

    final sfx = widget.ref.read(sfxProvider);
    final speech = widget.ref.read(speechProvider);
    sfx.starTouch();
    speech.cheerHaptic();

    _pulse.stop();
    await _touch.forward();
    await Future<void>.delayed(const Duration(milliseconds: 120));
    widget.onFinished();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.35),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _collect,
        child: Center(
          child: AnimatedBuilder(
            animation: Listenable.merge([_arrive, _pulse, _touch]),
            builder: (context, _) {
              final arrive = Curves.elasticOut.transform(
                _arrive.value.clamp(0.0, 1.0),
              );
              final pulse = _touched ? 0.0 : _pulse.value;
              final burst = _touch.value;

              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 260,
                    height: 260,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Sparks, only once it has been touched.
                        if (burst > 0)
                          CustomPaint(
                            size: const Size(260, 260),
                            painter: _SparkPainter(burst),
                          ),
                        // The glow behind the star.
                        Container(
                          width: 150 + pulse * 20 + burst * 90,
                          height: 150 + pulse * 20 + burst * 90,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                AppColors.sunshine.withValues(
                                  alpha: (0.55 + pulse * 0.25) *
                                      (1 - burst * 0.8),
                                ),
                                AppColors.sunshine.withValues(alpha: 0),
                              ],
                            ),
                          ),
                        ),
                        Transform.scale(
                          scale: arrive * (1 + pulse * 0.06 + burst * 0.5),
                          child: Opacity(
                            opacity: (1 - burst).clamp(0.0, 1.0),
                            child: const Icon(
                              Icons.star_rounded,
                              size: 132,
                              color: AppColors.sunshine,
                              shadows: [
                                Shadow(
                                  color: Color(0x99FFB703),
                                  blurRadius: 30,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  AnimatedOpacity(
                    opacity: _touched ? 0 : 1,
                    duration: const Duration(milliseconds: 200),
                    child: Text(
                      Copy.touchTheStar,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        shadows: [
                          Shadow(color: Colors.black45, blurRadius: 8),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _SparkPainter extends CustomPainter {
  const _SparkPainter(this.progress);

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final centre = Offset(size.width / 2, size.height / 2);
    final paint = Paint()
      ..color = AppColors.sunshine.withValues(
        alpha: (1 - progress).clamp(0.0, 1.0),
      );

    for (var i = 0; i < 12; i++) {
      final angle = (i / 12) * 2 * math.pi;
      final distance = 40 + progress * 95;
      final position = centre +
          Offset(math.cos(angle) * distance, math.sin(angle) * distance);
      canvas.drawCircle(position, 9 * (1 - progress) + 2, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _SparkPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
