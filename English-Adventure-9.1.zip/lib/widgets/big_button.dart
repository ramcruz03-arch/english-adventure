import 'package:flutter/material.dart';

import '../core/theme/app_theme.dart';

/// A chunky, child-sized button. Always at least [kChildTapTarget] tall.
class BigButton extends StatelessWidget {
  const BigButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.color = AppColors.mint,
    this.icon,
    this.expand = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final Color color;
  final IconData? icon;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    final button = Semantics(
      button: true,
      label: label,
      child: Material(
        color: enabled ? color : color.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(AppRadii.button),
        elevation: enabled ? 6 : 0,
        shadowColor: color.withValues(alpha: 0.5),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppRadii.button),
          onTap: onPressed,
          child: Container(
            constraints: const BoxConstraints(minHeight: kChildTapTarget),
            padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 16),
            child: Row(
              mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Icon(icon, color: Colors.white, size: 30),
                  const SizedBox(width: 12),
                ],
                Flexible(
                  child: Text(
                    label,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    return expand ? SizedBox(width: double.infinity, child: button) : button;
  }
}

/// Round speaker button used everywhere audio can be replayed.
class SoundButton extends StatelessWidget {
  const SoundButton({
    super.key,
    required this.onPressed,
    this.color = AppColors.grape,
    this.size = kChildTapTarget,
  });

  final VoidCallback onPressed;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: 'Hear it',
      child: Material(
        color: color,
        shape: const CircleBorder(),
        elevation: 5,
        shadowColor: color.withValues(alpha: 0.5),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onPressed,
          child: SizedBox(
            width: size,
            height: size,
            child: Icon(Icons.volume_up_rounded,
                color: Colors.white, size: size * 0.5),
          ),
        ),
      ),
    );
  }
}
