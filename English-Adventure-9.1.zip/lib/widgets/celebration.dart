import 'dart:math';

import 'package:flutter/material.dart';

import '../core/theme/app_theme.dart';

/// Drops a short burst of confetti over the whole screen.
///
/// Fire and forget: `showCelebration(context)`.
void showCelebration(BuildContext context) {
  final overlay = Overlay.maybeOf(context);
  if (overlay == null) return;

  late OverlayEntry entry;
  entry = OverlayEntry(
    builder: (_) => const IgnorePointer(child: _ConfettiBurst()),
  );
  overlay.insert(entry);

  Future<void>.delayed(const Duration(milliseconds: 1600), () {
    if (entry.mounted) entry.remove();
  });
}

class _ConfettiBurst extends StatefulWidget {
  const _ConfettiBurst();

  @override
  State<_ConfettiBurst> createState() => _ConfettiBurstState();
}

class _ConfettiBurstState extends State<_ConfettiBurst>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1600),
  )..forward();

  late final List<_Bit> _bits = _makeBits();

  static const _palette = [
    AppColors.sunshine,
    AppColors.coral,
    AppColors.mint,
    AppColors.grape,
    AppColors.skyDeep,
  ];

  List<_Bit> _makeBits() {
    final random = Random();
    return List<_Bit>.generate(28, (i) {
      return _Bit(
        x: random.nextDouble(),
        delay: random.nextDouble() * 0.3,
        drift: (random.nextDouble() - 0.5) * 0.25,
        size: 10 + random.nextDouble() * 12,
        spin: (random.nextDouble() - 0.5) * 8,
        color: _palette[random.nextInt(_palette.length)],
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) => CustomPaint(
        painter: _ConfettiPainter(_bits, _controller.value),
        size: Size.infinite,
      ),
    );
  }
}

class _Bit {
  const _Bit({
    required this.x,
    required this.delay,
    required this.drift,
    required this.size,
    required this.spin,
    required this.color,
  });

  final double x;
  final double delay;
  final double drift;
  final double size;
  final double spin;
  final Color color;
}

class _ConfettiPainter extends CustomPainter {
  const _ConfettiPainter(this.bits, this.t);

  final List<_Bit> bits;
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    for (final bit in bits) {
      final double local =
          ((t - bit.delay) / (1 - bit.delay)).clamp(0.0, 1.0).toDouble();
      if (local <= 0) continue;

      final dx = (bit.x + bit.drift * local) * size.width;
      final dy = -30 + local * (size.height + 60);
      final double opacity = local < 0.85 ? 1.0 : (1 - local) / 0.15;

      canvas.save();
      canvas.translate(dx, dy);
      canvas.rotate(bit.spin * local);
      final paint = Paint()
        ..color =
            bit.color.withValues(alpha: opacity.clamp(0.0, 1.0).toDouble());
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset.zero,
            width: bit.size,
            height: bit.size * 0.6,
          ),
          const Radius.circular(3),
        ),
        paint,
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _ConfettiPainter oldDelegate) =>
      oldDelegate.t != t;
}
