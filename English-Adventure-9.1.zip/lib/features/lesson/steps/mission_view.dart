import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/celebration.dart';
import '../../../widgets/mascot.dart';

/// The mini mission that closes an island: find every target bubble.
///
/// Tapping a non-target bubble just says what it is and invites another go —
/// there is no score to lose and nothing turns red.
class MissionView extends ConsumerStatefulWidget {
  const MissionView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final MissionStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<MissionView> createState() => _MissionViewState();
}

class _MissionViewState extends ConsumerState<MissionView> {
  final Set<int> _found = <int>{};
  int? _wobbling;
  String _bubble = '';
  bool _finished = false;

  @override
  void initState() {
    super.initState();
    _bubble = widget.step.prompt;
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => ref.read(speechProvider).sayNow(widget.step.prompt),
    );
  }

  Future<void> _tap(int index) async {
    if (_finished || _found.contains(index)) return;
    final speech = ref.read(speechProvider);
    final option = widget.step.options[index];

    if (option == widget.step.target) {
      setState(() {
        _found.add(index);
        _bubble = Copy.praise();
      });
      speech.cheerHaptic();
      // A single letter is spoken as its sound, a word as a word.
      await (option.length == 1
          ? speech.sayPhoneme(option)
          : speech.say(option));
      if (_found.length == widget.step.targetCount) _complete();
    } else {
      setState(() {
        _wobbling = index;
        _bubble = Copy.nudge();
      });
      speech.softHaptic();
      await speech.say('That one is $option.');
      await speech.say(Copy.nudge());
      if (mounted) setState(() => _wobbling = null);
    }
  }

  Future<void> _complete() async {
    _finished = true;
    showCelebration(context);
    await ref.read(speechProvider).say('You found them all! ${Copy.praise()}');
    await Future<void>.delayed(const Duration(milliseconds: 400));
    if (mounted) widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    final step = widget.step;
    final remaining = step.targetCount - _found.length;

    return Column(
      children: [
        PipSays(text: _bubble),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppRadii.button),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.search_rounded, color: AppColors.inkSoft),
              const SizedBox(width: 10),
              Text(
                'Find:  ${step.target}',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  color: widget.accent,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                remaining > 0 ? '$remaining left' : 'all found!',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: AppColors.inkSoft,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Center(
            child: Wrap(
              alignment: WrapAlignment.center,
              spacing: 16,
              runSpacing: 16,
              children: List<Widget>.generate(step.options.length, (i) {
                final found = _found.contains(i);
                return _Bubble(
                  text: step.options[i],
                  found: found,
                  wobbling: _wobbling == i,
                  accent: widget.accent,
                  onTap: () => _tap(i),
                );
              }),
            ),
          ),
        ),
        const SizedBox(height: 12),
        BigButton(
          label: Copy.hear,
          icon: Icons.volume_up_rounded,
          color: AppColors.grape,
          expand: true,
          onPressed: () => ref.read(speechProvider).say(step.prompt),
        ),
      ],
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({
    required this.text,
    required this.found,
    required this.wobbling,
    required this.accent,
    required this.onTap,
  });

  final String text;
  final bool found;
  final bool wobbling;
  final Color accent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: wobbling ? 0.9 : 1.0,
      duration: const Duration(milliseconds: 180),
      child: Material(
        color: found ? AppColors.sunshine : Colors.white,
        shape: const CircleBorder(),
        elevation: found ? 2 : 6,
        shadowColor: accent.withValues(alpha: 0.4),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Container(
            width: 104,
            height: 104,
            alignment: Alignment.center,
            child: Text(
              text,
              style: TextStyle(
                fontSize: text.length > 2 ? 30 : 44,
                fontWeight: FontWeight.w800,
                color: found ? Colors.white : accent,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
