import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/celebration.dart';
import '../../../widgets/mascot.dart';

/// Read a sentence or a short story, then answer one gentle question.
///
/// Each line is tapped to hear it, which keeps reading active rather than
/// passive. The question only appears once every line has been heard, and a
/// wrong choice simply re-reads the story instead of scoring anything.
class StoryView extends ConsumerStatefulWidget {
  const StoryView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final StoryStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<StoryView> createState() => _StoryViewState();
}

class _StoryViewState extends ConsumerState<StoryView> {
  final Set<int> _heard = <int>{};
  String _bubble = 'Tap a line to hear it.';
  bool _asking = false;
  bool _finished = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => ref.read(speechProvider).sayNow(_bubble),
    );
  }

  Future<void> _readLine(int index) async {
    final speech = ref.read(speechProvider);
    speech.softHaptic();
    setState(() => _heard.add(index));
    await speech.say(widget.step.sentences[index]);
    if (!mounted) return;
    if (_heard.length == widget.step.sentences.length && !_asking) {
      setState(() {
        _asking = true;
        _bubble = widget.step.question;
      });
      await speech.say(widget.step.question);
    }
  }

  Future<void> _readAll() async {
    final speech = ref.read(speechProvider);
    setState(() {
      _heard.addAll(
        List<int>.generate(widget.step.sentences.length, (i) => i),
      );
    });
    await speech.say(widget.step.sentences.join(' '));
    if (!mounted || _asking) return;
    setState(() {
      _asking = true;
      _bubble = widget.step.question;
    });
    await speech.say(widget.step.question);
  }

  Future<void> _answer(String option) async {
    if (_finished) return;
    final speech = ref.read(speechProvider);

    if (option == widget.step.answer) {
      _finished = true;
      setState(() => _bubble = Copy.praise());
      speech.cheerHaptic();
      showCelebration(context);
      await speech.say('$option. ${Copy.praise()}');
      await Future<void>.delayed(const Duration(milliseconds: 400));
      if (mounted) widget.onDone();
    } else {
      setState(() => _bubble = 'Let us read it again.');
      speech.softHaptic();
      await speech.say(
        'Let us read it again. ${widget.step.sentences.join(' ')}',
      );
      if (mounted) setState(() => _bubble = widget.step.question);
    }
  }

  @override
  Widget build(BuildContext context) {
    final step = widget.step;

    return Column(
      children: [
        PipSays(text: _bubble),
        const SizedBox(height: 12),
        Text(step.emoji, style: const TextStyle(fontSize: 64)),
        const SizedBox(height: 10),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                for (var i = 0; i < step.sentences.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _SentenceLine(
                      text: step.sentences[i],
                      heard: _heard.contains(i),
                      accent: widget.accent,
                      onTap: () => _readLine(i),
                    ),
                  ),
                if (_asking) ...[
                  const SizedBox(height: 12),
                  Text(
                    step.question,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 10,
                    runSpacing: 10,
                    children: step.options
                        .map(
                          (option) => BigButton(
                            label: option,
                            color: widget.accent,
                            onPressed: () => _answer(option),
                          ),
                        )
                        .toList(),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        BigButton(
          label: 'Read it to me',
          icon: Icons.volume_up_rounded,
          color: AppColors.grape,
          expand: true,
          onPressed: _readAll,
        ),
      ],
    );
  }
}

class _SentenceLine extends StatelessWidget {
  const _SentenceLine({
    required this.text,
    required this.heard,
    required this.accent,
    required this.onTap,
  });

  final String text;
  final bool heard;
  final Color accent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(AppRadii.card),
      elevation: heard ? 1 : 4,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadii.card),
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadii.card),
            border: Border.all(
              color: heard ? accent : accent.withValues(alpha: 0.25),
              width: heard ? 3 : 2,
            ),
          ),
          child: Text(
            text,
            style: TextStyle(
              fontSize: 26,
              height: 1.3,
              fontWeight: FontWeight.w700,
              color: heard ? accent : AppColors.ink,
            ),
          ),
        ),
      ),
    );
  }
}
