import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/mascot.dart';

/// Shown once, before the child ever sees the map.
///
/// English Adventure 5.1 placed children with an eight-question quiz. That is
/// a test, and a test is exactly what this app promises not to be — so the
/// question is asked of the grown-up instead, in one tap, and can be changed
/// later in the parent area.
class SetupScreen extends ConsumerWidget {
  const SetupScreen({super.key});

  static const _choices = [
    (
      1,
      '🌱',
      'Just starting',
      'Learning letters and their sounds for the first time',
    ),
    (
      2,
      '🌿',
      'Knows some letters',
      'Recognises several letters, not reading words yet',
    ),
    (
      3,
      '🌳',
      'Reading small words',
      'Can blend sounds into words like cat and sun',
    ),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: SeaSkyBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              const SizedBox(height: 8),
              const PipSays(
                text: "Hello! I'm Pip. Let's set up the adventure.",
                mascotSize: 76,
              ),
              const SizedBox(height: 24),
              Text(
                'For the grown-up',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 4),
              Text(
                'Where should we start? Nothing is locked away for good — '
                'you can change this any time in the parent area.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 20),
              for (final choice in _choices) ...[
                _ChoiceCard(
                  emoji: choice.$2,
                  title: choice.$3,
                  subtitle: choice.$4,
                  onTap: () => ref
                      .read(progressProvider.notifier)
                      .setStartWorld(choice.$1),
                ),
                const SizedBox(height: 14),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _ChoiceCard extends StatelessWidget {
  const _ChoiceCard({
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final String emoji;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(AppRadii.card),
      elevation: 4,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadii.card),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 44)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, size: 32),
            ],
          ),
        ),
      ),
    );
  }
}
