import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/level.dart';

/// ABC Island: all 26 letters, in alphabet order, open from day one.
///
/// The teaching sequence is ordered by usefulness (s, a, t, p… so a child
/// can read `sat` after four letters), but children still need the alphabet
/// itself — letter *names*, ABC order, the song — for spelling aloud,
/// dictionaries and school. That is a different skill from letter *sounds*,
/// and this is where it lives.
///
/// It also answers a fair complaint: without this screen, a parent could not
/// see the alphabet anywhere, or tell how much of it their child had met.
class AlphabetScreen extends ConsumerWidget {
  const AlphabetScreen({super.key});

  static const _alphabet = 'abcdefghijklmnopqrstuvwxyz';

  /// Letter -> (sound, picture word, picture).
  static const Map<String, (String, String, String)> _letters = {
    'a': ('ah', 'apple', '🍎'),
    'b': ('b', 'bee', '🐝'),
    'c': ('k', 'cat', '🐱'),
    'd': ('d', 'dog', '🐶'),
    'e': ('eh', 'egg', '🥚'),
    'f': ('fff', 'fish', '🐟'),
    'g': ('g', 'goat', '🐐'),
    'h': ('h', 'hat', '🎩'),
    'i': ('ih', 'igloo', '🧊'),
    'j': ('j', 'jam', '🍯'),
    'k': ('k', 'key', '🔑'),
    'l': ('lll', 'lion', '🦁'),
    'm': ('mmm', 'moon', '🌙'),
    'n': ('nnn', 'nest', '🪺'),
    'o': ('o', 'octopus', '🐙'),
    'p': ('p', 'pig', '🐷'),
    'q': ('kw', 'queen', '👑'),
    'r': ('rrr', 'rainbow', '🌈'),
    's': ('sss', 'sun', '🌞'),
    't': ('t', 'turtle', '🐢'),
    'u': ('uh', 'umbrella', '☂️'),
    'v': ('vvv', 'van', '🚐'),
    'w': ('wuh', 'wave', '🌊'),
    'x': ('ks', 'fox', '🦊'),
    'y': ('yuh', 'yo-yo', '🪀'),
    'z': ('zzz', 'zebra', '🦓'),
  };

  /// Letter names, spelled so a text-to-speech voice says them properly.
  static const Map<String, String> _names = {
    'a': 'ay', 'b': 'bee', 'c': 'see', 'd': 'dee', 'e': 'ee', 'f': 'eff',
    'g': 'jee', 'h': 'aitch', 'i': 'eye', 'j': 'jay', 'k': 'kay', 'l': 'ell',
    'm': 'em', 'n': 'en', 'o': 'oh', 'p': 'pee', 'q': 'cue', 'r': 'arr',
    's': 'ess', 't': 'tee', 'u': 'you', 'v': 'vee', 'w': 'double you',
    'x': 'ex', 'y': 'why', 'z': 'zed',
  };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final levels = ref.watch(levelsProvider).asData?.value ?? const <Level>[];
    final progress = ref.watch(progressProvider);

    // A letter counts as "met" once its island has been finished.
    final met = <String>{};
    for (final level in levels) {
      if (!progress.isFinished(level.id)) continue;
      for (final step in level.steps) {
        if (step is LetterIntroStep) met.add(step.letter.toLowerCase());
      }
    }

    return Scaffold(
      body: SeaSkyBackground(
        tint: AppColors.grape,
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back_rounded,
                          color: Colors.white, size: 30),
                      onPressed: () => Navigator.of(context).maybePop(),
                    ),
                    const Expanded(
                      child: Text(
                        'ABC Island',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(AppRadii.button),
                      ),
                      child: Text(
                        '${met.length} / 26',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: AppColors.ink,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'Tap a letter to hear its name and its sound.',
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(color: Colors.white),
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 0.92,
                  ),
                  itemCount: _alphabet.length,
                  itemBuilder: (context, i) {
                    final letter = _alphabet[i];
                    return _LetterTile(
                      letter: letter,
                      data: _letters[letter]!,
                      metThisLetter: met.contains(letter),
                      onTap: () {
                        final speech = ref.read(speechProvider);
                        final (sound, word, _) = _letters[letter]!;
                        speech.softHaptic();
                        // Both labels, kept distinct: sounds are for
                        // reading, names are for talking about letters.
                        speech.sayNow(
                          'This letter is called ${_names[letter]}. '
                          'Big ${letter.toUpperCase()} and little $letter.',
                        );
                        speech.sayPhoneme(letter, sound: sound);
                        speech.say('$word.');
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LetterTile extends StatelessWidget {
  const _LetterTile({
    required this.letter,
    required this.data,
    required this.metThisLetter,
    required this.onTap,
  });

  final String letter;
  final (String, String, String) data;
  final bool metThisLetter;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (_, __, emoji) = data;

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(AppRadii.tile),
      elevation: metThisLetter ? 5 : 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadii.tile),
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadii.tile),
            border: Border.all(
              color: metThisLetter
                  ? AppColors.mint
                  : AppColors.inkSoft.withValues(alpha: 0.2),
              width: metThisLetter ? 3 : 1.5,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                letter,
                style: TextStyle(
                  fontSize: 34,
                  height: 1.0,
                  fontWeight: FontWeight.w800,
                  color: metThisLetter ? AppColors.grape : AppColors.inkSoft,
                ),
              ),
              Text(
                letter.toUpperCase(),
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.inkSoft,
                ),
              ),
              const SizedBox(height: 2),
              Text(emoji, style: const TextStyle(fontSize: 20)),
            ],
          ),
        ),
      ),
    );
  }
}
