import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/theme/app_theme.dart';
import 'parent_screen.dart';

/// Opens the parent area behind a four-digit PIN.
///
/// The first time, the grown-up chooses the PIN. A child who taps the lock
/// icon sees a number pad and nothing else — no scores, no settings.
Future<void> openParentArea(BuildContext context) async {
  final passed = await showDialog<bool>(
    context: context,
    barrierDismissible: true,
    builder: (_) => const _PinDialog(),
  );

  if (passed != true || !context.mounted) return;
  await Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => const ParentScreen()),
  );
}

class _PinDialog extends ConsumerStatefulWidget {
  const _PinDialog();

  @override
  ConsumerState<_PinDialog> createState() => _PinDialogState();
}

class _PinDialogState extends ConsumerState<_PinDialog> {
  String _entry = '';
  String _message = '';

  Future<void> _push(String digit) async {
    if (_entry.length >= 4) return;
    setState(() {
      _entry += digit;
      _message = '';
    });
    if (_entry.length == 4) await _submit();
  }

  Future<void> _submit() async {
    final controller = ref.read(progressProvider.notifier);
    final hasPin = ref.read(progressProvider).hasPin;

    if (!hasPin) {
      await controller.setPin(_entry);
      if (mounted) Navigator.of(context).pop(true);
      return;
    }

    if (controller.checkPin(_entry)) {
      if (mounted) Navigator.of(context).pop(true);
      return;
    }

    setState(() {
      _entry = '';
      _message = 'That PIN did not match. Try again.';
    });
  }

  @override
  Widget build(BuildContext context) {
    final hasPin = ref.watch(progressProvider.select((p) => p.hasPin));

    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      title: Text(hasPin ? 'Enter parent PIN' : 'Choose a parent PIN'),
      content: SizedBox(
        width: 300,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              hasPin
                  ? 'Four digits.'
                  : 'Four digits. You will need it to open this area again.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List<Widget>.generate(4, (i) {
                final filled = i < _entry.length;
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: filled
                        ? AppColors.skyDeep
                        : AppColors.inkSoft.withValues(alpha: 0.25),
                  ),
                );
              }),
            ),
            if (_message.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                _message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.coral),
              ),
            ],
            const SizedBox(height: 18),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 10,
              runSpacing: 10,
              children: [
                for (var n = 1; n <= 9; n++) _Key(label: '$n', onTap: _push),
                const SizedBox(width: 64, height: 56),
                _Key(label: '0', onTap: _push),
                SizedBox(
                  width: 64,
                  height: 56,
                  child: IconButton(
                    icon: const Icon(Icons.backspace_outlined),
                    onPressed: _entry.isEmpty
                        ? null
                        : () => setState(
                              () => _entry =
                                  _entry.substring(0, _entry.length - 1),
                            ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Key extends StatelessWidget {
  const _Key({required this.label, required this.onTap});

  final String label;
  final ValueChanged<String> onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 64,
      height: 56,
      child: OutlinedButton(
        onPressed: () => onTap(label),
        child: Text(label, style: const TextStyle(fontSize: 22)),
      ),
    );
  }
}
