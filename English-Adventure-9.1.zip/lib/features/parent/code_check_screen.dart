import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/level.dart';

/// Six made-up words the child has never seen.
///
/// A real word can be recognised from memory; `vop` cannot. If a child reads
/// nonsense words correctly they are genuinely decoding, which is why
/// England's phonics screening check uses them. It is the difference between
/// a child who has learned to read and one who has memorised our word lists.
class CodeCheckScreen extends ConsumerStatefulWidget {
  const CodeCheckScreen({super.key});

  @override
  ConsumerState<CodeCheckScreen> createState() => _CodeCheckScreenState();
}

class _CodeCheckScreenState extends ConsumerState<CodeCheckScreen> {
  /// Made-up but pronounceable. Each is filtered against the letters the
  /// child has actually been taught, so the check is never unfair.
  static const _bank = [
    'nid', 'sug', 'tep', 'vam', 'kib', 'dof', 'pon', 'lat', 'mub',
    'gan', 'ret', 'hep', 'jom', 'zib', 'fud', 'wex', 'yat', 'cug',
  ];

  int _index = 0;
  int _correct = 0;
  bool _finished = false;
  List<String> _words = const [];

  List<String> _pickWords(List<Level> levels) {
    final progress = ref.read(progressProvider);

    final taught = <String>{};
    for (final level in levels) {
      if (!progress.isFinished(level.id)) continue;
      for (final step in level.steps) {
        if (step is LetterIntroStep) taught.add(step.letter.toLowerCase());
      }
    }
    // Before anything is finished, assume the first few sounds.
    if (taught.length < 4) taught.addAll(['s', 'a', 't', 'p', 'i', 'n']);

    final usable = _bank
        .where((w) => w.split('').every(taught.contains))
        .toList();

    return usable.length >= 6 ? usable.take(6).toList() : usable;
  }

  void _mark(bool correct) {
    if (correct) _correct++;
    if (_index >= _words.length - 1) {
      ref
          .read(progressProvider.notifier)
          .recordCodeCheck(_correct, _words.length);
      setState(() => _finished = true);
      return;
    }
    setState(() => _index++);
  }

  @override
  Widget build(BuildContext context) {
    final levels = ref.watch(levelsProvider).asData?.value ?? const <Level>[];
    if (_words.isEmpty) _words = _pickWords(levels);

    return Scaffold(
      backgroundColor: AppColors.sand,
      appBar: AppBar(
        title: const Text('Code check'),
        backgroundColor: AppColors.sand,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: _words.isEmpty
            ? Center(
                child: Text(
                  'Finish a few more islands first — there are not enough '
                  'letters taught yet for a fair check.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              )
            : _finished
                ? _Result(
                    correct: _correct,
                    total: _words.length,
                    onDone: () => Navigator.of(context).pop(),
                  )
                : _Question(
                    word: _words[_index],
                    index: _index,
                    total: _words.length,
                    onMark: _mark,
                  ),
      ),
    );
  }
}

class _Question extends StatelessWidget {
  const _Question({
    required this.word,
    required this.index,
    required this.total,
    required this.onMark,
  });

  final String word;
  final int index;
  final int total;
  final ValueChanged<bool> onMark;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text('Word ${index + 1} of $total',
            style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 6),
        Text(
          'These are made-up words. Ask your child to sound each one out.',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        Expanded(
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 40, vertical: 30),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadii.card),
              ),
              child: Text(
                word,
                style: const TextStyle(
                  fontSize: 74,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 4,
                  color: AppColors.ink,
                ),
              ),
            ),
          ),
        ),
        FilledButton(
          onPressed: () => onMark(true),
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(60),
            backgroundColor: AppColors.mint,
          ),
          child: const Text('Sounded it out',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
        ),
        const SizedBox(height: 10),
        OutlinedButton(
          onPressed: () => onMark(false),
          style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(54),
          ),
          child: const Text('Not yet'),
        ),
      ],
    );
  }
}

class _Result extends StatelessWidget {
  const _Result({
    required this.correct,
    required this.total,
    required this.onDone,
  });

  final int correct;
  final int total;
  final VoidCallback onDone;

  @override
  Widget build(BuildContext context) {
    final ratio = total == 0 ? 0.0 : correct / total;
    final strong = ratio >= 0.8;

    return ListView(
      children: [
        const SizedBox(height: 20),
        Center(
          child: Text(
            '$correct / $total',
            style: TextStyle(
              fontSize: 62,
              fontWeight: FontWeight.w800,
              color: strong ? AppColors.mint : AppColors.sunshine,
            ),
          ),
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppRadii.card),
          ),
          child: Text(
            strong
                ? 'Your child is decoding, not guessing from memory. That is '
                    'exactly what we want at this stage — the skill will '
                    'transfer to words they have never met.'
                : 'Some sounds are not secure yet. Rather than pushing '
                    'forward, replay the islands for the letters that were '
                    'missed. The letters practised list shows which have had '
                    'least attention.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
        const SizedBox(height: 24),
        FilledButton(
          onPressed: onDone,
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
          child: const Text('Done'),
        ),
      ],
    );
  }
}
