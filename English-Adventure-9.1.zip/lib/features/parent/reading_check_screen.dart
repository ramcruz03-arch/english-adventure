import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/theme/app_theme.dart';
import '../../data/checks_repository.dart';

/// A one-minute timed read, run by a parent.
///
/// This is the only measure in the app that answers the real question: can
/// this child read better than last month? Words correct per minute has
/// decades of validation behind it, and around 40 WCPM is the point at which
/// a beginning reader is considered at low risk of difficulty.
///
/// The passage comes from assets/content/checks.json and never appears in
/// the course. A passage the child has already read would measure memory
/// rather than reading. It is still fully decodable with the code they have
/// been taught, so the check is fair.
class ReadingCheckScreen extends ConsumerStatefulWidget {
  const ReadingCheckScreen({super.key});

  @override
  ConsumerState<ReadingCheckScreen> createState() =>
      _ReadingCheckScreenState();
}

enum _Phase { intro, running, scoring, result }

class _ReadingCheckScreenState extends ConsumerState<ReadingCheckScreen> {
  static const int _seconds = 60;

  _Phase _phase = _Phase.intro;
  Timer? _timer;
  int _remaining = _seconds;
  int _stumbles = 0;
  int _lastWordReached = 0;
  int _wcpm = 0;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  /// The hardest unpracticed passage the child is ready for.
  CheckPassage? _passage(List<CheckPassage> passages) {
    final finished = ref.read(progressProvider).islandsFinished;
    CheckPassage? chosen;
    for (final passage in passages) {
      if (passage.minIsland <= finished) chosen = passage;
    }
    return chosen ?? (passages.isEmpty ? null : passages.first);
  }

  void _start() {
    setState(() {
      _phase = _Phase.running;
      _remaining = _seconds;
      _stumbles = 0;
      _lastWordReached = 0;
    });

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() => _remaining--);
      if (_remaining <= 0) {
        timer.cancel();
        setState(() => _phase = _Phase.scoring);
      }
    });
  }

  /// The child finished the passage before the minute was up. Scoring uses
  /// the time actually taken, so a fast reader is not penalised for running
  /// out of text.
  void _stopEarly() {
    _timer?.cancel();
    setState(() => _phase = _Phase.scoring);
  }

  void _score(int wordsAttempted) {
    final elapsed = _seconds - _remaining;
    final seconds = elapsed <= 0 ? _seconds : elapsed;
    final correct = (wordsAttempted - _stumbles).clamp(0, wordsAttempted);
    final wcpm = (correct * 60 / seconds).round();

    ref.read(progressProvider.notifier).recordReadingCheck(wcpm);
    setState(() {
      _lastWordReached = wordsAttempted;
      _wcpm = wcpm;
      _phase = _Phase.result;
    });
  }

  @override
  Widget build(BuildContext context) {
    final passages =
        ref.watch(checksProvider).asData?.value.reading ?? const <CheckPassage>[];
    final passage = _passage(passages);

    return Scaffold(
      backgroundColor: AppColors.sand,
      appBar: AppBar(
        title: const Text('Reading check'),
        backgroundColor: AppColors.sand,
        elevation: 0,
      ),
      body: passage == null
          ? const Center(child: Text('No passage available yet.'))
          : Padding(
              padding: const EdgeInsets.all(20),
              child: switch (_phase) {
                _Phase.intro => _Intro(onStart: _start),
                _Phase.running => _Running(
                    passage: passage,
                    remaining: _remaining,
                    stumbles: _stumbles,
                    onStumble: () => setState(() => _stumbles++),
                    onFinishedEarly: _stopEarly,
                  ),
                _Phase.scoring => _Scoring(
                    passage: passage,
                    onPick: _score,
                  ),
                _Phase.result => _Result(
                    wcpm: _wcpm,
                    words: _lastWordReached,
                    stumbles: _stumbles,
                    onDone: () => Navigator.of(context).pop(),
                  ),
              },
            ),
    );
  }
}

class _Intro extends StatelessWidget {
  const _Intro({required this.onStart});

  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const Text(
          'How it works',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 12),
        Text(
          '1. Hand the phone to your child and ask them to read aloud.\n\n'
          '2. Tap "Missed a word" each time they get stuck or read a word '
          'wrongly. Do not correct them — just tap.\n\n'
          '3. When the minute ends, tap the last word they reached.\n\n'
          'Your child never sees a score. To them this is just reading to '
          'a grown-up.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 28),
        FilledButton(
          onPressed: onStart,
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(58),
            backgroundColor: AppColors.mint,
          ),
          child: const Text('Start the minute',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}

class _Running extends StatelessWidget {
  const _Running({
    required this.passage,
    required this.remaining,
    required this.stumbles,
    required this.onStumble,
    required this.onFinishedEarly,
  });

  final CheckPassage passage;
  final int remaining;
  final int stumbles;
  final VoidCallback onStumble;
  final VoidCallback onFinishedEarly;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '$remaining s',
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w800,
                color: AppColors.skyDeep,
              ),
            ),
            Text('Missed: $stumbles',
                style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
        const SizedBox(height: 12),
        Expanded(
          child: SingleChildScrollView(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadii.card),
              ),
              child: Text(
                passage.text,
                style: const TextStyle(
                  fontSize: 26,
                  height: 1.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton(
          onPressed: onStumble,
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(64),
            backgroundColor: AppColors.coral,
          ),
          child: const Text('Missed a word',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        ),
        const SizedBox(height: 10),
        OutlinedButton(
          onPressed: onFinishedEarly,
          style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(48),
          ),
          child: const Text('They finished early'),
        ),
      ],
    );
  }
}

class _Scoring extends StatelessWidget {
  const _Scoring({required this.passage, required this.onPick});

  final CheckPassage passage;
  final ValueChanged<int> onPick;

  @override
  Widget build(BuildContext context) {
    final words = passage.text.split(RegExp(r'\s+'));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Tap the last word they read',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: SingleChildScrollView(
            child: Wrap(
              spacing: 8,
              runSpacing: 10,
              children: [
                for (var i = 0; i < words.length; i++)
                  ActionChip(
                    backgroundColor: Colors.white,
                    label: Text(
                      words[i],
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    onPressed: () => onPick(i + 1),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: () => onPick(words.length),
          style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(48),
          ),
          child: const Text('They read the whole passage'),
        ),
      ],
    );
  }
}

class _Result extends StatelessWidget {
  const _Result({
    required this.wcpm,
    required this.words,
    required this.stumbles,
    required this.onDone,
  });

  final int wcpm;
  final int words;
  final int stumbles;
  final VoidCallback onDone;

  /// Bands from the widely used oral reading fluency norms: under 20 needs
  /// support, 40+ is on track for a beginning reader, 60+ is fluent.
  (String, String, Color) get _band {
    if (wcpm >= 60) {
      return (
        'Reading fluently',
        'Comfortably above the beginner benchmark. Keep the reading going '
            'and move on to longer passages.',
        AppColors.mint,
      );
    }
    if (wcpm >= 40) {
      return (
        'On track',
        'At or above the level where a beginning reader is considered at '
            'low risk. This is where you want to be.',
        AppColors.mint,
      );
    }
    if (wcpm >= 20) {
      return (
        'Coming along',
        'Decoding is working but still effortful. More re-reading of '
            'passages already met will build speed.',
        AppColors.sunshine,
      );
    }
    return (
      'Needs more practice',
      'Reading is still slow and effortful. Go back over earlier islands '
          'rather than pushing forward, and read together daily.',
      AppColors.coral,
    );
  }

  @override
  Widget build(BuildContext context) {
    final (title, advice, colour) = _band;

    return ListView(
      children: [
        const SizedBox(height: 10),
        Center(
          child: Text(
            '$wcpm',
            style: TextStyle(
              fontSize: 78,
              fontWeight: FontWeight.w800,
              color: colour,
              height: 1.0,
            ),
          ),
        ),
        const Center(
          child: Text('words correct per minute',
              style: TextStyle(fontSize: 16, color: AppColors.inkSoft)),
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppRadii.card),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.w800,
                    color: colour,
                  )),
              const SizedBox(height: 8),
              Text(advice, style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 14),
              Text(
                'Read $words words, missed $stumbles.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'One check is a snapshot, not a verdict. Children vary day to day; '
          'what matters is the direction over several weeks.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 24),
        FilledButton(
          onPressed: onDone,
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(54),
          ),
          child: const Text('Done'),
        ),
      ],
    );
  }
}
