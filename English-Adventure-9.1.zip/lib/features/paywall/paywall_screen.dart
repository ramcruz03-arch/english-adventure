import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/purchase/purchase_service.dart';
import '../../core/theme/app_theme.dart';

/// The unlock screen.
///
/// Deliberately only reachable from behind the parent PIN: a child should
/// never meet a price tag. Nothing here is designed to pressure — no
/// countdown, no "limited offer", no repeated prompts.
class PaywallScreen extends ConsumerStatefulWidget {
  const PaywallScreen({super.key});

  @override
  ConsumerState<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends ConsumerState<PaywallScreen> {
  bool _busy = false;
  String? _message;
  String? _price;

  @override
  void initState() {
    super.initState();
    _loadPrice();
  }

  Future<void> _loadPrice() async {
    final service = ref.read(purchaseServiceProvider);
    final loaded = await service.loadProduct();
    if (!mounted) return;
    setState(() {
      _price = loaded ? service.priceLabel : null;
      if (!loaded) {
        _message = 'The store is not reachable right now. '
            'The free worlds keep working as normal.';
      }
    });
  }

  Future<void> _run(Future<PurchaseResult> Function() action) async {
    setState(() {
      _busy = true;
      _message = null;
    });

    final result = await action();
    if (!mounted) return;

    setState(() {
      _busy = false;
      _message = switch (result.outcome) {
        PurchaseOutcome.success => 'All worlds are unlocked. Thank you!',
        PurchaseOutcome.cancelled => 'No problem — nothing was charged.',
        PurchaseOutcome.pending =>
          result.message ?? 'The store is still processing this.',
        PurchaseOutcome.unavailable =>
          result.message ?? 'The unlock is not available right now.',
        PurchaseOutcome.error =>
          result.message ?? 'Something went wrong. Nothing was charged.',
      };
    });
  }

  @override
  Widget build(BuildContext context) {
    final unlocked = ref.watch(
      progressProvider.select((p) => p.unlockedFullVersion),
    );
    final controller = ref.read(progressProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.sand,
      appBar: AppBar(
        title: const Text('Unlock all worlds'),
        backgroundColor: AppColors.sand,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          if (unlocked)
            _Panel(
              emoji: '🎉',
              title: 'All worlds are unlocked',
              body: 'Thank you for supporting the app. The unlock stays with '
                  'your Google account — reinstall any time and use Restore.',
            )
          else ...[
            _Panel(
              emoji: '🗝️',
              title: 'One payment, everything included',
              body: 'Worlds 1 and 2 are free forever — every letter sound, '
                  'tracing and word cards. Unlocking adds blending, word '
                  'building, sentences and stories: 36 more islands.\n\n'
                  'No subscription. No ads. Works on every device signed in '
                  'to the same Google account, for as many children as you '
                  'like.',
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _busy
                  ? null
                  : () => _run(
                        () => ref.read(purchaseServiceProvider).buy(
                              onUnlocked: () => controller.setUnlocked(true),
                            ),
                      ),
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(58),
                backgroundColor: AppColors.mint,
              ),
              child: Text(
                _price == null ? 'Unlock everything' : 'Unlock — $_price',
                style: const TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _busy
                ? null
                : () => _run(
                      () => ref.read(purchaseServiceProvider).restore(
                            onUnlocked: () => controller.setUnlocked(true),
                          ),
                    ),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(52),
            ),
            child: const Text('Restore a previous purchase'),
          ),
          if (_busy) ...[
            const SizedBox(height: 20),
            const Center(child: CircularProgressIndicator()),
          ],
          if (_message != null) ...[
            const SizedBox(height: 20),
            Text(
              _message!,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
          const SizedBox(height: 28),
          Text(
            'Payment is handled by Google Play. The app never sees your card '
            'details and stores nothing about you.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  const _Panel({
    required this.emoji,
    required this.title,
    required this.body,
  });

  final String emoji;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 44)),
          const SizedBox(height: 10),
          Text(title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 10),
          Text(body, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}
