import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show SystemNavigator;
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/copy.dart';
import '../../core/providers.dart';
import '../../core/storage/progress_store.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/level.dart';
import '../../widgets/big_button.dart';
import '../../widgets/mascot.dart';
import '../../widgets/progress_bits.dart';
import '../lesson/lesson_screen.dart';
import '../alphabet/alphabet_screen.dart';
import '../parent/parent_gate.dart';
import '../setup/setup_screen.dart';

/// Home. Sixty islands across six worlds, unlocked in order.
class MapScreen extends ConsumerWidget {
  const MapScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final progress = ref.watch(progressProvider);
    if (progress.needsSetup) return const SetupScreen();

    final levels = ref.watch(levelsProvider);

    return Scaffold(
      body: SeaSkyBackground(
        child: SafeArea(
          child: levels.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('Could not load the islands.\n$error'),
              ),
            ),
            data: (list) => _MapBody(levels: list, progress: progress),
          ),
        ),
      ),
    );
  }
}

/// An island is open if a grown-up chose to start at its world, if it is the
/// very first one, or if the island before it is finished.
bool _isUnlocked(List<Level> levels, int i, ProgressState progress) {
  final level = levels[i];
  if (progress.isWorldPaid(level.worldIndex)) return false;
  // A grown-up can open everything, so a child is not stuck with whichever
  // island happens to come next.
  if (progress.openAllIslands) return true;
  return i == 0 ||
      level.worldIndex <= progress.startWorld ||
      progress.isFinished(levels[i - 1].id);
}

class _MapBody extends ConsumerWidget {
  const _MapBody({required this.levels, required this.progress});

  final List<Level> levels;
  final ProgressState progress;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Worlds become headers, each followed by a grid of island tiles.
    final rows = <Widget>[];

    final nextIsland = _nextIslandIndex();

    var lastWorldSeen = '';
    var pending = <Widget>[];

    void flushWorld() {
      if (pending.isEmpty) return;
      rows.add(
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: List<Widget>.of(pending),
        ),
      );
      rows.add(const SizedBox(height: 18));
      pending = <Widget>[];
    }

    for (var i = 0; i < levels.length; i++) {
      final level = levels[i];

      if (level.world != lastWorldSeen) {
        flushWorld();
        lastWorldSeen = level.world;
        final worldLevels =
            levels.where((l) => l.world == level.world).toList();
        rows.add(
          _WorldHeader(
            title: level.world,
            done: worldLevels.where((l) => progress.isFinished(l.id)).length,
            total: worldLevels.length,
            paid: progress.isWorldPaid(level.worldIndex),
          ),
        );
      }

      final unlocked = _isUnlocked(levels, i, progress);
      pending.add(
        _IslandTile(
          level: level,
          unlocked: unlocked,
          stars: progress.starsFor(level.id),
          isNext: i == nextIsland,
          onTap: () => _open(context, ref, level, unlocked),
        ),
      );
    }
    flushWorld();

    final nextIndex = nextIsland;

    return Column(
      children: [
        _Header(progress: progress),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 2, 20, 6),
          child: _AbcButton(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const AlphabetScreen(),
              ),
            ),
          ),
        ),
        if (nextIndex != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
            child: BigButton(
              label: '${Copy.keepGoing}  ${levels[nextIndex].emoji}',
              icon: Icons.sailing_rounded,
              color: AppColors.coral,
              expand: true,
              onPressed: () =>
                  _open(context, ref, levels[nextIndex], true),
            ),
          ),
        if (progress.collectibles.isNotEmpty)
          _TreasureBag(levels: levels, progress: progress),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 32),
            children: rows,
          ),
        ),
      ],
    );
  }

  /// First island that is open and not finished yet.
  int? _nextIslandIndex() {
    for (var i = 0; i < levels.length; i++) {
      if (progress.isFinished(levels[i].id)) continue;
      if (_isUnlocked(levels, i, progress)) return i;
    }
    return null;
  }

  void _open(
    BuildContext context,
    WidgetRef ref,
    Level level,
    bool unlocked,
  ) {
    final speech = ref.read(speechProvider);
    if (!unlocked) {
      final paid = ref
          .read(progressProvider)
          .isWorldPaid(level.worldIndex);
      final message = paid ? Copy.askAGrownUp : Copy.lockedMessage;
      speech.say(message);
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            backgroundColor: AppColors.grape,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            content: Text(
              message,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        );
      return;
    }
    speech.softHaptic();
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => LessonScreen(level: level)),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.progress});

  final ProgressState progress;

  @override
  Widget build(BuildContext context) {
    final greeting = progress.childName.isEmpty
        ? Copy.mapTitle
        : 'Hi ${progress.childName}!';

    // Title on its own line, controls beneath. In one row the buttons left
    // so little space that the title wrapped to one letter per line.
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const PipMascot(size: 46),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  greeting,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  softWrap: false,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        color: Color(0x552B3A55),
                        blurRadius: 8,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              StarPill(stars: progress.totalStars),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _GrownUpsButton(onTap: () => openParentArea(context)),
              ),
              const SizedBox(width: 10),
              _ExitButton(onTap: () => _confirmExit(context)),
            ],
          ),
        ],
      ),
    );
  }
}

/// Always open, never locked: the alphabet should be reachable on day one.
class _AbcButton extends StatelessWidget {
  const _AbcButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.9),
      borderRadius: BorderRadius.circular(AppRadii.button),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadii.button),
        onTap: onTap,
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('🔤', style: TextStyle(fontSize: 22)),
              SizedBox(width: 10),
              Text(
                'ABC Island — all the letters',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// A labelled button rather than a bare icon: parents could not find the
/// settings when this was just a padlock.
class _GrownUpsButton extends StatelessWidget {
  const _GrownUpsButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.9),
      borderRadius: BorderRadius.circular(AppRadii.button),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadii.button),
        onTap: onTap,
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.lock_outline_rounded,
                  size: 20, color: AppColors.ink),
              SizedBox(width: 6),
              Text(
                Copy.grownUps,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// A visible way out. Android's back gesture already closes the app, but a
/// child cannot be expected to know that, and a parent should not have to
/// guess either.
class _ExitButton extends StatelessWidget {
  const _ExitButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.9),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: const SizedBox(
          width: 44,
          height: 44,
          child: Icon(Icons.close_rounded, size: 24, color: AppColors.ink),
        ),
      ),
    );
  }
}

/// Confirmed, so a stray tap never throws a child out mid-adventure.
Future<void> _confirmExit(BuildContext context) async {
  final leave = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      title: const Text('Finish for now?'),
      content: const Text('Your stars and treasures are all saved.'),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(false),
          child: const Text('Keep playing'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(dialogContext).pop(true),
          child: const Text('Finish'),
        ),
      ],
    ),
  );
  if (leave == true) await SystemNavigator.pop();
}

class _WorldHeader extends StatelessWidget {
  const _WorldHeader({
    required this.title,
    required this.done,
    required this.total,
    this.paid = false,
  });

  final String title;
  final int done;
  final int total;
  final bool paid;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 12),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                shadows: [
                  Shadow(
                    color: Color(0x552B3A55),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.85),
              borderRadius: BorderRadius.circular(AppRadii.button),
            ),
            child: Text(
              paid ? '🔒' : '$done / $total',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.ink,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TreasureBag extends StatelessWidget {
  const _TreasureBag({required this.levels, required this.progress});

  final List<Level> levels;
  final ProgressState progress;

  @override
  Widget build(BuildContext context) {
    final found = levels
        .where((l) => progress.collectibles.contains(l.reward.id))
        .toList();

    return Container(
      height: 58,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.85),
        borderRadius: BorderRadius.circular(AppRadii.button),
      ),
      child: Row(
        children: [
          const Text('🎒', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 10),
          Expanded(
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: found.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, i) => Center(
                child: Text(
                  found[i].reward.emoji,
                  style: const TextStyle(fontSize: 28),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// The shortest useful label for a tile: the sound or word being taught.
String _shortLabel(String subtitle) {
  // Review and first-read islands get a word, not a truncated sentence.
  if (subtitle.contains('on your own')) return 'Read!';
  if (subtitle.startsWith('Read')) return 'Review';
  if (subtitle.contains('longer')) return 'long';
  if (subtitle.contains('Everything')) return 'Review';
  if (subtitle.contains('three sounds') ||
      subtitle.contains('Three sounds')) {
    return 'str';
  }

  var text = subtitle;
  for (final prefix in const ['Meet ', 'Blend ', 'Read ', 'Endings ']) {
    if (text.startsWith(prefix)) text = text.substring(prefix.length);
  }
  // "st and sp" -> "st sp";  "sh ch th ng" stays as it is
  text = text.replaceAll(' and ', ' ');
  final words = text.split(' ').where((w) => w.isNotEmpty).toList();
  if (words.length > 2) text = words.take(2).join(' ');
  return text.length > 9 ? text.substring(0, 9) : text;
}

/// One island, small enough that a whole world fits on a screen.
///
/// The old tall cards meant scrolling through thirty of them to find
/// anything; at this size a child can see where they are and pick.
class _IslandTile extends StatelessWidget {
  const _IslandTile({
    required this.level,
    required this.unlocked,
    required this.stars,
    required this.isNext,
    required this.onTap,
  });

  final Level level;
  final bool unlocked;
  final int stars;
  final bool isNext;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = unlocked ? level.color : AppColors.inkSoft;
    final finished = stars > 0;

    return Semantics(
      button: true,
      label: '${level.title}. ${unlocked ? "" : "Locked. "}'
          '$stars of ${level.maxStars} stars',
      child: Material(
        color: Colors.white.withValues(alpha: unlocked ? 1 : 0.55),
        borderRadius: BorderRadius.circular(AppRadii.tile),
        elevation: unlocked ? 4 : 0,
        shadowColor: color.withValues(alpha: 0.4),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppRadii.tile),
          onTap: onTap,
          child: Container(
            width: 88,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppRadii.tile),
              border: Border.all(
                color: isNext
                    ? AppColors.coral
                    : color.withValues(alpha: unlocked ? 0.45 : 0.2),
                width: isNext ? 4 : 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  unlocked ? level.emoji : '🔒',
                  style: const TextStyle(fontSize: 30),
                ),
                const SizedBox(height: 2),
                Text(
                  // Just the focus — "sh", "-at", "st" — because a whole
                  // subtitle cannot fit a tile and ends up as "Blend -...".
                  _shortLabel(level.subtitle),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: unlocked ? AppColors.ink : AppColors.inkSoft,
                  ),
                ),
                const SizedBox(height: 3),
                if (finished)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.star_rounded,
                          size: 14, color: AppColors.sunshine),
                      Text(
                        '$stars',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppColors.inkSoft,
                        ),
                      ),
                    ],
                  )
                else
                  Text(
                    '${level.index}',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.inkSoft,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
