import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

import 'models/level.dart';

/// Loads island content. Everything ships inside the app, so the whole
/// experience works with no network at all.
class ContentRepository {
  static const String levelsAsset = 'assets/content/levels.json';

  List<Level>? _cache;

  Future<List<Level>> levels() async {
    final cached = _cache;
    if (cached != null) return cached;

    final raw = await rootBundle.loadString(levelsAsset);
    final decoded = jsonDecode(raw) as List<dynamic>;
    final levels = decoded
        .map((e) => Level.fromJson(e as Map<String, dynamic>))
        .toList()
      ..sort((a, b) => a.index.compareTo(b.index));

    _cache = levels;
    return levels;
  }
}
