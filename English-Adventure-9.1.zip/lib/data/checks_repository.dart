import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// An unpracticed passage for a one-minute reading check.
///
/// These never appear in the course itself. A passage the child has already
/// read would measure memory rather than reading.
class CheckPassage {
  const CheckPassage({
    required this.minIsland,
    required this.title,
    required this.text,
  });

  final int minIsland;
  final String title;
  final String text;

  List<String> get words => text.split(RegExp(r'\s+'));

  factory CheckPassage.fromJson(Map<String, dynamic> json) => CheckPassage(
    minIsland: (json['minIsland'] as num).toInt(),
    title: json['title'] as String,
    text: json['text'] as String,
  );
}

/// Made-up words. They cannot be memorised, so getting them right proves
/// decoding rather than recall — the same reason England's phonics
/// screening check uses them.
class CheckWordSet {
  const CheckWordSet({required this.minIsland, required this.words});

  final int minIsland;
  final List<String> words;

  factory CheckWordSet.fromJson(Map<String, dynamic> json) => CheckWordSet(
    minIsland: (json['minIsland'] as num).toInt(),
    words:
        (json['words'] as List<dynamic>).map((e) => e as String).toList(),
  );
}

class ChecksRepository {
  static const String asset = 'assets/content/checks.json';

  ({List<CheckPassage> reading, List<CheckWordSet> code})? _cache;

  Future<({List<CheckPassage> reading, List<CheckWordSet> code})> load() async {
    final cached = _cache;
    if (cached != null) return cached;

    final raw = await rootBundle.loadString(asset);
    final decoded = jsonDecode(raw) as Map<String, dynamic>;

    final result = (
      reading: (decoded['reading'] as List<dynamic>)
          .map((e) => CheckPassage.fromJson(e as Map<String, dynamic>))
          .toList()
        ..sort((a, b) => a.minIsland.compareTo(b.minIsland)),
      code: (decoded['code'] as List<dynamic>)
          .map((e) => CheckWordSet.fromJson(e as Map<String, dynamic>))
          .toList()
        ..sort((a, b) => a.minIsland.compareTo(b.minIsland)),
    );

    _cache = result;
    return result;
  }

  /// The hardest check the child is ready for.
  static T? bestFor<T>(List<T> items, int islandsFinished,
      int Function(T) minIsland) {
    T? chosen;
    for (final item in items) {
      if (minIsland(item) <= islandsFinished) chosen = item;
    }
    return chosen ?? (items.isEmpty ? null : items.first);
  }
}
