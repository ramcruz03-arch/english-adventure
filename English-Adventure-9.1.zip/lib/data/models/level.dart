import 'package:flutter/material.dart';

/// A collectible treasure awarded when an island is finished.
class Collectible {
  const Collectible({required this.id, required this.name, required this.emoji});

  final String id;
  final String name;
  final String emoji;

  factory Collectible.fromJson(Map<String, dynamic> json) => Collectible(
    id: json['id'] as String,
    name: json['name'] as String,
    emoji: json['emoji'] as String,
  );
}

/// A word shown on a tap-to-hear card.
class WordItem {
  const WordItem({required this.text, required this.emoji});

  final String text;
  final String emoji;

  factory WordItem.fromJson(Map<String, dynamic> json) =>
      WordItem(text: json['text'] as String, emoji: json['emoji'] as String);
}

/// One short activity inside an island. Every island is a list of these.
///
/// Adding a new activity later = add a subclass here, add a case in
/// [LessonStep.fromJson], and add a case in `LessonScreen._viewFor`.
/// Because this class is `sealed`, the compiler will point at the switch if
/// you forget the last step.
sealed class LessonStep {
  const LessonStep();

  factory LessonStep.fromJson(Map<String, dynamic> json) {
    switch (json['type'] as String) {
      case 'letterIntro':
        return LetterIntroStep(
          letter: json['letter'] as String,
          sound: json['sound'] as String,
          exampleWord: json['exampleWord'] as String,
          exampleEmoji: json['exampleEmoji'] as String,
          say: json['say'] as String,
        );
      case 'wordCard':
        return WordCardStep(
          prompt: json['prompt'] as String? ?? 'Tap a card to hear it.',
          words: (json['words'] as List<dynamic>)
              .map((e) => WordItem.fromJson(e as Map<String, dynamic>))
              .toList(),
        );
      case 'spell':
        return SpellStep(
          word: json['word'] as String,
          emoji: json['emoji'] as String,
          distractors: (json['distractors'] as List<dynamic>? ?? const [])
              .map((e) => e as String)
              .toList(),
        );
      case 'trace':
        return TraceStep(
          letter: json['letter'] as String,
          say: json['say'] as String? ?? 'Trace the letter.',
          support: TraceSupport.fromJson(json['support'] as String?),
          letterCase: TraceCase.fromJson(json['case'] as String?),
          word: json['word'] as String?,
        );
      case 'reading':
        return ReadingStep(
          title: json['title'] as String? ?? 'Read this',
          emoji: json['emoji'] as String? ?? '📖',
          text: json['text'] as String,
          independent: (json['support'] as String?) == 'independent',
          question: json['question'] as String?,
          options: (json['options'] as List<dynamic>? ?? const [])
              .map((e) => e as String)
              .toList(),
          answer: json['answer'] as String?,
        );
      case 'story':
        return StoryStep(
          emoji: json['emoji'] as String? ?? '📖',
          sentences: (json['sentences'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
          question: json['question'] as String,
          options: (json['options'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
          answer: json['answer'] as String,
        );
      case 'mission':
        return MissionStep(
          prompt: json['prompt'] as String,
          target: json['target'] as String,
          options: (json['options'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
        );
      default:
        throw FormatException('Unknown step type: ${json['type']}');
    }
  }

  /// Letters this step gives practice on (used for the parent report).
  List<String> get practisedLetters;
}

class LetterIntroStep extends LessonStep {
  const LetterIntroStep({
    required this.letter,
    required this.sound,
    required this.exampleWord,
    required this.exampleEmoji,
    required this.say,
  });

  final String letter;
  final String sound;
  final String exampleWord;
  final String exampleEmoji;
  final String say;

  @override
  List<String> get practisedLetters => [letter];
}

class WordCardStep extends LessonStep {
  const WordCardStep({required this.prompt, required this.words});

  final String prompt;
  final List<WordItem> words;

  @override
  List<String> get practisedLetters =>
      words.expand((w) => w.text.split('')).toSet().toList();
}

class SpellStep extends LessonStep {
  const SpellStep({
    required this.word,
    required this.emoji,
    this.distractors = const [],
  });

  final String word;
  final String emoji;
  final List<String> distractors;

  List<String> get letters => word.split('');

  @override
  List<String> get practisedLetters => letters;
}

/// How much help the child gets while writing.
enum TraceSupport {
  /// Full grey letter, guide dots, arrows. First meeting.
  guided,

  /// Guide dots and a start marker only, no letter underneath.
  dots,

  /// An empty box and a start dot: writing from memory.
  memory;

  static TraceSupport fromJson(String? value) => switch (value) {
        'dots' => TraceSupport.dots,
        'memory' => TraceSupport.memory,
        _ => TraceSupport.guided,
      };
}

/// Which form of the letter is written.
enum TraceCase {
  lower,
  upper,

  /// Little one first, then the big one — how a classroom teaches it.
  both;

  static TraceCase fromJson(String? value) => switch (value) {
        'upper' => TraceCase.upper,
        'both' => TraceCase.both,
        _ => TraceCase.lower,
      };
}

class TraceStep extends LessonStep {
  const TraceStep({
    required this.letter,
    required this.say,
    this.support = TraceSupport.guided,
    this.letterCase = TraceCase.lower,
    this.word,
  });

  final String letter;
  final String say;
  final TraceSupport support;
  final TraceCase letterCase;

  /// Set for name writing. `{name}` is replaced with the child's name, so
  /// the first letter is a capital and the rest are lowercase — the most
  /// motivating handwriting task there is.
  final String? word;

  /// The letters to write, in order, each with the case to write it in.
  List<(String letter, bool capital)> targets(String childName) {
    final source = word;
    if (source != null) {
      final text = source.replaceAll('{name}', childName).trim();
      if (text.isEmpty) return [(letter, false)];
      return text
          .split('')
          .where((c) => RegExp(r'[A-Za-z]').hasMatch(c))
          .map((c) => (c, c == c.toUpperCase()))
          .toList();
    }
    // A multi-letter grapheme like `qu` is written as its letters: there is
    // no single `qu` shape, a child writes q and then u.
    if (letter.length > 1) {
      final letters = letter
          .toLowerCase()
          .split('')
          .map((c) => (c, false))
          .toList();
      if (letterCase == TraceCase.both) {
        // Capitals only ever apply to the first letter: `Quiz`, not `QUiz`.
        letters.add((letter[0], true));
      }
      return letters;
    }

    return switch (letterCase) {
      TraceCase.lower => [(letter, false)],
      TraceCase.upper => [(letter, true)],
      TraceCase.both => [(letter, false), (letter, true)],
    };
  }

  @override
  List<String> get practisedLetters => [letter];
}

/// Connected text: the heart of the course.
///
/// The child meets the same passage in escalating independence — listen,
/// read together, read alone — because that progression is where fluency
/// comes from.
class ReadingStep extends LessonStep {
  const ReadingStep({
    required this.title,
    required this.emoji,
    required this.text,
    this.independent = false,
    this.question,
    this.options = const [],
    this.answer,
  });

  final String title;
  final String emoji;
  final String text;

  /// Skip the listen-first stage: the child reads it cold.
  final bool independent;

  final String? question;
  final List<String> options;
  final String? answer;

  bool get hasQuestion => question != null && options.length >= 2;

  int get wordCount => text.split(RegExp(r'\s+')).length;

  /// Sentences, kept with their punctuation, for sentence-by-sentence audio.
  List<String> get sentences {
    final matches = RegExp(r'[^.!?]+[.!?]*').allMatches(text);
    return matches
        .map((m) => m.group(0)!.trim())
        .where((s) => s.isNotEmpty)
        .toList();
  }

  @override
  List<String> get practisedLetters => const [];
}

class StoryStep extends LessonStep {
  const StoryStep({
    required this.emoji,
    required this.sentences,
    required this.question,
    required this.options,
    required this.answer,
  });

  final String emoji;
  final List<String> sentences;
  final String question;
  final List<String> options;
  final String answer;

  @override
  List<String> get practisedLetters => const [];
}

class MissionStep extends LessonStep {
  const MissionStep({
    required this.prompt,
    required this.target,
    required this.options,
  });

  final String prompt;
  final String target;
  final List<String> options;

  int get targetCount => options.where((o) => o == target).length;

  @override
  List<String> get practisedLetters => target.split('');
}

/// One island on the map.
class Level {
  const Level({
    required this.id,
    required this.index,
    required this.world,
    required this.worldIndex,
    required this.title,
    required this.subtitle,
    required this.emoji,
    required this.color,
    required this.reward,
    required this.steps,
  });

  final String id;
  final int index;

  /// Which of the six worlds this island belongs to.
  final String world;
  final int worldIndex;

  final String title;
  final String subtitle;
  final String emoji;
  final Color color;
  final Collectible reward;
  final List<LessonStep> steps;

  /// One star per activity, so a child always sees a full row at the end.
  int get maxStars => steps.length;

  factory Level.fromJson(Map<String, dynamic> json) => Level(
    id: json['id'] as String,
    index: json['index'] as int,
    world: json['world'] as String? ?? 'English Adventure',
    worldIndex: (json['worldIndex'] as num?)?.toInt() ?? 1,
    title: json['title'] as String,
    subtitle: json['subtitle'] as String,
    emoji: json['emoji'] as String,
    color: _parseColor(json['color'] as String),
    reward: Collectible.fromJson(json['reward'] as Map<String, dynamic>),
    steps: (json['steps'] as List<dynamic>)
        .map((e) => LessonStep.fromJson(e as Map<String, dynamic>))
        .toList(),
  );

  static Color _parseColor(String hex) {
    final value = hex.replaceAll('#', '');
    return Color(int.parse('FF$value', radix: 16));
  }
}
