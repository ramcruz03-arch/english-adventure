// Validates assets/content/levels.json before a build.
//
// Pure Dart (no Flutter imports) so it can run with `dart run`.
// Usage: dart run tools/validate_content.dart

import 'dart:convert';
import 'dart:io';

/// Letters that have tracing strokes in lib/core/letter_strokes.dart.
/// Keep in sync when you add a new letter shape.
const traceableLetters = {
  'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
  'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
};

const stepTypes = {
  'letterIntro',
  'wordCard',
  'spell',
  'trace',
  'mission',
  'story',
  'reading',
};

void main() {
  final file = File('assets/content/levels.json');
  if (!file.existsSync()) {
    _fail('assets/content/levels.json is missing');
  }

  final levels = jsonDecode(file.readAsStringSync()) as List<dynamic>;
  final errors = <String>[];
  final ids = <String>{};
  final rewardIds = <String>{};

  for (final raw in levels) {
    final level = raw as Map<String, dynamic>;
    final id = level['id'] as String? ?? '(no id)';

    if (!ids.add(id)) errors.add('Duplicate level id: $id');

    for (final key in [
      'index',
      'world',
      'worldIndex',
      'title',
      'subtitle',
      'emoji',
      'color',
    ]) {
      if (level[key] == null) errors.add('$id: missing "$key"');
    }

    final color = level['color'] as String? ?? '';
    if (!RegExp(r'^#[0-9A-Fa-f]{6}$').hasMatch(color)) {
      errors.add('$id: colour "$color" must look like #RRGGBB');
    }

    final reward = level['reward'] as Map<String, dynamic>?;
    if (reward == null) {
      errors.add('$id: missing reward');
    } else if (!rewardIds.add(reward['id'] as String)) {
      errors.add('$id: duplicate reward id ${reward['id']}');
    }

    final steps = level['steps'] as List<dynamic>? ?? const [];
    if (steps.isEmpty) errors.add('$id: has no steps');
    if (steps.length > 6) {
      errors.add('$id: ${steps.length} steps — keep islands short (max 6)');
    }

    for (final rawStep in steps) {
      final step = rawStep as Map<String, dynamic>;
      final type = step['type'] as String? ?? '';
      if (!stepTypes.contains(type)) {
        errors.add('$id: unknown step type "$type"');
        continue;
      }
      if (type == 'trace') {
        final letter = (step['letter'] as String? ?? '').toLowerCase();
        if (!traceableLetters.contains(letter)) {
          errors.add('$id: no tracing strokes for letter "$letter"');
        }
        const cases = {'lower', 'upper', 'both'};
        final letterCase = step['case'] as String?;
        if (letterCase != null && !cases.contains(letterCase)) {
          errors.add('$id: unknown trace case "$letterCase"');
        }
      }
      if (type == 'spell') {
        final word = step['word'] as String? ?? '';
        if (word.isEmpty) errors.add('$id: spell step has no word');
        if (word.length > 4) {
          errors.add('$id: "$word" is long for a beginner (max 4 letters)');
        }
      }
      if (type == 'story') {
        final options =
            (step['options'] as List<dynamic>? ?? const []).cast<String>();
        final answer = step['answer'] as String? ?? '';
        if (!options.contains(answer)) {
          errors.add('$id: story answer "$answer" is not in the options');
        }
        final sentences = step['sentences'] as List<dynamic>? ?? const [];
        if (sentences.isEmpty) errors.add('$id: story has no sentences');
      }
      if (type == 'reading') {
        final text = step['text'] as String? ?? '';
        if (text.isEmpty) errors.add('$id: reading step has no text');
        final options =
            (step['options'] as List<dynamic>? ?? const []).cast<String>();
        final answer = step['answer'] as String?;
        if (answer != null && !options.contains(answer)) {
          errors.add('$id: reading answer "$answer" is not in the options');
        }
      }
      if (type == 'mission') {
        final target = step['target'] as String? ?? '';
        final options =
            (step['options'] as List<dynamic>? ?? const []).cast<String>();
        if (!options.contains(target)) {
          errors.add('$id: mission target "$target" is not in the options');
        }
      }
    }
  }

  if (errors.isNotEmpty) {
    for (final error in errors) {
      stderr.writeln('  ✗ $error');
    }
    _fail('${errors.length} content problem(s) found');
  }

  stdout.writeln('✓ ${levels.length} islands look good.');
}

Never _fail(String message) {
  stderr.writeln('Content validation failed: $message');
  exit(1);
}
