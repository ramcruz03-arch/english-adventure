import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/storage/progress_store.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/level.dart';
import '../../widgets/progress_bits.dart';
import '../../widgets/star_award.dart';
import '../reward/reward_screen.dart';
import 'steps/letter_intro_view.dart';
import 'steps/mission_view.dart';
import 'steps/reading_view.dart';
import 'steps/spell_view.dart';
import 'steps/story_view.dart';
import 'steps/trace_view.dart';
import 'steps/word_card_view.dart';

/// Plays one island: a handful of short activities, one after another.
///
/// The child can always leave, never fails, and earns a star per activity.
class LessonScreen extends ConsumerStatefulWidget {
  const LessonScreen({super.key, required this.level});

  final Level level;

  @override
  ConsumerState<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends ConsumerState<LessonScreen> {
  late final ProgressController _progress;
  final Stopwatch _stopwatch = Stopwatch()..start();

  int _index = 0;

  @override
  void initState() {
    super.initState();
    _progress = ref.read(progressProvider.notifier);
  }

  @override
  void dispose() {
    _stopwatch.stop();
    _progress.addPlaySeconds(_stopwatch.elapsed.inSeconds);
    super.dispose();
  }

  Future<void> _handleStepDone() async {
    final level = widget.level;
    final step = level.steps[_index];
    await _progress.notePractice(step.practisedLetters);

    // Every activity earns a star the child collects by touching it.
    if (!mounted) return;
    await showStarAward(context, ref);
    if (!mounted) return;

    if (_index >= level.steps.length - 1) {
      await _progress.finishLevel(
        levelId: level.id,
        stars: level.maxStars,
        collectibleId: level.reward.id,
      );
      ref.read(sfxProvider).islandComplete();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => RewardScreen(level: level),
        ),
      );
      return;
    }

    setState(() => _index++);
  }

  Widget _viewFor(LessonStep step) {
    final accent = widget.level.color;
    return switch (step) {
      LetterIntroStep s => LetterIntroView(
          step: s,
          accent: accent,
          onDone: _handleStepDone,
        ),
      WordCardStep s => WordCardView(
          step: s,
          accent: accent,
          onDone: _handleStepDone,
        ),
      SpellStep s => SpellView(
          step: s,
          accent: accent,
          onDone: _handleStepDone,
        ),
      TraceStep s => TraceView(
          step: s,
          accent: accent,
          onDone: _handleStepDone,
        ),
      ReadingStep s => ReadingView(
          step: s,
          accent: accent,
          onDone: _handleStepDone,
        ),
      StoryStep s => StoryView(
          step: s,
          accent: accent,
          onDone: _handleStepDone,
        ),
      MissionStep s => MissionView(
          step: s,
          accent: accent,
          onDone: _handleStepDone,
        ),
    };
  }

  @override
  Widget build(BuildContext context) {
    final level = widget.level;

    return Scaffold(
      body: SeaSkyBackground(
        tint: level.color,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
            child: Column(
              children: [
                Row(
                  children: [
                    _RoundIconButton(
                      icon: Icons.arrow_back_rounded,
                      onPressed: () => Navigator.of(context).maybePop(),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${level.emoji}  ${level.title}',
                            style: Theme.of(context).textTheme.titleLarge,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 6),
                          StepDots(
                            count: level.steps.length,
                            current: _index,
                            color: level.color,
                          ),
                        ],
                      ),
                    ),
                    StarRow(earned: _index, total: level.maxStars, size: 20),
                  ],
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 320),
                    child: KeyedSubtree(
                      key: ValueKey<int>(_index),
                      child: _viewFor(level.steps[_index]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  const _RoundIconButton({required this.icon, required this.onPressed});

  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 3,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: SizedBox(
          width: 52,
          height: 52,
          child: Icon(icon, color: AppColors.ink, size: 28),
        ),
      ),
    );
  }
}
