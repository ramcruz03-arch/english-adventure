import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/storage/progress_store.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/level.dart';
import '../paywall/paywall_screen.dart';
import 'code_check_screen.dart';
import 'reading_check_screen.dart';

/// Calm, plain-language progress and settings for a parent.
///
/// No scores, no rankings, nothing that would make a child feel measured —
/// and everything a grown-up might want to change lives here rather than
/// anywhere the child can reach.
class ParentScreen extends ConsumerWidget {
  const ParentScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final progress = ref.watch(progressProvider);
    final levels = ref.watch(levelsProvider);
    final allLevels = levels.asData?.value ?? const <Level>[];

    final worlds = <String, List<Level>>{};
    for (final level in allLevels) {
      worlds.putIfAbsent(level.world, () => <Level>[]).add(level);
    }

    final letters = progress.letterCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    // Letters whose island is finished: what the child has actually been
    // taught, as opposed to what they have merely seen.
    final mastered = <String>{};
    ReadingStep? canReadNow;
    for (final level in allLevels) {
      if (!progress.isFinished(level.id)) continue;
      for (final step in level.steps) {
        if (step is LetterIntroStep) mastered.add(step.letter.toLowerCase());
        if (step is ReadingStep) canReadNow = step;
      }
    }

    return Scaffold(
      backgroundColor: AppColors.sand,
      appBar: AppBar(
        title: const Text('Grown-ups'),
        backgroundColor: AppColors.sand,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // ------------------------------------------------------ growth --
          const _SectionTitle('Growth'),
          _CanReadCard(passage: canReadNow, name: progress.childName),
          const SizedBox(height: 12),
          Row(
            children: [
              _StatCard(
                label: 'Sounds mastered',
                value: '${mastered.length}/26',
                icon: Icons.abc_rounded,
                color: AppColors.grape,
              ),
              const SizedBox(width: 12),
              _StatCard(
                label: 'Words read',
                value: '${progress.wordsRead}',
                icon: Icons.menu_book_rounded,
                color: AppColors.mint,
              ),
            ],
          ),
          const SizedBox(height: 12),
          _CheckCard(
            title: 'Reading check',
            subtitle: progress.latestCheck == null
                ? 'A one-minute read, scored by you. The clearest measure of '
                    'progress there is.'
                : 'Last check: ${progress.latestCheck!.wcpm} words per '
                    'minute. 40+ is on track.',
            action: 'Start',
            icon: Icons.timer_outlined,
            color: AppColors.skyDeep,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const ReadingCheckScreen(),
              ),
            ),
          ),
          if (progress.readingChecks.length >= 2) ...[
            const SizedBox(height: 12),
            _CheckTrend(checks: progress.readingChecks),
          ],
          const SizedBox(height: 12),
          _CheckCard(
            title: 'Code check',
            subtitle: progress.codeChecks.isEmpty
                ? 'Six made-up words. They cannot be memorised, so they show '
                    'real decoding.'
                : 'Last check: ${progress.codeChecks.last.correct} of '
                    '${progress.codeChecks.last.total} sounded out.',
            action: 'Start',
            icon: Icons.fact_check_outlined,
            color: AppColors.coral,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const CodeCheckScreen(),
              ),
            ),
          ),
          if (progress.milestones.isNotEmpty) ...[
            const SizedBox(height: 22),
            const _SectionTitle('Moments'),
            _Milestones(entries: progress.milestones),
          ],
          const SizedBox(height: 26),

          // ---------------------------------------------------- progress --
          const _SectionTitle('Activity'),
          Row(
            children: [
              _StatCard(
                label: 'Islands finished',
                value: allLevels.isEmpty
                    ? '${progress.islandsFinished}'
                    : '${progress.islandsFinished}/${allLevels.length}',
                icon: Icons.flag_rounded,
                color: AppColors.mint,
              ),
              const SizedBox(width: 12),
              _StatCard(
                label: 'Stars earned',
                value: '${progress.totalStars}',
                icon: Icons.star_rounded,
                color: AppColors.sunshine,
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _StatCard(
                label: 'Treasures found',
                value: '${progress.collectibles.length}',
                icon: Icons.card_giftcard_rounded,
                color: AppColors.grape,
              ),
              const SizedBox(width: 12),
              _StatCard(
                label: 'Time this week',
                value: '${(progress.secondsThisWeek / 60).round()} min',
                icon: Icons.schedule_rounded,
                color: AppColors.skyDeep,
              ),
            ],
          ),
          const SizedBox(height: 12),
          _GoalCard(progress: progress),
          const SizedBox(height: 22),

          const _SectionTitle('Worlds'),
          for (final entry in worlds.entries)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _WorldRow(
                name: entry.key,
                levels: entry.value,
                progress: progress,
                onReplay: () => _confirmWorldReplay(context, ref, entry.value),
              ),
            ),
          const SizedBox(height: 22),

          const _SectionTitle('Last 7 days'),
          _WeekBars(
            minutes:
                progress.weeklySeconds.map((s) => (s / 60).round()).toList(),
          ),
          const SizedBox(height: 22),

          const _SectionTitle('Letters practised'),
          if (letters.isEmpty)
            Text(
              'Nothing yet — the first island is a good place to start.',
              style: Theme.of(context).textTheme.bodyMedium,
            )
          else
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: letters
                  .map(
                    (entry) => Chip(
                      backgroundColor: Colors.white,
                      label: Text(
                        '${entry.key}  ·  ${entry.value}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          const SizedBox(height: 26),

          // ---------------------------------------------------- settings --
          const _SectionTitle('Settings'),
          Card(
            child: ListTile(
              leading: const Icon(Icons.face_rounded, color: AppColors.coral),
              title: const Text("Child's name"),
              subtitle: Text(
                progress.childName.isEmpty
                    ? 'Not set — Pip will just say "you"'
                    : progress.childName,
              ),
              onTap: () => _editName(context, ref, progress.childName),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: SwitchListTile(
              value: progress.soundOn,
              title: const Text('Voice and sounds'),
              subtitle: const Text('Letters, words and encouragement'),
              onChanged: (value) =>
                  ref.read(progressProvider.notifier).setSound(value),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.record_voice_over_rounded,
                  color: AppColors.mint),
              title: const Text('Test the voice'),
              subtitle: const Text(
                'Hear how Pip sounds on this device. If nothing plays, '
                'install Google Speech Services and pick a voice in your '
                "phone's settings.",
              ),
              onTap: () => ref.read(speechProvider).test(),
            ),
          ),          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Voice speed',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  Text(
                    _rateLabel(progress.voiceRate),
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  Slider(
                    value: progress.voiceRate,
                    min: 0.28,
                    max: 0.60,
                    divisions: 8,
                    label: _rateLabel(progress.voiceRate),
                    onChanged: (value) =>
                        ref.read(progressProvider.notifier).setVoiceRate(value),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.timer_outlined, color: AppColors.skyDeep),
              title: const Text('Daily goal'),
              subtitle: Text(
                '${progress.dailyGoalMinutes} minutes — a gentle target, '
                'never a cut-off',
              ),
              onTap: () => _editGoal(context, ref, progress.dailyGoalMinutes),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.explore_rounded, color: AppColors.skyDeep),
              title: const Text('Starting point'),
              subtitle: Text(_startLabel(progress.startWorld)),
              onTap: () => _chooseStart(context, ref),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock_open_rounded,
                  color: AppColors.sunshine),
              title: Text(
                progress.unlockedFullVersion
                    ? 'All worlds unlocked'
                    : 'Unlock all worlds',
              ),
              subtitle: Text(
                progress.unlockedFullVersion
                    ? 'Thank you for supporting the app'
                    : 'Worlds 1–2 are free. One payment adds the other 36 '
                        'islands.',
              ),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const PaywallScreen(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.password_rounded, color: AppColors.grape),
              title: const Text('Reset parent PIN'),
              subtitle: const Text('You will choose a new one next time'),
              onTap: () async {
                await ref.read(progressProvider.notifier).clearPin();
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('PIN cleared.')),
                  );
                }
              },
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.restart_alt_rounded, color: AppColors.coral),
              title: const Text('Start the adventure again'),
              subtitle: const Text('Clears stars, treasures and progress'),
              onTap: () => _confirmReset(context, ref),
            ),
          ),
          const SizedBox(height: 22),
          Text(
            'Everything is stored on this device only. No account, no ads, '
            'no data leaves the app. Purchases are handled by Google Play.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  static String _rateLabel(double rate) {
    if (rate <= 0.34) return 'Very slow';
    if (rate <= 0.42) return 'Slow (recommended)';
    if (rate <= 0.50) return 'Normal';
    return 'Quick';
  }

  static String _startLabel(int world) => switch (world) {
        1 => 'Just starting — from Letter Village',
        2 => 'Knows some letters — from Sound Forest',
        3 => 'Reading small words — from Blending Bridge',
        _ => 'Not set',
      };

  Future<void> _editName(
    BuildContext context,
    WidgetRef ref,
    String current,
  ) async {
    final controller = TextEditingController(text: current);
    final name = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text("Child's name"),
        content: TextField(
          controller: controller,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            hintText: 'First name only',
            helperText: 'Stored on this device, spoken by Pip',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.of(dialogContext).pop(controller.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (name != null) {
      await ref.read(progressProvider.notifier).setChildName(name);
    }
  }

  Future<void> _editGoal(
    BuildContext context,
    WidgetRef ref,
    int current,
  ) async {
    final choice = await showDialog<int>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: const Text('Daily goal'),
        children: [
          for (final minutes in [5, 10, 15, 20])
            SimpleDialogOption(
              onPressed: () => Navigator.of(dialogContext).pop(minutes),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  '$minutes minutes${minutes == current ? '  ·  current' : ''}',
                ),
              ),
            ),
        ],
      ),
    );
    if (choice != null) {
      await ref.read(progressProvider.notifier).setDailyGoal(choice);
    }
  }

  Future<void> _chooseStart(BuildContext context, WidgetRef ref) async {
    final choice = await showDialog<int>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: const Text('Where should the adventure open?'),
        children: [
          for (var world = 1; world <= 3; world++)
            SimpleDialogOption(
              onPressed: () => Navigator.of(dialogContext).pop(world),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(_startLabel(world)),
              ),
            ),
        ],
      ),
    );
    if (choice != null) {
      await ref.read(progressProvider.notifier).setStartWorld(choice);
    }
  }

  Future<void> _confirmWorldReplay(
    BuildContext context,
    WidgetRef ref,
    List<Level> levels,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Play this world again?'),
        content: const Text(
          'The islands go back to unplayed so they feel new. Treasures '
          'already found stay in the bag.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Play again'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ref
          .read(progressProvider.notifier)
          .resetWorld(levels.map((l) => l.id));
    }
  }

  Future<void> _confirmReset(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Start again?'),
        content: const Text(
          'This clears all stars, treasures and progress on this device. '
          'Your settings and unlock are kept.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Start again'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(progressProvider.notifier).resetEverything();
    }
  }
}

/// The single most useful line in the whole dashboard: a real sample of
/// what this child can read today, built from the code they have been taught.
class _CanReadCard extends StatelessWidget {
  const _CanReadCard({required this.passage, required this.name});

  final ReadingStep? passage;
  final String name;

  @override
  Widget build(BuildContext context) {
    final who = name.isEmpty ? 'Your child' : name;
    final sample = passage?.text;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
        border: Border.all(color: AppColors.mint, width: 3),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            sample == null
                ? 'What $who will read first'
                : 'What $who can read now',
            style: const TextStyle(fontSize: 16, color: AppColors.inkSoft),
          ),
          const SizedBox(height: 10),
          Text(
            sample ?? 'Finish the first islands to see this.',
            style: const TextStyle(
              fontSize: 22,
              height: 1.4,
              fontWeight: FontWeight.w700,
              color: AppColors.ink,
            ),
          ),
          if (sample != null) ...[
            const SizedBox(height: 10),
            Text(
              'Every word here uses only sounds $who has been taught.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ],
      ),
    );
  }
}

class _CheckCard extends StatelessWidget {
  const _CheckCard({
    required this.title,
    required this.subtitle,
    required this.action,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final String action;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.fromLTRB(16, 10, 12, 10),
        leading: Icon(icon, color: color, size: 30),
        title: Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
        ),
        subtitle: Text(subtitle),
        trailing: FilledButton(
          onPressed: onTap,
          style: FilledButton.styleFrom(backgroundColor: color),
          child: Text(action),
        ),
        onTap: onTap,
      ),
    );
  }
}

/// Words per minute over time. Direction matters more than any single check.
class _CheckTrend extends StatelessWidget {
  const _CheckTrend({required this.checks});

  final List<ReadingCheck> checks;

  @override
  Widget build(BuildContext context) {
    final recent =
        checks.length > 8 ? checks.sublist(checks.length - 8) : checks;
    final peak = recent.fold<int>(60, (m, c) => c.wcpm > m ? c.wcpm : m);

    return Container(
      height: 160,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Words per minute',
              style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 10),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final check in recent)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text('${check.wcpm}',
                              style: const TextStyle(fontSize: 12)),
                          const SizedBox(height: 4),
                          Container(
                            height: 10 + (check.wcpm / peak) * 70,
                            decoration: BoxDecoration(
                              color: check.wcpm >= 40
                                  ? AppColors.mint
                                  : AppColors.sunshine,
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text('Green is 40+, the beginner benchmark.',
              style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}

class _Milestones extends StatelessWidget {
  const _Milestones({required this.entries});

  final List<Milestone> entries;

  @override
  Widget build(BuildContext context) {
    final recent = entries.reversed.take(6).toList();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      child: Column(
        children: [
          for (final entry in recent)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  const Text('🏅', style: TextStyle(fontSize: 20)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      entry.text,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Text(
                    '${entry.date.day}/${entry.date.month}',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Text(text, style: Theme.of(context).textTheme.titleLarge),
      );
}

class _GoalCard extends StatelessWidget {
  const _GoalCard({required this.progress});

  final ProgressState progress;

  @override
  Widget build(BuildContext context) {
    final minutes = (progress.secondsToday / 60).round();
    final goal = progress.dailyGoalMinutes;
    final ratio = goal == 0 ? 0.0 : (minutes / goal).clamp(0.0, 1.0).toDouble();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Today',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ),
              Text(
                progress.metGoalToday
                    ? '$minutes min  🎉'
                    : '$minutes of $goal min',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 12,
              backgroundColor: AppColors.inkSoft.withValues(alpha: 0.2),
              valueColor:
                  const AlwaysStoppedAnimation<Color>(AppColors.sunshine),
            ),
          ),
        ],
      ),
    );
  }
}

class _WorldRow extends StatelessWidget {
  const _WorldRow({
    required this.name,
    required this.levels,
    required this.progress,
    required this.onReplay,
  });

  final String name;
  final List<Level> levels;
  final ProgressState progress;
  final VoidCallback onReplay;

  @override
  Widget build(BuildContext context) {
    final done = levels.where((l) => progress.isFinished(l.id)).length;
    final total = levels.length;
    final paid =
        levels.isNotEmpty && progress.isWorldPaid(levels.first.worldIndex);

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                if (paid)
                  Text(
                    'Locked — included in the unlock',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
              ],
            ),
          ),
          SizedBox(
            width: 90,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: total == 0 ? 0 : done / total,
                minHeight: 10,
                backgroundColor: AppColors.inkSoft.withValues(alpha: 0.2),
                valueColor: const AlwaysStoppedAnimation<Color>(AppColors.mint),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text('$done/$total', style: Theme.of(context).textTheme.bodyMedium),
          IconButton(
            tooltip: 'Play this world again',
            icon: const Icon(Icons.replay_rounded),
            onPressed: done == 0 ? null : onReplay,
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadii.card),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 10),
            Text(
              value,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w800,
              ),
            ),
            Text(label, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }
}

class _WeekBars extends StatelessWidget {
  const _WeekBars({required this.minutes});

  final List<int> minutes;

  static const _labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

  @override
  Widget build(BuildContext context) {
    final maxValue = minutes.fold<int>(1, (m, v) => v > m ? v : m);
    final today = DateTime.now();

    return Container(
      height: 150,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List<Widget>.generate(minutes.length, (i) {
          final day = today.subtract(Duration(days: 6 - i));
          final label = _labels[(day.weekday - 1) % 7];
          final height = 12 + (minutes[i] / maxValue) * 78;
          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                '${minutes[i]}',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 6),
              Container(
                width: 26,
                height: height,
                decoration: BoxDecoration(
                  color: AppColors.skyDeep.withValues(
                    alpha: minutes[i] == 0 ? 0.2 : 0.85,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              const SizedBox(height: 6),
              Text(label, style: Theme.of(context).textTheme.bodyMedium),
            ],
          );
        }),
      ),
    );
  }
}
