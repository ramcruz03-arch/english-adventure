import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/checks_repository.dart';
import '../data/content_repository.dart';
import 'purchase/purchase_service.dart';
import '../data/models/level.dart';
import 'audio/sfx_service.dart';
import 'audio/speech_service.dart';
import 'storage/progress_store.dart';

/// Overridden in `main()` once SharedPreferences has loaded.
final sharedPreferencesProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('SharedPreferences not initialised'),
);

final contentRepositoryProvider =
    Provider<ContentRepository>((ref) => ContentRepository());

final levelsProvider = FutureProvider<List<Level>>(
  (ref) => ref.watch(contentRepositoryProvider).levels(),
);

final checksRepositoryProvider =
    Provider<ChecksRepository>((ref) => ChecksRepository());

/// Assessment material. Kept separate from the course on purpose: a reading
/// check must use a passage the child has never seen, or it measures memory
/// rather than reading.
final checksProvider =
    FutureProvider<({List<CheckPassage> reading, List<CheckWordSet> code})>(
  (ref) => ref.watch(checksRepositoryProvider).load(),
);

final progressProvider =
    StateNotifierProvider<ProgressController, ProgressState>(
  (ref) => ProgressController(ref.watch(sharedPreferencesProvider)),
);

final speechProvider = Provider<SpeechService>((ref) {
  final speech = SpeechService()..init();
  // Keep the voice in sync with the parent's sound and speed settings.
  speech.enabled = ref.watch(progressProvider.select((p) => p.soundOn));
  speech.rate = ref.watch(progressProvider.select((p) => p.voiceRate));
  ref.onDispose(speech.stop);
  return speech;
});

final sfxProvider = Provider<SfxService>((ref) {
  final sfx = SfxService();
  sfx.enabled = ref.watch(progressProvider.select((p) => p.soundOn));
  ref.onDispose(sfx.dispose);
  return sfx;
});

final purchaseServiceProvider = Provider<PurchaseService>((ref) {
  final service = PurchaseService();
  ref.onDispose(service.dispose);
  return service;
});
