import 'package:audioplayers/audioplayers.dart';

/// Short sound effects: the star sounds and the island flourish.
///
/// Separate from [SpeechService] on purpose — a chime should be able to ring
/// while Pip is still talking, and effects must never queue behind speech.
///
/// Every call is defensive: a device that cannot play audio simply stays
/// quiet rather than interrupting a child's turn with an error.
class SfxService {
  SfxService();

  final AudioPlayer _player = AudioPlayer(playerId: 'sfx');

  bool enabled = true;

  /// A star is awarded: a rising three-note sparkle.
  Future<void> starAward() => _play('audio/star_award.wav');

  /// The child touches the star: a bright glassy ping.
  Future<void> starTouch() => _play('audio/star_touch.wav');

  /// An island is finished.
  Future<void> islandComplete() => _play('audio/island_complete.wav');

  Future<void> _play(String asset) async {
    if (!enabled) return;
    try {
      await _player.stop();
      await _player.play(AssetSource(asset), volume: 0.9);
    } catch (_) {
      // No audio on this device: carry on silently.
    }
  }

  Future<void> dispose() async {
    try {
      await _player.dispose();
    } catch (_) {}
  }
}
