# English Adventure 4.0

A gentle, playful systematic-phonics adventure for beginner readers.

## 4.0 focus
- Magic Garden adventure map
- Anil companion/avatar
- Stars, stickers and treasure language
- Calm, non-punitive child experience
- Systematic phonics, blending, reading and tracing
- Offline-first local progress with SQLite
- Child-safe parent area
- Flutter CI with Android APK/AAB build gates

## Run locally
```bash
flutter pub get
flutter analyze
flutter test
dart run tools/validate_content.dart
flutter run
```
