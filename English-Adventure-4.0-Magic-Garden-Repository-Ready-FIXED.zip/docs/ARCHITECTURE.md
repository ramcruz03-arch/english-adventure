# Architecture

Presentation: Flutter widgets + Riverpod.
Persistence: SQLite via sqflite.
Content: JSON under `assets/content`.
Audio: FlutterTTS abstraction.
Features: garden, phonics, writing, story, parent.

Adaptive-learning direction: record attempts, review low-accuracy skills, replay/hint after errors, demonstrate after repeated errors, do not use speed as primary mastery evidence, and interleave review with new learning.

The child UI never exposes mastery labels or rankings.
