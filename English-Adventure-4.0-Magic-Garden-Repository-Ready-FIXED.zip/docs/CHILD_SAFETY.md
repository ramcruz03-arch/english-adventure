# Child safety
- No public profiles or messaging
- No public leaderboards
- No ads in child mode
- No external links in child mode
- Parent gate for settings, purchases and external links
- Minimal personal data
- Offline-first learning
- No diagnosis or clinical claims
- No punishment, shame or negative performance labels
