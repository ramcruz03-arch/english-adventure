# English Adventure 4.0 visual design system

Magic Garden is warm, organic, playful and low-pressure.

- Leaf `#3E8E5B`
- Deep leaf `#24613C`
- Cream `#FFF9E9`
- Sun `#FFD45E`
- Peach `#FFC9A8`
- Soft green `#DDF2CF`
- Ink `#263238`

Large tap targets, one primary action per learning card, gentle feedback, no countdowns, and progress expressed through growth, stars, stickers and treasure.
