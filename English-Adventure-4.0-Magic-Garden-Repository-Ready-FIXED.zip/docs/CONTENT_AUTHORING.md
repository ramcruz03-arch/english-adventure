# Content authoring
1. Teach required sounds before using them in new decodable words.
2. Use familiar, unambiguous pictures.
3. Keep instructions short and narratable.
4. Review previously taught sounds frequently.
5. Mark irregular sight words explicitly.
6. Keep stories within taught patterns where possible.
7. Have production content reviewed by a qualified literacy/phonics educator.
