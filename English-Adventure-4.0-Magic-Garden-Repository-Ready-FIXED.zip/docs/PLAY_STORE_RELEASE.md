# Play Store release plan

- Generate Android platform files with `flutter create --platforms=android .` when absent.
- Set the permanent application ID before publishing.
- Keep release keystore material outside the repository.
- Build and test an Android App Bundle with `flutter build appbundle --release`.
- Complete Play Console child-safety and data-safety declarations.
- Prepare screenshots, app icon, feature graphic and privacy policy URL.
- Use closed testing before production rollout.
