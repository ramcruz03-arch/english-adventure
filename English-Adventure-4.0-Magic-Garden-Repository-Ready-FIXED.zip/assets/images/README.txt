Production assets: Anil character sheet, garden map, stickers, treasure chest, lesson illustrations, icons, audio references.
