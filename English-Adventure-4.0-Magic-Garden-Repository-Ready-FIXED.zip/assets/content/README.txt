Add new lessons/stories as JSON. Keep decodable stories within already-taught phonics patterns.
