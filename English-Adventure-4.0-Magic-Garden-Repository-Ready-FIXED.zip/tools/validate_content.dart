import 'dart:convert';
import 'dart:io';

void main() {
  final lessons =
      jsonDecode(File('assets/content/lessons.json').readAsStringSync()) as List;
  final stories =
      jsonDecode(File('assets/content/stories.json').readAsStringSync()) as List;
  final errors = <String>[];
  final seenSkills = <String>{};

  for (final raw in lessons) {
    final l = raw as Map<String, dynamic>;
    final id = l['id'];
    final skill = l['skill'];

    if (id is! String || id.isEmpty) {
      errors.add('Lesson missing id');
    }
    if (skill is! String || skill.isEmpty) {
      errors.add('Lesson $id missing skill');
    }
    if (skill is String && !seenSkills.add(skill)) {
      errors.add('Duplicate skill: $skill');
    }

    final activities = l['activities'];
    if (activities is! List || activities.isEmpty) {
      errors.add('Lesson $id has no activities');
    }

    if (activities is List) {
      for (final rawA in activities) {
        final a = rawA as Map<String, dynamic>;
        final options = a['options'];
        final answer = a['answer'];

        if (options is! List || options.isEmpty) {
          errors.add('Lesson $id has no options');
        }
        if (options is List && !options.contains(answer)) {
          errors.add('Lesson $id answer not in options');
        }
      }
    }
  }

  for (final raw in stories) {
    final s = raw as Map<String, dynamic>;
    final id = s['id'];

    if (id is! String || id.isEmpty) {
      errors.add('Story missing id');
    }
    if (s['sentences'] is! List || (s['sentences'] as List).isEmpty) {
      errors.add('Story $id has no sentences');
    }
    if (s['options'] is! List || (s['options'] as List).isEmpty) {
      errors.add('Story $id has no options');
    }
    if (s['options'] is List &&
        !(s['options'] as List).contains(s['answer'])) {
      errors.add('Story $id answer not in options');
    }
  }

  if (errors.isNotEmpty) {
    stderr.writeln(errors.join('\n'));
    exitCode = 1;
  } else {
    stdout.writeln(
      'Content validation passed: ${lessons.length} lessons, '
      '${stories.length} stories.',
    );
  }
}
