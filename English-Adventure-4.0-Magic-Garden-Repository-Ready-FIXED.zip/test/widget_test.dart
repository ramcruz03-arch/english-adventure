import 'package:flutter_test/flutter_test.dart';
import 'package:english_adventure/app/app.dart';

void main() {
  testWidgets('opens in Garden', (tester) async {
    await tester.pumpWidget(const EnglishAdventureApp());
    expect(find.text('Magic Garden'), findsOneWidget);
    expect(find.text('Hello, Explorer!'), findsOneWidget);
  });

  testWidgets('parent area is gated', (tester) async {
    await tester.pumpWidget(const EnglishAdventureApp());
    await tester.tap(find.text('Parents'));
    await tester.pumpAndSettle();
    expect(find.text('Open Parent Dashboard'), findsOneWidget);
  });
}
