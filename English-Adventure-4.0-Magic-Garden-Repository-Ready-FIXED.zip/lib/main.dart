import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app/app.dart';
import 'core/audio/audio_service.dart';
import 'core/database/app_database.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final database = await AppDatabase.open();
  final audio = AudioService();
  await audio.init();
  runApp(
    ProviderScope(
      overrides: [
        databaseProvider.overrideWithValue(database),
        audioServiceProvider.overrideWithValue(audio),
      ],
      child: const EnglishAdventureApp(),
    ),
  );
}
