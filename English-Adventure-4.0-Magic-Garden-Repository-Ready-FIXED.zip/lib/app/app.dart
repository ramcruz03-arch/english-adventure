import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../features/garden/garden_screen.dart';
import '../features/parent/parent_screen.dart';
import '../features/phonics/lesson_screen.dart';
import '../features/story/story_screen.dart';

class EnglishAdventureApp extends StatelessWidget {
  const EnglishAdventureApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'English Adventure', debugShowCheckedModeBanner: false,
    theme: buildAdventureTheme(), home: const AppShell(),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState() => _AppShellState();
}
class _AppShellState extends State<AppShell> {
  int index = 0;
  void go(int value) => setState(() => index = value);
  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      GardenScreen(onPhonics: () => go(1), onStory: () => go(2)),
      const LessonScreen(), const StoryScreen(), const ParentScreen(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: go, destinations: const [
        NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Garden'),
        NavigationDestination(icon: Icon(Icons.auto_stories_outlined), selectedIcon: Icon(Icons.auto_stories), label: 'Learn'),
        NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Story'),
        NavigationDestination(icon: Icon(Icons.family_restroom_outlined), selectedIcon: Icon(Icons.family_restroom), label: 'Parents'),
      ]),
    );
  }
}
