class Lesson {
  final String id;
  final int stage;
  final String title;
  final String skill;
  final String instruction;
  final String? letter;
  final String? sound;
  final List<ActivityData> activities;

  const Lesson({required this.id, required this.stage, required this.title, required this.skill, required this.instruction, this.letter, this.sound, required this.activities});

  factory Lesson.fromJson(Map<String, dynamic> j) => Lesson(
    id: j['id'],
    stage: j['stage'],
    title: j['title'],
    skill: j['skill'],
    instruction: j['instruction'],
    letter: j['letter'],
    sound: j['sound'],
    activities: (j['activities'] as List).map((e) => ActivityData.fromJson(e)).toList(),
  );
}

class ActivityData {
  final String type;
  final String prompt;
  final List<String> options;
  final String answer;
  final String? word;
  final String? imageLabel;

  const ActivityData({required this.type, required this.prompt, required this.options, required this.answer, this.word, this.imageLabel});

  factory ActivityData.fromJson(Map<String, dynamic> j) => ActivityData(
    type: j['type'],
    prompt: j['prompt'],
    options: List<String>.from(j['options'] ?? const []),
    answer: j['answer'],
    word: j['word'],
    imageLabel: j['imageLabel'],
  );
}
