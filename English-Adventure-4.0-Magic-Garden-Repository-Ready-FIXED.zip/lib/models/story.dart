class Story {
  final String id;
  final String title;
  final String level;
  final List<String> sentences;
  final String question;
  final List<String> options;
  final String answer;

  const Story({required this.id, required this.title, required this.level, required this.sentences, required this.question, required this.options, required this.answer});

  factory Story.fromJson(Map<String, dynamic> j) => Story(
    id: j['id'],
    title: j['title'],
    level: j['level'],
    sentences: List<String>.from(j['sentences']),
    question: j['question'],
    options: List<String>.from(j['options']),
    answer: j['answer'],
  );
}
