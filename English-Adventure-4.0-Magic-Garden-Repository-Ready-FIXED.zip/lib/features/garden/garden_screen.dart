import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/providers.dart';
import '../../widgets/anil_avatar.dart';
import '../../widgets/garden_map.dart';
import '../../widgets/reward_card.dart';
import '../../widgets/star_pill.dart';

class GardenScreen extends ConsumerWidget {
  final VoidCallback onPhonics;
  final VoidCallback onStory;
  const GardenScreen({super.key, required this.onPhonics, required this.onStory});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(dashboardStatsProvider);
    final stars = stats.value?['rewards'] as int? ?? 0;
    return LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth > 720;
      return SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: wide ? 48 : 18, vertical: 18),
        child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 980), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const AnilAvatar(), const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Hello, Explorer!', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
              Text('Anil is waiting for you 🌱', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
            ])),
            StarPill(stars: stars),
          ]),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFDDF4D3), Color(0xFFFFF0C5)]), borderRadius: BorderRadius.circular(30)),
            child: Row(children: const [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Today’s tiny adventure', style: TextStyle(fontWeight: FontWeight.w700)),
                SizedBox(height: 5), Text('The Sound Garden', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                SizedBox(height: 8), Text('Listen • blend • read • celebrate', style: TextStyle(fontSize: 15)),
              ])),
              Text('🌈', style: TextStyle(fontSize: 66)),
            ]),
          ),
          const SizedBox(height: 22),
          const Text('Adventure Map', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10), GardenMap(onPhonics: onPhonics, onStory: onStory),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: RewardCard(icon: '⭐', title: 'Stars', value: '$stars')), const SizedBox(width: 10),
            const Expanded(child: RewardCard(icon: '🎟️', title: 'Stickers', value: '7')), const SizedBox(width: 10),
            const Expanded(child: RewardCard(icon: '🧰', title: 'Treasures', value: '2')),
          ]),
          const SizedBox(height: 18),
          const Card(child: Padding(padding: EdgeInsets.all(18), child: Row(children: [
            Text('💚', style: TextStyle(fontSize: 28)), SizedBox(width: 12),
            Expanded(child: Text('No rush. Try again whenever you need. Learning grows one happy step at a time.', style: TextStyle(fontWeight: FontWeight.w700, height: 1.4))),
          ]))),
        ]))),
      );
    });
  }
}
