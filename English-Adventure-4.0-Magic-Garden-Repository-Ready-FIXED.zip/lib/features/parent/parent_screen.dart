import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/providers.dart';

class ParentScreen extends ConsumerWidget {
  const ParentScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(dashboardStatsProvider);
    return SingleChildScrollView(padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 820), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Parent Progress', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
      const SizedBox(height: 5), const Text('A calm snapshot of today’s learning.'), const SizedBox(height: 20),
      stats.when(
        loading: () => const LinearProgressIndicator(),
        error: (_, __) => const Text('Progress is getting ready.'),
        data: (s) => Row(children: [
          Expanded(child: _Stat(title: 'Stars', value: '${s['rewards']}', icon: '⭐')), const SizedBox(width: 10),
          Expanded(child: _Stat(title: 'Sessions', value: '${s['sessions']}', icon: '📚')), const SizedBox(width: 10),
          Expanded(child: _Stat(title: 'Skills tracked', value: '${s['tracked']}', icon: '🌱')),
        ]),
      ),
      const SizedBox(height: 20),
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('Learning path', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), SizedBox(height: 12),
        _Progress(label: 'Letter sounds', value: .78), _Progress(label: 'Blending', value: .48),
        _Progress(label: 'Reading', value: .35), _Progress(label: 'Writing', value: .28),
      ]))),
      const SizedBox(height: 14),
      const Card(child: Padding(padding: EdgeInsets.all(18), child: Row(children: [
        Text('💡', style: TextStyle(fontSize: 30)), SizedBox(width: 12),
        Expanded(child: Text('Short, happy practice is enough. Celebrate effort, retries and confidence—not just correct answers.', style: TextStyle(fontWeight: FontWeight.w700, height: 1.4))),
      ]))),
    ]))));
  }
}
class _Stat extends StatelessWidget {
  final String title, value, icon; const _Stat({required this.title, required this.value, required this.icon});
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [Text(icon, style: const TextStyle(fontSize: 25)), const SizedBox(height: 4), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), Text(title, style: const TextStyle(fontSize: 12))])));
}
class _Progress extends StatelessWidget {
  final String label; final double value; const _Progress({required this.label, required this.value});
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label, style: const TextStyle(fontWeight: FontWeight.w700)), Text('${(value * 100).round()}%')]),
    const SizedBox(height: 5), LinearProgressIndicator(value: value, minHeight: 8, borderRadius: BorderRadius.circular(20)),
  ]));
}
