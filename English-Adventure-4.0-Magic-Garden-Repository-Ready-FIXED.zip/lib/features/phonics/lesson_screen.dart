import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/audio/audio_service.dart';
import '../../core/database/app_database.dart';
import '../../providers/providers.dart';
import '../writing/tracing_screen.dart';

class LessonScreen extends ConsumerStatefulWidget {
  const LessonScreen({super.key});
  @override
  ConsumerState<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends ConsumerState<LessonScreen> {
  int lessonIndex = 0;
  int attempts = 0;

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(lessonsProvider);
    return async.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (_, __) => const Center(child: Text('We could not open this adventure yet.')),
      data: (lessons) {
        final lesson = lessons[lessonIndex.clamp(0, lessons.length - 1)];
        final a = lesson.activities.first;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Center(child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: Column(children: [
              Row(children: [
                IconButton(onPressed: () => Navigator.maybePop(context), icon: const Icon(Icons.arrow_back)),
                Expanded(child: Text(lesson.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
                IconButton(onPressed: () => ref.read(audioServiceProvider).speak('${lesson.letter ?? ''} ${lesson.sound ?? ''}'), icon: const Icon(Icons.volume_up)),
              ]),
              const SizedBox(height: 14),
              const LinearProgressIndicator(value: .45, minHeight: 8),
              const SizedBox(height: 24),
              Card(child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(children: [
                  Text(a.prompt, textAlign: TextAlign.center, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 18),
                  if (lesson.letter != null) Text(lesson.letter!, style: const TextStyle(fontSize: 92, fontWeight: FontWeight.w900)),
                  if (lesson.sound != null) Text(lesson.sound!, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
                  if (a.imageLabel != null) Text(a.imageLabel!, style: const TextStyle(fontSize: 60)),
                  const SizedBox(height: 18),
                  Wrap(
                    spacing: 12, runSpacing: 12,
                    children: a.options.map((o) => FilledButton.tonal(
                      onPressed: () => _answer(lesson.skill, a.answer, o, lessons.length),
                      child: Text(o, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
                    )).toList(),
                  ),
                  if (a.type == 'trace') Padding(
                    padding: const EdgeInsets.only(top: 18),
                    child: FilledButton.icon(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TracingScreen(target: lesson.letter ?? 'A', skillId: lesson.skill))),
                      icon: const Icon(Icons.gesture),
                      label: const Text('Trace it'),
                    ),
                  ),
                ]),
              )),
              const SizedBox(height: 16),
              const Text('No rush. We can try it together. 🌱', style: TextStyle(fontStyle: FontStyle.italic)),
            ]),
          )),
        );
      },
    );
  }

  Future<void> _answer(String skill, String answer, String choice, int total) async {
    final correct = choice == answer;
    attempts++;
    await ref.read(databaseProvider).recordAttempt(skillId: skill, correct: correct, hintUsed: !correct);
    await ref.read(audioServiceProvider).speak(
      correct ? 'Great listening!' : attempts >= 2 ? 'Let’s try it together. The answer is $answer.' : 'Almost there. Listen carefully.',
    );
    if (!correct && attempts < 2) return;
    await ref.read(databaseProvider).addReward('star-$skill');
    ref.invalidate(progressProvider);
    if (lessonIndex < total - 1) {
      setState(() { lessonIndex++; attempts = 0; });
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Wonderful effort! You earned a star ⭐')));
    }
  }
}
