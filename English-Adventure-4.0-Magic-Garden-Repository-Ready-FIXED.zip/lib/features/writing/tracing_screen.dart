import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/database/app_database.dart';
import '../../providers/providers.dart';

class TracingScreen extends ConsumerStatefulWidget {
  final String target;
  final String skillId;
  const TracingScreen({super.key, required this.target, required this.skillId});
  @override
  ConsumerState<TracingScreen> createState() => _TracingScreenState();
}

class _TracingScreenState extends ConsumerState<TracingScreen> {
  final points = <Offset>[];

  Future<void> finish() async {
    final success = points.length >= 8;
    await ref.read(databaseProvider).recordAttempt(
      skillId: '${widget.skillId}_writing',
      correct: success,
      hintUsed: !success,
    );
    ref.invalidate(progressProvider);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? 'Wonderful tracing! ⭐' : 'Nice try! Let’s practise it together.')),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Write ${widget.target}'), actions: [
      IconButton(onPressed: () => setState(points.clear), icon: const Icon(Icons.refresh)),
    ]),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        const Text('Follow the shape with your finger.', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 15),
        Expanded(
          child: GestureDetector(
            onPanStart: (d) => setState(() => points.add(d.localPosition)),
            onPanUpdate: (d) => setState(() => points.add(d.localPosition)),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
              child: CustomPaint(painter: _TracePainter(widget.target, points)),
            ),
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: finish, icon: const Icon(Icons.star), label: const Text('I’m ready!'))),
      ]),
    ),
  );
}

class _TracePainter extends CustomPainter {
  final String target;
  final List<Offset> points;
  _TracePainter(this.target, this.points);

  @override
  void paint(Canvas canvas, Size size) {
    final text = TextPainter(
      text: TextSpan(text: target, style: TextStyle(fontSize: size.shortestSide * .55, fontWeight: FontWeight.w900, color: const Color(0xFFDEE4DD))),
      textDirection: TextDirection.ltr,
    )..layout();
    text.paint(canvas, Offset((size.width - text.width) / 2, (size.height - text.height) / 2));
    final p = Paint()..color = const Color(0xFF2E8B57)..strokeWidth = 10..strokeCap = StrokeCap.round;
    for (var i = 1; i < points.length; i++) canvas.drawLine(points[i - 1], points[i], p);
  }

  @override
  bool shouldRepaint(covariant _TracePainter oldDelegate) => true;
}
