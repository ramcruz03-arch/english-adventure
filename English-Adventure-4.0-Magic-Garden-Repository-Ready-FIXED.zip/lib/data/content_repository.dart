import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/lesson.dart';
import '../models/story.dart';

class ContentRepository {
  Future<List<Lesson>> lessons() async {
    final raw = await rootBundle.loadString('assets/content/lessons.json');
    return (jsonDecode(raw) as List).map((e) => Lesson.fromJson(e)).toList();
  }

  Future<List<Story>> stories() async {
    final raw = await rootBundle.loadString('assets/content/stories.json');
    return (jsonDecode(raw) as List).map((e) => Story.fromJson(e)).toList();
  }
}
