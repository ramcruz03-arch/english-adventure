import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/content_repository.dart';
import '../core/database/app_database.dart';

final contentRepositoryProvider = Provider<ContentRepository>((ref) => ContentRepository());

final lessonsProvider = FutureProvider((ref) => ref.watch(contentRepositoryProvider).lessons());
final storiesProvider = FutureProvider((ref) => ref.watch(contentRepositoryProvider).stories());
final progressProvider = FutureProvider((ref) => ref.watch(databaseProvider).progress());

final dashboardStatsProvider = FutureProvider((ref) async {
  final db = ref.watch(databaseProvider);
  final p = await db.progress();
  final sessions = await db.completedSessions();
  final rewards = await db.rewardCount();
  return {
    'mastered': p.where((r) => ((r['mastery'] as num?) ?? 0) >= 80).length,
    'sessions': sessions,
    'rewards': rewards,
    'tracked': p.length,
  };
});
