import 'package:flutter/material.dart';

class RewardCard extends StatelessWidget {
  final String icon;
  final String title;
  final String value;
  const RewardCard({super.key, required this.icon, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          Text(icon, style: const TextStyle(fontSize: 26)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          Text(title, style: const TextStyle(fontSize: 12)),
        ]),
      ),
    );
  }
}
