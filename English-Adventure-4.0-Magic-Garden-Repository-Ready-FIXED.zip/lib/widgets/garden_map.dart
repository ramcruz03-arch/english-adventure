import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class GardenMap extends StatelessWidget {
  final VoidCallback onPhonics;
  final VoidCallback onStory;
  const GardenMap({super.key, required this.onPhonics, required this.onStory});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 310,
      decoration: BoxDecoration(
        color: AdventureColors.softGreen,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0xFFB9D99D), width: 2),
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: _GardenPainter())),
          Positioned(left: 22, top: 26, child: _Node(label: 'Sounds', icon: '🔊', onTap: onPhonics)),
          const Positioned(left: 132, top: 108, child: _Node(label: 'Words', icon: '🧩')),
          const Positioned(right: 28, top: 38, child: _Node(label: 'Writing', icon: '✏️')),
          Positioned(right: 60, bottom: 26, child: _Node(label: 'Story', icon: '📖', onTap: onStory)),
          Positioned(
            left: 18,
            bottom: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: .9), borderRadius: BorderRadius.circular(14)),
              child: const Text('Every little step counts!', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ),
        ],
      ),
    );
  }
}

class _Node extends StatelessWidget {
  final String label;
  final String icon;
  final VoidCallback? onTap;
  const _Node({required this.label, required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    final unlocked = onTap != null;
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 72,
            height: 72,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: unlocked ? AdventureColors.sun : const Color(0xFFD5DDD0),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 4),
              boxShadow: const [BoxShadow(blurRadius: 9, offset: Offset(0, 4), color: Color(0x22000000))],
            ),
            child: Text(unlocked ? icon : '🔒', style: const TextStyle(fontSize: 30)),
          ),
          const SizedBox(height: 5),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _GardenPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFFCFE8B4));
    final path = Paint()
      ..color = const Color(0xFFE8D7A5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 20
      ..strokeCap = StrokeCap.round;
    final curve = Path()
      ..moveTo(50, 78)
      ..cubicTo(180, 25, 215, 190, 350, 145)
      ..cubicTo(440, 115, 430, 230, 560, 205);
    canvas.drawPath(curve, path);

    final leaf = Paint()..color = const Color(0xFF62A35E);
    final trunk = Paint()..color = const Color(0xFF8A5A44);
    for (final o in [Offset(90, size.height - 65), const Offset(310, 48), Offset(size.width - 55, 95)]) {
      canvas.drawCircle(o, 26, leaf);
      canvas.drawRect(Rect.fromCenter(center: o.translate(0, 28), width: 9, height: 34), trunk);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
