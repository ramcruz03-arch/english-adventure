import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class AnilAvatar extends StatelessWidget {
  final double size;
  const AnilAvatar({super.key, this.size = 72});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AdventureColors.sun,
        border: Border.all(color: Colors.white, width: 4),
        boxShadow: const [BoxShadow(blurRadius: 12, offset: Offset(0, 5), color: Color(0x22000000))],
      ),
      alignment: Alignment.center,
      child: Text('👦', style: TextStyle(fontSize: size * .52)),
    );
  }
}
