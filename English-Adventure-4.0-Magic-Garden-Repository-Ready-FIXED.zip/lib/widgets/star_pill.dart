import 'package:flutter/material.dart';

class StarPill extends StatelessWidget {
  final int stars;
  const StarPill({super.key, required this.stars});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF0A8),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Text('⭐ $stars', style: const TextStyle(fontWeight: FontWeight.w900)),
    );
  }
}
