import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

final databaseProvider = Provider<AppDatabase>((ref) => throw UnimplementedError());

class AppDatabase {
  final Database db;
  AppDatabase._(this.db);

  static Future<AppDatabase> open() async {
    final path = join(await getDatabasesPath(), 'english_adventure.db');
    final db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute(
          'CREATE TABLE child_progress(id INTEGER PRIMARY KEY AUTOINCREMENT, skill_id TEXT NOT NULL UNIQUE, attempts INTEGER NOT NULL DEFAULT 0, correct INTEGER NOT NULL DEFAULT 0, hints INTEGER NOT NULL DEFAULT 0, mastery REAL NOT NULL DEFAULT 0, updated_at TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT NOT NULL, duration_seconds INTEGER NOT NULL DEFAULT 0, completed INTEGER NOT NULL DEFAULT 0)',
        );
        await db.execute(
          'CREATE TABLE rewards(id INTEGER PRIMARY KEY AUTOINCREMENT, reward_id TEXT NOT NULL UNIQUE, earned_at TEXT NOT NULL)',
        );
      },
    );
    return AppDatabase._(db);
  }

  Future<void> recordAttempt({required String skillId, required bool correct, bool hintUsed = false}) async {
    final rows = await db.query('child_progress', where: 'skill_id = ?', whereArgs: [skillId], limit: 1);
    final now = DateTime.now().toIso8601String();
    if (rows.isEmpty) {
      await db.insert('child_progress', {
        'skill_id': skillId,
        'attempts': 1,
        'correct': correct ? 1 : 0,
        'hints': hintUsed ? 1 : 0,
        'mastery': correct ? 20.0 : 0.0,
        'updated_at': now,
      });
      return;
    }
    final r = rows.first;
    final attempts = (r['attempts'] as int) + 1;
    final correctCount = (r['correct'] as int) + (correct ? 1 : 0);
    final hints = (r['hints'] as int) + (hintUsed ? 1 : 0);
    final mastery = ((correctCount / attempts) * 100).clamp(0.0, 100.0);
    await db.update(
      'child_progress',
      {'attempts': attempts, 'correct': correctCount, 'hints': hints, 'mastery': mastery, 'updated_at': now},
      where: 'skill_id = ?',
      whereArgs: [skillId],
    );
  }

  Future<List<Map<String, Object?>>> progress() => db.query('child_progress', orderBy: 'updated_at DESC');

  Future<int> completedSessions() async {
    final r = await db.rawQuery('SELECT COUNT(*) AS count FROM sessions WHERE completed = 1');
    return (r.first['count'] as int?) ?? 0;
  }

  Future<void> addReward(String rewardId) => db.insert(
    'rewards',
    {'reward_id': rewardId, 'earned_at': DateTime.now().toIso8601String()},
    conflictAlgorithm: ConflictAlgorithm.ignore,
  );

  Future<int> rewardCount() async {
    final r = await db.rawQuery('SELECT COUNT(*) AS count FROM rewards');
    return (r.first['count'] as int?) ?? 0;
  }
}
