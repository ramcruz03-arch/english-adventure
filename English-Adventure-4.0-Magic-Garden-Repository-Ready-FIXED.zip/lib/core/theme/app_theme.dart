import 'package:flutter/material.dart';

class AdventureColors {
  static const leaf = Color(0xFF3E8E5B);
  static const leafDark = Color(0xFF24613C);
  static const sky = Color(0xFFE7F5FF);
  static const cream = Color(0xFFFFF9E9);
  static const sun = Color(0xFFFFD45E);
  static const peach = Color(0xFFFFC9A8);
  static const ink = Color(0xFF263238);
  static const softGreen = Color(0xFFDDF2CF);
}

ThemeData buildAdventureTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AdventureColors.leaf,
    brightness: Brightness.light,
  ).copyWith(
    primary: AdventureColors.leaf,
    onPrimary: Colors.white,
    secondary: AdventureColors.sun,
    surface: Colors.white,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AdventureColors.cream,
    fontFamily: 'Arial',
    cardTheme: CardThemeData(
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    ),
    navigationBarTheme: const NavigationBarThemeData(
      height: 72,
      labelTextStyle: WidgetStatePropertyAll(
        TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
      ),
    ),
  );
}
