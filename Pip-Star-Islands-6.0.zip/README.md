# Pip and the Star Islands (English Adventure 6.0)

A playful phonics adventure for children beginning to read and write English.
Flutter, offline-first, no ads, no accounts, no tracking.

60 islands across six worlds: Letter Village, Sound Forest, Blending Bridge,
Word Forest, Sentence Town, Story Castle. Six hands-on activity types —
meet a letter, tap word cards, drag letters to spell, trace with a finger,
find the target on a mission, read a story and answer one gentle question.

## Run it

```bash
flutter pub get
flutter run
```

The GitHub Actions workflow in `.github/workflows/build.yml` produces a
release APK. It calls `flutter create --platforms=android .` if the android/
folder is missing, so this zip does not need to carry platform files.

The pubspec is still named `english_adventure` so the existing workflow and
repo keep working. "Pip and the Star Islands" is the display name.

## Layout

```
lib/
  main.dart                 entry point, loads storage then runs the app
  app/app.dart              MaterialApp, theme, text-scale clamp
  core/
    copy.dart               every child-facing word, in one place
    letter_strokes.dart     letter shapes used by tracing
    providers.dart          Riverpod wiring
    audio/                  text-to-speech
    storage/                progress state + local persistence
    theme/                  colours, type, background
  data/
    models/level.dart       Level, Collectible, sealed LessonStep types
    content_repository.dart loads assets/content/levels.json
  features/
    setup/                  first-run "where should we start?" (grown-up)
    map/                    island map (home), grouped by world
    lesson/                 lesson flow + one file per activity
    reward/                 collectible celebration
    parent/                 PIN gate + progress dashboard
  widgets/                  buttons, mascot, stars, confetti
assets/content/levels.json  all learning content (60 islands)
tools/generate_content.py   regenerates levels.json from curated word lists
tools/validate_content.dart content checks, run in CI
```

Adding a level is a JSON edit. See `docs/CONTENT_AUTHORING.md`.
