# Adding content

All learning content lives in `assets/content/levels.json`. No Dart changes
are needed to add an island.

## An island

```json
{
  "id": "l61_q",
  "index": 61,
  "world": "Word Forest",
  "worldIndex": 4,
  "title": "Goat Hill",
  "subtitle": "Meet g",
  "emoji": "🐐",
  "color": "#FFB703",
  "reward": { "id": "goat_bell", "name": "Goat Bell", "emoji": "🔔" },
  "steps": [ ... ]
}
```

Islands unlock in `index` order. Keep 4–5 steps: about 3–5 minutes of play.

## Step types

| type | fields | what the child does |
|---|---|---|
| `letterIntro` | letter, sound, exampleWord, exampleEmoji, say | hears the sound, taps the letter |
| `wordCard` | prompt, words[{text, emoji}] | taps each card to hear the word and its letters |
| `spell` | word, emoji, distractors[] | drags letter tiles into the word |
| `trace` | letter, say | traces the letter with a finger |
| `mission` | prompt, target, options[] | finds every target bubble |
| `story` | emoji, sentences[], question, options[], answer | taps each line to hear it, then answers one question |

## Rules the validator enforces

- unique level ids and reward ids
- every island has a world and worldIndex
- story answers must be one of the story options
- colour in `#RRGGBB` form
- at most 6 steps per island
- `trace` letters must have strokes in `lib/core/letter_strokes.dart`
- `spell` words of 4 letters or fewer
- `mission` targets must appear in the options

Run it: `dart run tools/validate_content.dart`

## Regenerating everything

`python3 tools/generate_content.py` rebuilds `levels.json` from the curated
letter/word/sentence tables at the top of that script. Edit the tables, not
the JSON, when you want to change wording or add a world.

## Adding a new letter shape

All 26 lowercase letters already have strokes in
`lib/core/letter_strokes.dart`. For digraphs or capitals, add an entry there
(a list of strokes; each stroke is a list of points in a 0..1 box, y
downwards) and add the key to `traceableLetters` in the validator.

## Adding a new activity type

1. Add a subclass of `LessonStep` in `lib/data/models/level.dart` and a case
   in `LessonStep.fromJson`.
2. Add a view under `lib/features/lesson/steps/`.
3. Add the case to `_viewFor` in `lesson_screen.dart` — the compiler will
   tell you if you forget, because `LessonStep` is sealed.
