#!/usr/bin/env python3
"""Generates assets/content/levels.json for Pip and the Star Islands 6.0.

Curriculum skeleton follows the 6-world sequence from English Adventure 5.1
(Letter Village -> Sound Forest -> Blending Bridge -> Word Forest ->
Sentence Town -> Story Castle), rebuilt into hands-on activity types and with
every picture/word pair hand-checked.
"""

import json, random

random.seed(7)

PLACES = ["Cove", "Bay", "Point", "Beach", "Nook", "Hill",
          "Shore", "Isle", "Reef", "Sands", "Lagoon", "Cliff"]

PALETTE = ["#FFB703", "#EF476F", "#06D6A0", "#118AB2", "#9B5DE5", "#FF7F51",
           "#8AC926", "#3A86FF", "#F72585", "#7209B7", "#2FD08D", "#FB8500"]

WORLDS = [
    ("Letter Village", "🏝️", "Shell", "🐚"),
    ("Sound Forest", "🌴", "Leaf", "🍃"),
    ("Blending Bridge", "🌉", "Bead", "🔷"),
    ("Word Forest", "🌳", "Acorn", "🌰"),
    ("Sentence Town", "🏘️", "Key", "🗝️"),
    ("Story Castle", "🏰", "Star", "⭐"),
]

# letter -> (spoken sound, [(word, emoji), (word, emoji)])
LETTERS = {
    "s": ("sss", [("sun", "🌞"), ("sock", "🧦")]),
    "a": ("ah", [("apple", "🍎"), ("ant", "🐜")]),
    "t": ("t", [("turtle", "🐢"), ("tree", "🌳")]),
    "p": ("p", [("pig", "🐷"), ("pen", "🖊️")]),
    "i": ("ih", [("igloo", "🧊"), ("ink", "🖋️")]),
    "n": ("nnn", [("nest", "🪺"), ("nose", "👃")]),
    "m": ("mmm", [("moon", "🌙"), ("mouse", "🐭")]),
    "d": ("d", [("dog", "🐶"), ("duck", "🦆")]),
    "g": ("g", [("goat", "🐐"), ("grapes", "🍇")]),
    "o": ("o", [("octopus", "🐙"), ("orange", "🍊")]),
    "c": ("k", [("cat", "🐱"), ("cake", "🍰")]),
    "k": ("k", [("key", "🔑"), ("kite", "🪁")]),
    "e": ("eh", [("egg", "🥚"), ("elephant", "🐘")]),
    "u": ("uh", [("umbrella", "☂️"), ("up", "⬆️")]),
    "r": ("rrr", [("rainbow", "🌈"), ("rabbit", "🐇")]),
    "h": ("h", [("hat", "🎩"), ("house", "🏠")]),
    "b": ("b", [("bee", "🐝"), ("bus", "🚌")]),
    "f": ("fff", [("fish", "🐟"), ("flower", "🌸")]),
    "l": ("lll", [("lion", "🦁"), ("leaf", "🍃")]),
    "j": ("j", [("juice", "🧃"), ("jam", "🍯")]),
    "v": ("vvv", [("van", "🚐"), ("violin", "🎻")]),
    "w": ("wuh", [("wave", "🌊"), ("watch", "⌚")]),
    "y": ("yuh", [("yo-yo", "🪀"), ("yarn", "🧶")]),
    "z": ("zzz", [("zebra", "🦓"), ("zip", "🤐")]),
}

WORLD1 = ["s", "a", "t", "p", "i", "n", "m", "d", "g", "o", "c", "k"]
WORLD2 = ["e", "u", "r", "h", "b", "f", "l", "j", "v", "w", "y", "z"]

# family -> words in it
FAMILIES = [
    ("at", [("cat", "🐱"), ("hat", "🎩"), ("bat", "🦇")]),
    ("an", [("van", "🚐"), ("fan", "🪭"), ("pan", "🍳")]),
    ("ap", [("cap", "🧢"), ("map", "🗺️"), ("nap", "😴")]),
    ("ig", [("pig", "🐷"), ("dig", "⛏️"), ("wig", "💇")]),
    ("in", [("pin", "📌"), ("bin", "🗑️"), ("win", "🏆")]),
    ("ip", [("lip", "👄"), ("zip", "🤐"), ("dip", "🥣")]),
    ("og", [("dog", "🐶"), ("log", "🪵"), ("jog", "🏃")]),
    ("ot", [("pot", "🍲"), ("dot", "⚫"), ("hot", "🔥")]),
    ("op", [("mop", "🧹"), ("top", "🔝"), ("hop", "🐰")]),
    ("ug", [("bug", "🐛"), ("mug", "☕"), ("rug", "🧶")]),
    ("un", [("sun", "🌞"), ("run", "🏃"), ("bun", "🍞")]),
    ("et", [("net", "🥅"), ("jet", "✈️"), ("pet", "🐕")]),
]

WORDS = [("cat", "🐱"), ("dog", "🐶"), ("sun", "🌞"), ("pig", "🐷"),
         ("bed", "🛏️"), ("cup", "☕"), ("hat", "🎩"), ("bug", "🐛"),
         ("net", "🥅"), ("van", "🚐"), ("fox", "🦊"), ("box", "📦")]

# (title, sentence, emoji, key word, question, options, answer)
SENTENCES = [
    ("Cat on the Mat", "The cat sat on the mat.", "🐱", "cat",
     "Who sat on the mat?", ["cat", "dog", "bug"], "cat"),
    ("The Big Dog", "A big dog can run.", "🐶", "dog",
     "What can run?", ["dog", "pot", "hat"], "dog"),
    ("Hot Sun", "The sun is hot.", "🌞", "sun",
     "What is hot?", ["sun", "cup", "bed"], "sun"),
    ("Sam's Red Cap", "Sam has a red cap.", "🧢", "cap",
     "What does Sam have?", ["cap", "cat", "pen"], "cap"),
    ("Pig in the Mud", "The pig is in the mud.", "🐷", "pig",
     "Who is in the mud?", ["pig", "hen", "fox"], "pig"),
    ("Bug on a Log", "A bug is on the log.", "🐛", "bug",
     "What is on the log?", ["bug", "bus", "cup"], "bug"),
    ("Fox and Box", "The fox has a big box.", "🦊", "fox",
     "Who has the box?", ["fox", "dog", "hen"], "fox"),
    ("Hen in the Pen", "The hen is in the pen.", "🐔", "hen",
     "Who is in the pen?", ["hen", "cat", "pig"], "hen"),
]

STORIES = [
    ("The Cat", "🐱",
     ["The cat sat.", "The cat sat on a mat.", "The cat can nap.",
      "The cat is happy."],
     "What sat on the mat?", ["The cat", "The dog", "The sun"], "The cat",
     [("cat", "🐱"), ("mat", "🟫")], "cat"),
    ("Sam and the Cap", "🧢",
     ["Sam had a cap.", "The cap fell.", "Sam got the cap.",
      "Sam is happy."],
     "What did Sam have?", ["A cap", "A dog", "A pen"], "A cap",
     [("cap", "🧢"), ("sad", "😢")], "cap"),
    ("A Rat Can Hop", "🐀",
     ["A rat can hop.", "The rat can run.", "The rat can stop.",
      "The rat is on a log."],
     "Where is the rat?", ["On a log", "In a bag", "On a mat"], "On a log",
     [("rat", "🐀"), ("log", "🪵")], "rat"),
    ("The Wet Van", "🚐",
     ["The van is wet.", "The rain is on the van.", "Ben can see the van.",
      "The sun comes out."],
     "What is wet?", ["The van", "The hat", "The cat"], "The van",
     [("van", "🚐"), ("wet", "💧")], "van"),
]

ALPHABET = "abcdefghijklmnopqrstuvwxyz"
DISTRACTOR_WORDS = [w for w, _ in WORDS] + ["mat", "pot", "bun", "jet", "wig",
                                            "top", "rug", "lip", "bin", "fan"]

levels = []
index = 0


def new_level(world_i, key, title, subtitle, emoji, treasure_word, steps):
    global index
    index += 1
    world, world_emoji, noun, t_emoji = WORLDS[world_i]
    levels.append({
        "id": f"l{index:02d}_{key}",
        "index": index,
        "world": world,
        "worldIndex": world_i + 1,
        "title": title,
        "subtitle": subtitle,
        "emoji": emoji,
        "color": PALETTE[(index - 1) % len(PALETTE)],
        "reward": {
            "id": f"t{index:02d}_{key}",
            "name": f"{treasure_word.capitalize()} {noun}",
            "emoji": t_emoji,
        },
        "steps": steps,
    })


def letter_mission(letter):
    others = [c for c in ALPHABET if c != letter]
    options = [letter] * 3 + random.sample(others, 3)
    random.shuffle(options)
    return {
        "type": "mission",
        "prompt": f"Find every {letter}!",
        "target": letter,
        "options": options,
    }


def word_mission(word, prompt=None):
    pool = [w for w in DISTRACTOR_WORDS if w != word]
    options = [word, word] + random.sample(pool, 2)
    random.shuffle(options)
    return {
        "type": "mission",
        "prompt": prompt or f"Find the word {word}!",
        "target": word,
        "options": options,
    }


def spell(word, emoji):
    pool = [c for c in ALPHABET if c not in word]
    return {
        "type": "spell",
        "word": word,
        "emoji": emoji,
        "distractors": random.sample(pool, 1),
    }


# ---- World 1 and 2: letters -------------------------------------------------
for world_i, letters in ((0, WORLD1), (1, WORLD2)):
    for i, letter in enumerate(letters):
        sound, words = LETTERS[letter]
        first_word, first_emoji = words[0]
        new_level(
            world_i,
            letter,
            f"{first_word.capitalize()} {PLACES[i % len(PLACES)]}",
            f"Meet {letter}",
            first_emoji,
            first_word,
            [
                {
                    "type": "letterIntro",
                    "letter": letter,
                    "sound": sound,
                    "exampleWord": first_word,
                    "exampleEmoji": first_emoji,
                    "say": f"This is {letter}. It says {sound}. "
                           f"{sound.capitalize()}, like {first_word}.",
                },
                {
                    "type": "trace",
                    "letter": letter,
                    "say": f"Trace the {letter} with your finger.",
                },
                letter_mission(letter),
                {
                    "type": "wordCard",
                    "prompt": f"These start with {letter}. Tap to hear them.",
                    "words": [{"text": w, "emoji": e} for w, e in words],
                },
            ],
        )

# ---- World 3: blending families --------------------------------------------
for family, words in FAMILIES:
    (w1, e1), (w2, e2) = words[0], words[1]
    new_level(
        2,
        family,
        f"The -{family} Family",
        ", ".join(w for w, _ in words),
        e1,
        w1,
        [
            {
                "type": "wordCard",
                "prompt": f"All of these end with -{family}.",
                "words": [{"text": w, "emoji": e} for w, e in words],
            },
            spell(w1, e1),
            spell(w2, e2),
            word_mission(w1),
        ],
    )

# ---- World 4: word building -------------------------------------------------
for word, emoji in WORDS:
    new_level(
        3,
        word,
        f"Build {word}",
        f"Read and spell {word}",
        emoji,
        word,
        [
            {
                "type": "wordCard",
                "prompt": "Tap to hear the word.",
                "words": [{"text": word, "emoji": emoji}],
            },
            spell(word, emoji),
            {
                "type": "trace",
                "letter": word[0],
                "say": f"Trace the first letter of {word}: {word[0]}.",
            },
            word_mission(word),
        ],
    )

# ---- World 5: sentences -----------------------------------------------------
for title, sentence, emoji, key, question, options, answer in SENTENCES:
    new_level(
        4,
        key,
        title,
        sentence,
        emoji,
        key,
        [
            {
                "type": "story",
                "emoji": emoji,
                "sentences": [sentence],
                "question": question,
                "options": options,
                "answer": answer,
            },
            spell(key, emoji),
            word_mission(key, f"Find {key} again!"),
        ],
    )

# ---- World 6: stories -------------------------------------------------------
for title, emoji, sentences, question, options, answer, words, key in STORIES:
    new_level(
        5,
        key,
        title,
        "A little story to read",
        emoji,
        key,
        [
            {
                "type": "story",
                "emoji": emoji,
                "sentences": sentences,
                "question": question,
                "options": options,
                "answer": answer,
            },
            {
                "type": "wordCard",
                "prompt": "Words from the story.",
                "words": [{"text": w, "emoji": e} for w, e in words],
            },
            word_mission(key),
        ],
    )

with open("assets/content/levels.json", "w", encoding="utf-8") as f:
    json.dump(levels, f, ensure_ascii=False, indent=1)

print(f"wrote {len(levels)} islands")
for w, *_ in WORLDS:
    print(f"  {w}: {sum(1 for l in levels if l['world'] == w)}")
