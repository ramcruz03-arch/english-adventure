#!/usr/bin/env python3
"""Authors assets/content/levels.json for Pip and the Star Islands 6.0.

Curriculum skeleton follows the six-world scope and sequence from English
Adventure 5.1, but all activities are rebuilt as the no-fail step types the
6.0 engine supports, words are lowercase, and every emoji is checked to
actually match its word.
"""
import json
import random

random.seed(6)

ALPHABET = "abcdefghijklmnopqrstuvwxyz"

PHONEME = {
    "a": "ah", "b": "buh", "c": "kuh", "d": "duh", "e": "eh", "f": "fff",
    "g": "guh", "h": "huh", "i": "ih", "j": "juh", "k": "kuh", "l": "lll",
    "m": "mmm", "n": "nnn", "o": "oh", "p": "puh", "q": "kwuh", "r": "rrr",
    "s": "sss", "t": "tuh", "u": "uh", "v": "vvv", "w": "wuh", "x": "ks",
    "y": "yuh", "z": "zzz",
}

# letter -> (example word, emoji, three picture words)
LETTERS = {
    "s": ("sun", "🌞", [("sun", "🌞"), ("sock", "🧦"), ("star", "⭐")]),
    "a": ("apple", "🍎", [("apple", "🍎"), ("ant", "🐜"), ("arm", "💪")]),
    "t": ("tree", "🌳", [("tree", "🌳"), ("top", "🔝"), ("ten", "🔟")]),
    "p": ("pig", "🐷", [("pig", "🐷"), ("pan", "🍳"), ("pen", "🖊️")]),
    "i": ("igloo", "🧊", [("igloo", "🧊"), ("ink", "🖋️"), ("insect", "🐞")]),
    "n": ("nest", "🪺", [("nest", "🪺"), ("net", "🥅"), ("nose", "👃")]),
    "m": ("moon", "🌙", [("moon", "🌙"), ("map", "🗺️"), ("milk", "🥛")]),
    "d": ("dog", "🐶", [("dog", "🐶"), ("duck", "🦆"), ("drum", "🥁")]),
    "g": ("goat", "🐐", [("goat", "🐐"), ("gift", "🎁"), ("grapes", "🍇")]),
    "o": ("octopus", "🐙", [("octopus", "🐙"), ("orange", "🍊"), ("otter", "🦦")]),
    "c": ("cat", "🐱", [("cat", "🐱"), ("cake", "🍰"), ("car", "🚗")]),
    "k": ("key", "🔑", [("key", "🔑"), ("kite", "🪁"), ("kiwi", "🥝")]),
    "e": ("egg", "🥚", [("egg", "🥚"), ("elephant", "🐘"), ("engine", "🚂")]),
    "u": ("umbrella", "☂️", [("umbrella", "☂️"), ("unicorn", "🦄"), ("up", "⬆️")]),
    "r": ("rain", "🌧️", [("rain", "🌧️"), ("rabbit", "🐰"), ("ring", "💍")]),
    "h": ("hat", "🎩", [("hat", "🎩"), ("house", "🏠"), ("horse", "🐴")]),
    "b": ("ball", "⚽", [("ball", "⚽"), ("bus", "🚌"), ("book", "📖")]),
    "f": ("fish", "🐟", [("fish", "🐟"), ("fire", "🔥"), ("flower", "🌸")]),
    "l": ("leaf", "🍃", [("leaf", "🍃"), ("lion", "🦁"), ("lamp", "💡")]),
    "j": ("juice", "🧃", [("juice", "🧃"), ("jar", "🫙"), ("jet", "✈️")]),
    "v": ("van", "🚐", [("van", "🚐"), ("violin", "🎻"), ("volcano", "🌋")]),
    "w": ("web", "🕸️", [("web", "🕸️"), ("watch", "⌚"), ("wave", "🌊")]),
    "x": ("box", "📦", [("box", "📦"), ("fox", "🦊"), ("six", "6️⃣")]),
    "y": ("yo-yo", "🪀", [("yo-yo", "🪀"), ("yarn", "🧶"), ("yellow", "🟡")]),
    "z": ("zebra", "🦓", [("zebra", "🦓"), ("zip", "🤐"), ("zoo", "🎡")]),
    "q": ("queen", "👑", [("queen", "👑"), ("quilt", "🧵"), ("question", "❓")]),
}

WORLD_1 = list("satpinmdgo")            # 10 islands
WORLD_2 = list("ckehrbflujvwxyzq")      # 16 islands  -> all 26 letters covered

# world 3: blending CVC words
WORLD_3 = [
    ("cat", "🐱"), ("dog", "🐶"), ("sun", "🌞"), ("pig", "🐷"), ("bed", "🛏️"),
    ("cup", "☕"), ("hat", "🎩"), ("net", "🥅"), ("bus", "🚌"), ("log", "🪵"),
]

# world 4: word families
WORLD_4 = [
    ("-at", [("cat", "🐱"), ("hat", "🎩"), ("bat", "🦇")]),
    ("-an", [("can", "🥫"), ("fan", "🪭"), ("pan", "🍳")]),
    ("-ig", [("pig", "🐷"), ("wig", "💇"), ("fig", "🫐")]),
    ("-op", [("top", "🔝"), ("mop", "🧹"), ("pop", "🎈")]),
    ("-ug", [("bug", "🐛"), ("mug", "☕"), ("rug", "🧶")]),
    ("-en", [("hen", "🐔"), ("pen", "🖊️"), ("ten", "🔟")]),
    ("-it", [("sit", "🪑"), ("kit", "🧰"), ("pit", "🕳️")]),
    ("-og", [("dog", "🐶"), ("log", "🪵"), ("fog", "🌫️")]),
    ("-un", [("sun", "🌞"), ("run", "🏃"), ("bun", "🥐")]),
    ("-ed", [("bed", "🛏️"), ("red", "🟥"), ("web", "🕸️")]),
]

# world 5: sentences
WORLD_5 = [
    ("The cat sat.", "🐱", "Who sat?", ["cat", "dog", "bus"], "cat"),
    ("A big dog ran.", "🐶", "Who ran?", ["dog", "hen", "pig"], "dog"),
    ("The sun is hot.", "🌞", "What is hot?", ["sun", "bed", "cup"], "sun"),
    ("Sam has a red hat.", "🎩", "What does Sam have?", ["hat", "mug", "net"], "hat"),
    ("The pig is in the mud.", "🐷", "Who is in the mud?", ["pig", "cat", "hen"], "pig"),
    ("I can see a big bus.", "🚌", "What can I see?", ["bus", "log", "fan"], "bus"),
    ("The hen sat on an egg.", "🥚", "What did the hen sit on?", ["egg", "rug", "pen"], "egg"),
    ("We ran up to the top.", "🔝", "Where did we run?", ["top", "bed", "van"], "top"),
]

# world 6: decodable mini-stories
WORLD_6 = [
    ("The Cat and the Mat", "🐱",
     ["The cat sat.", "The cat sat on a mat.", "The cat can nap.", "The cat is happy."],
     "Where did the cat sit?", ["mat", "bus", "log"], "mat",
     [("cat", "🐱"), ("nap", "😴"), ("mat", "🟫")]),
    ("Sam and the Cap", "🧢",
     ["Sam has a cap.", "The cap is red.", "The cap fell in the mud.", "Sam got the cap."],
     "What colour is the cap?", ["red", "big", "wet"], "red",
     [("cap", "🧢"), ("red", "🟥"), ("mud", "🟤")]),
    ("The Dog Ran", "🐶",
     ["A dog can run.", "The dog ran to the log.", "The dog dug in the sand.", "The dog is glad."],
     "Where did the dog run?", ["log", "bed", "bus"], "log",
     [("dog", "🐶"), ("run", "🏃"), ("log", "🪵")]),
    ("The Big Bug", "🐛",
     ["A bug sat on a rug.", "The bug is big.", "The bug can hop.", "The bug hid in a mug."],
     "Where did the bug hide?", ["mug", "van", "net"], "mug",
     [("bug", "🐛"), ("rug", "🧶"), ("mug", "☕")]),
    ("The Hen and the Egg", "🐔",
     ["The hen sat on an egg.", "The egg is in the nest.", "Tap, tap! The egg is open.", "A little chick!"],
     "What was in the egg?", ["chick", "fish", "frog"], "chick",
     [("hen", "🐔"), ("egg", "🥚"), ("nest", "🪺")]),
    ("Up to the Sun", "🌞",
     ["The sun is up.", "We run up the hill.", "It is hot at the top.", "We sit and nap."],
     "What did we do at the top?", ["nap", "hop", "dig"], "nap",
     [("sun", "🌞"), ("hill", "⛰️"), ("nap", "😴")]),
]

WORLDS = [
    ("Letter Village", "#FFB703", "🏝️"),
    ("Sound Forest", "#2FD08D", "🌴"),
    ("Blending Bridge", "#3A86FF", "🌉"),
    ("Word Forest", "#8A5CF6", "🌲"),
    ("Sentence Town", "#FF6B5B", "🏘️"),
    ("Story Castle", "#F72585", "🏰"),
]

TREASURES = [
    ("Sun Shell", "🐚"), ("Sea Star", "⭐"), ("Pearl", "🫧"), ("Coral Bead", "🪸"),
    ("Gold Coin", "🪙"), ("Blue Gem", "💎"), ("Paper Boat", "🛶"), ("Sand Dollar", "🪩"),
    ("Compass", "🧭"), ("Message Bottle", "🍾"), ("Feather", "🪶"), ("Moon Stone", "🌕"),
    ("Green Leaf", "🍀"), ("Pine Cone", "🌰"), ("Firefly Jar", "🫙"), ("Bird Egg", "🥚"),
    ("Mushroom Cap", "🍄"), ("Honey Pot", "🍯"), ("Acorn", "🌰"), ("Rainbow Shard", "🌈"),
    ("Bridge Bead", "🔷"), ("Silver Key", "🗝️"), ("Rope Coil", "🪢"), ("Lantern", "🏮"),
    ("Sky Kite", "🪁"), ("Cloud Puff", "☁️"), ("River Stone", "🪨"), ("Wooden Boat", "⛵"),
    ("Star Chart", "🗺️"), ("Brass Bell", "🔔"), ("Tree Seed", "🌱"), ("Wild Berry", "🫐"),
    ("Owl Feather", "🪽"), ("Fern Frond", "🌿"), ("Amber Drop", "🟠"), ("Fox Charm", "🦊"),
    ("Vine Ring", "💍"), ("Bark Scroll", "📜"), ("Dew Drop", "💧"), ("Sun Flower", "🌻"),
    ("Town Ticket", "🎫"), ("Baker's Bun", "🥐"), ("Post Stamp", "📮"), ("Street Lamp", "💡"),
    ("Clock Hand", "🕰️"), ("Blue Door Key", "🔑"), ("Market Apple", "🍎"), ("Song Bird", "🐦"),
    ("Castle Crown", "👑"), ("Story Book", "📖"), ("Wax Seal", "🔴"), ("Quill Pen", "🪶"),
    ("Dragon Scale", "🐉"), ("Lantern Key", "🗝️"), ("Star Map", "🌌"), ("Gold Trumpet", "🎺"),
    ("Ruby Heart", "❤️"), ("Silver Shield", "🛡️"), ("Magic Wand", "🪄"), ("Rainbow Sail", "⛵"),
]

levels = []
treasure_index = 0


def next_treasure():
    global treasure_index
    name, emoji = TREASURES[treasure_index % len(TREASURES)]
    slug = name.lower().replace(" ", "_").replace("'", "")
    treasure_index += 1
    return {"id": f"t{treasure_index:02d}_{slug}", "name": name, "emoji": emoji}


def letter_mission(letter, count=3, total=6):
    others = [c for c in ALPHABET if c != letter]
    options = [letter] * count + random.sample(others, total - count)
    random.shuffle(options)
    return options


def word_mission(word, pool, count=2, total=4):
    others = [w for w in pool if w != word]
    options = [word] * count + random.sample(others, min(total - count, len(others)))
    random.shuffle(options)
    return options


def spell_distractor(word):
    return random.choice([c for c in "satpinmdcbhgruef" if c not in word])


def letter_island(letter, index, world, colour):
    example_word, example_emoji, picture_words = LETTERS[letter]
    sound = PHONEME[letter]
    return {
        "id": f"isle_{letter}",
        "index": index,
        "world": world,
        "title": f"{example_word.capitalize()} Island",
        "subtitle": f"Meet {letter}",
        "emoji": example_emoji,
        "color": colour,
        "reward": next_treasure(),
        "steps": [
            {
                "type": "letterIntro",
                "letter": letter,
                "sound": sound,
                "exampleWord": example_word,
                "exampleEmoji": example_emoji,
                "say": f"This is {letter}. It says {sound}. {sound}, like {example_word}.",
            },
            {
                "type": "trace",
                "letter": letter,
                "say": f"Trace the {letter}. Start at the green dot.",
            },
            {
                "type": "wordCard",
                "prompt": f"These all start with {letter}. Tap to hear.",
                "words": [{"text": w, "emoji": e} for w, e in picture_words],
            },
            {
                "type": "mission",
                "prompt": f"Find every {letter}!",
                "target": letter,
                "options": letter_mission(letter),
            },
        ],
    }


def blend_island(word, emoji, index, world, colour, pool):
    return {
        "id": f"isle_blend_{word}",
        "index": index,
        "world": world,
        "title": word.capitalize(),
        "subtitle": f"Blend {' - '.join(word)}",
        "emoji": emoji,
        "color": colour,
        "reward": next_treasure(),
        "steps": [
            {
                "type": "blend",
                "word": word,
                "emoji": emoji,
                "sounds": [{"letter": c, "say": PHONEME[c]} for c in word],
                "say": "Tap each sound, then push them together.",
            },
            {
                "type": "spell",
                "word": word,
                "emoji": emoji,
                "distractors": [spell_distractor(word)],
            },
            {
                "type": "wordCard",
                "prompt": "You can read it now!",
                "words": [{"text": word, "emoji": emoji}],
            },
            {
                "type": "mission",
                "prompt": f"Find the word {word}!",
                "target": word,
                "options": word_mission(word, pool),
            },
        ],
    }


def family_island(family, words, index, world, colour):
    pool = [w for w, _ in words] + ["sun", "dog", "cup", "hat"]
    first, second = words[0], words[1]
    return {
        "id": f"isle_family_{family.strip('-')}",
        "index": index,
        "world": world,
        "title": f"{family} Grove",
        "subtitle": f"Words that end in {family}",
        "emoji": words[0][1],
        "color": colour,
        "reward": next_treasure(),
        "steps": [
            {
                "type": "wordCard",
                "prompt": f"All of these end in {family}. Tap to hear.",
                "words": [{"text": w, "emoji": e} for w, e in words],
            },
            {
                "type": "spell",
                "word": first[0],
                "emoji": first[1],
                "distractors": [spell_distractor(first[0])],
            },
            {
                "type": "spell",
                "word": second[0],
                "emoji": second[1],
                "distractors": [spell_distractor(second[0])],
            },
            {
                "type": "mission",
                "prompt": f"Find the word {first[0]}!",
                "target": first[0],
                "options": word_mission(first[0], pool),
            },
        ],
    }


def sentence_island(sentence, emoji, question, options, answer, index, world, colour):
    key_word = answer
    return {
        "id": f"isle_sentence_{index}",
        "index": index,
        "world": world,
        "title": sentence.rstrip("."),
        "subtitle": "Read a sentence",
        "emoji": emoji,
        "color": colour,
        "reward": next_treasure(),
        "steps": [
            {
                "type": "story",
                "title": sentence.rstrip("."),
                "emoji": emoji,
                "sentences": [sentence],
                "question": question,
                "options": options,
                "answer": answer,
            },
            {
                "type": "spell",
                "word": key_word,
                "emoji": emoji,
                "distractors": [spell_distractor(key_word)],
            },
            {
                "type": "mission",
                "prompt": f"Find the word {key_word}!",
                "target": key_word,
                "options": word_mission(key_word, options + ["top", "bun", "fan"]),
            },
        ],
    }


def story_island(title, emoji, sentences, question, options, answer, words,
                 index, world, colour):
    return {
        "id": f"isle_story_{index}",
        "index": index,
        "world": world,
        "title": title,
        "subtitle": "A story to read",
        "emoji": emoji,
        "color": colour,
        "reward": next_treasure(),
        "steps": [
            {
                "type": "wordCard",
                "prompt": "Words from the story. Tap to hear.",
                "words": [{"text": w, "emoji": e} for w, e in words],
            },
            {
                "type": "story",
                "title": title,
                "emoji": emoji,
                "sentences": sentences,
                "question": question,
                "options": options,
                "answer": answer,
            },
            {
                "type": "mission",
                "prompt": f"Find the word {answer}!",
                "target": answer,
                "options": word_mission(answer, options + [w for w, _ in words]),
            },
        ],
    }


index = 1

for letter in WORLD_1:
    levels.append(letter_island(letter, index, WORLDS[0][0], WORLDS[0][1]))
    index += 1

for letter in WORLD_2:
    levels.append(letter_island(letter, index, WORLDS[1][0], WORLDS[1][1]))
    index += 1

blend_pool = [w for w, _ in WORLD_3]
for word, emoji in WORLD_3:
    levels.append(blend_island(word, emoji, index, WORLDS[2][0], WORLDS[2][1], blend_pool))
    index += 1

for family, words in WORLD_4:
    levels.append(family_island(family, words, index, WORLDS[3][0], WORLDS[3][1]))
    index += 1

for sentence, emoji, question, options, answer in WORLD_5:
    levels.append(sentence_island(sentence, emoji, question, options, answer,
                                  index, WORLDS[4][0], WORLDS[4][1]))
    index += 1

for title, emoji, sentences, question, options, answer, words in WORLD_6:
    levels.append(story_island(title, emoji, sentences, question, options, answer,
                               words, index, WORLDS[5][0], WORLDS[5][1]))
    index += 1

with open("assets/content/levels.json", "w", encoding="utf-8") as handle:
    json.dump(levels, handle, ensure_ascii=False, indent=2)

print(f"wrote {len(levels)} islands")
for name, _, _ in WORLDS:
    print(f"  {name}: {sum(1 for l in levels if l['world'] == name)}")
