import 'package:flutter/material.dart';

/// A collectible treasure awarded when an island is finished.
class Collectible {
  const Collectible({required this.id, required this.name, required this.emoji});

  final String id;
  final String name;
  final String emoji;

  factory Collectible.fromJson(Map<String, dynamic> json) => Collectible(
    id: json['id'] as String,
    name: json['name'] as String,
    emoji: json['emoji'] as String,
  );
}

/// A word shown on a tap-to-hear card.
class WordItem {
  const WordItem({required this.text, required this.emoji});

  final String text;
  final String emoji;

  factory WordItem.fromJson(Map<String, dynamic> json) =>
      WordItem(text: json['text'] as String, emoji: json['emoji'] as String);
}

/// One short activity inside an island. Every island is a list of these.
///
/// Adding a new activity later = add a subclass here, add a case in
/// [LessonStep.fromJson], and add a case in `LessonScreen._viewFor`.
sealed class LessonStep {
  const LessonStep();

  factory LessonStep.fromJson(Map<String, dynamic> json) {
    switch (json['type'] as String) {
      case 'letterIntro':
        return LetterIntroStep(
          letter: json['letter'] as String,
          sound: json['sound'] as String,
          exampleWord: json['exampleWord'] as String,
          exampleEmoji: json['exampleEmoji'] as String,
          say: json['say'] as String,
        );
      case 'wordCard':
        return WordCardStep(
          prompt: json['prompt'] as String? ?? 'Tap a card to hear it.',
          words: (json['words'] as List<dynamic>)
              .map((e) => WordItem.fromJson(e as Map<String, dynamic>))
              .toList(),
        );
      case 'spell':
        return SpellStep(
          word: json['word'] as String,
          emoji: json['emoji'] as String,
          distractors: (json['distractors'] as List<dynamic>? ?? const [])
              .map((e) => e as String)
              .toList(),
        );
      case 'trace':
        return TraceStep(
          letter: json['letter'] as String,
          say: json['say'] as String? ?? 'Trace the letter.',
        );
      case 'blend':
        return BlendStep(
          word: json['word'] as String,
          emoji: json['emoji'] as String,
          say: json['say'] as String? ??
              'Tap each sound, then push them together.',
          sounds: (json['sounds'] as List<dynamic>)
              .map((e) => SoundBit.fromJson(e as Map<String, dynamic>))
              .toList(),
        );
      case 'story':
        return StoryStep(
          title: json['title'] as String,
          emoji: json['emoji'] as String? ?? '📖',
          sentences: (json['sentences'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
          question: json['question'] as String,
          options: (json['options'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
          answer: json['answer'] as String,
        );
      case 'story':
        return StoryStep(
          emoji: json['emoji'] as String,
          sentences: (json['sentences'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
          question: json['question'] as String,
          options: (json['options'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
          answer: json['answer'] as String,
        );
      case 'mission':
        return MissionStep(
          prompt: json['prompt'] as String,
          target: json['target'] as String,
          options: (json['options'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
        );
      default:
        throw FormatException('Unknown step type: ${json['type']}');
    }
  }

  /// Letters this step gives practice on (used for the parent report).
  List<String> get practisedLetters;
}

class LetterIntroStep extends LessonStep {
  const LetterIntroStep({
    required this.letter,
    required this.sound,
    required this.exampleWord,
    required this.exampleEmoji,
    required this.say,
  });

  final String letter;
  final String sound;
  final String exampleWord;
  final String exampleEmoji;
  final String say;

  @override
  List<String> get practisedLetters => [letter];
}

class WordCardStep extends LessonStep {
  const WordCardStep({required this.prompt, required this.words});

  final String prompt;
  final List<WordItem> words;

  @override
  List<String> get practisedLetters =>
      words.expand((w) => w.text.split('')).toSet().toList();
}

class SpellStep extends LessonStep {
  const SpellStep({
    required this.word,
    required this.emoji,
    this.distractors = const [],
  });

  final String word;
  final String emoji;
  final List<String> distractors;

  List<String> get letters => word.split('');

  @override
  List<String> get practisedLetters => letters;
}

class TraceStep extends LessonStep {
  const TraceStep({required this.letter, required this.say});

  final String letter;
  final String say;

  @override
  List<String> get practisedLetters => [letter];
}

class StoryStep extends LessonStep {
  const StoryStep({
    required this.emoji,
    required this.sentences,
    required this.question,
    required this.options,
    required this.answer,
  });

  final String emoji;
  final List<String> sentences;
  final String question;
  final List<String> options;
  final String answer;

  @override
  List<String> get practisedLetters => const [];
}

class MissionStep extends LessonStep {
  const MissionStep({
    required this.prompt,
    required this.target,
    required this.options,
  });

  final String prompt;
  final String target;
  final List<String> options;

  int get targetCount => options.where((o) => o == target).length;

  @override
  List<String> get practisedLetters => target.split('');
}

/// One sound inside a blending activity.
class SoundBit {
  const SoundBit({required this.letter, required this.say});

  final String letter;

  /// How text-to-speech should pronounce the phoneme ("sss", not "ess").
  final String say;

  factory SoundBit.fromJson(Map<String, dynamic> json) => SoundBit(
    letter: json['letter'] as String,
    say: json['say'] as String,
  );
}

/// Tap each sound, then push them together into a word.
class BlendStep extends LessonStep {
  const BlendStep({
    required this.word,
    required this.emoji,
    required this.sounds,
    required this.say,
  });

  final String word;
  final String emoji;
  final List<SoundBit> sounds;
  final String say;

  @override
  List<String> get practisedLetters => sounds.map((s) => s.letter).toList();
}

/// A few decodable sentences, read one at a time, then one gentle question.
class StoryStep extends LessonStep {
  const StoryStep({
    required this.title,
    required this.emoji,
    required this.sentences,
    required this.question,
    required this.options,
    required this.answer,
  });

  final String title;
  final String emoji;
  final List<String> sentences;
  final String question;
  final List<String> options;
  final String answer;

  @override
  List<String> get practisedLetters => answer.split('');
}

/// One island on the map.
class Level {
  const Level({
    required this.id,
    required this.index,
    required this.world,
    required this.title,
    required this.subtitle,
    required this.emoji,
    required this.color,
    required this.reward,
    required this.steps,
  });

  final String id;
  final int index;
  final String world;
  final String title;
  final String subtitle;
  final String emoji;
  final Color color;
  final Collectible reward;
  final List<LessonStep> steps;

  /// One star per activity, so a child always sees a full row at the end.
  int get maxStars => steps.length;

  factory Level.fromJson(Map<String, dynamic> json) => Level(
    id: json['id'] as String,
    index: json['index'] as int,
    world: json['world'] as String? ?? 'Star Islands',
    title: json['title'] as String,
    subtitle: json['subtitle'] as String,
    emoji: json['emoji'] as String,
    color: _parseColor(json['color'] as String),
    reward: Collectible.fromJson(json['reward'] as Map<String, dynamic>),
    steps: (json['steps'] as List<dynamic>)
        .map((e) => LessonStep.fromJson(e as Map<String, dynamic>))
        .toList(),
  );

  static Color _parseColor(String hex) {
    final value = hex.replaceAll('#', '');
    return Color(int.parse('FF$value', radix: 16));
  }
}
