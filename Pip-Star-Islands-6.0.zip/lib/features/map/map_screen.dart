import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/copy.dart';
import '../../core/providers.dart';
import '../../core/storage/progress_store.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/level.dart';
import '../../widgets/big_button.dart';
import '../../widgets/mascot.dart';
import '../../widgets/progress_bits.dart';
import '../lesson/lesson_screen.dart';
import '../parent/parent_gate.dart';
import '../setup/setup_screen.dart';

/// Home. Sixty islands across six worlds, unlocked in order.
class MapScreen extends ConsumerWidget {
  const MapScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final progress = ref.watch(progressProvider);
    if (progress.needsSetup) return const SetupScreen();

    final levels = ref.watch(levelsProvider);

    return Scaffold(
      body: SeaSkyBackground(
        child: SafeArea(
          child: levels.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('Could not load the islands.\n$error'),
              ),
            ),
            data: (list) => _MapBody(levels: list, progress: progress),
          ),
        ),
      ),
    );
  }
}

/// An island is open if a grown-up chose to start at its world, if it is the
/// very first one, or if the island before it is finished.
bool _isUnlocked(List<Level> levels, int i, ProgressState progress) =>
    i == 0 ||
    levels[i].worldIndex <= progress.startWorld ||
    progress.isFinished(levels[i - 1].id);

class _MapBody extends ConsumerWidget {
  const _MapBody({required this.levels, required this.progress});

  final List<Level> levels;
  final ProgressState progress;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Flatten worlds into one scrolling list of headers + island cards.
    final rows = <Widget>[];
    var lastWorld = '';

    for (var i = 0; i < levels.length; i++) {
      final level = levels[i];
      if (level.world != lastWorld) {
        lastWorld = level.world;
        final worldLevels =
            levels.where((l) => l.world == level.world).toList();
        final done =
            worldLevels.where((l) => progress.isFinished(l.id)).length;
        rows.add(
          _WorldHeader(
            title: level.world,
            done: done,
            total: worldLevels.length,
          ),
        );
      }

      final unlocked = _isUnlocked(levels, i, progress);
      rows.add(
        Padding(
          padding: EdgeInsets.only(
            bottom: 14,
            left: i.isEven ? 0 : 28,
            right: i.isEven ? 28 : 0,
          ),
          child: _IslandCard(
            level: level,
            unlocked: unlocked,
            stars: progress.starsFor(level.id),
            onTap: () => _open(context, ref, level, unlocked),
          ),
        ),
      );
    }

    final nextIndex = _nextIslandIndex();

    return Column(
      children: [
        _Header(progress: progress),
        if (nextIndex != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
            child: BigButton(
              label: '${Copy.keepGoing}  ${levels[nextIndex].emoji}',
              icon: Icons.sailing_rounded,
              color: AppColors.coral,
              expand: true,
              onPressed: () =>
                  _open(context, ref, levels[nextIndex], true),
            ),
          ),
        if (progress.collectibles.isNotEmpty)
          _TreasureBag(levels: levels, progress: progress),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 32),
            children: rows,
          ),
        ),
      ],
    );
  }

  /// First island that is open and not finished yet.
  int? _nextIslandIndex() {
    for (var i = 0; i < levels.length; i++) {
      if (progress.isFinished(levels[i].id)) continue;
      if (_isUnlocked(levels, i, progress)) return i;
    }
    return null;
  }

  void _open(
    BuildContext context,
    WidgetRef ref,
    Level level,
    bool unlocked,
  ) {
    final speech = ref.read(speechProvider);
    if (!unlocked) {
      speech.say(Copy.lockedMessage);
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            backgroundColor: AppColors.grape,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            content: const Text(
              Copy.lockedMessage,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
          ),
        );
      return;
    }
    speech.softHaptic();
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => LessonScreen(level: level)),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.progress});

  final ProgressState progress;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 12, 8),
      child: Row(
        children: [
          const PipMascot(size: 54),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              Copy.mapTitle,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                shadows: [
                  Shadow(
                    color: Color(0x552B3A55),
                    blurRadius: 8,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
            ),
          ),
          StarPill(stars: progress.totalStars),
          IconButton(
            tooltip: Copy.grownUps,
            iconSize: 28,
            icon: const Icon(Icons.lock_outline_rounded, color: Colors.white),
            onPressed: () => openParentArea(context),
          ),
        ],
      ),
    );
  }
}

class _WorldHeader extends StatelessWidget {
  const _WorldHeader({
    required this.title,
    required this.done,
    required this.total,
  });

  final String title;
  final int done;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 12),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                shadows: [
                  Shadow(
                    color: Color(0x552B3A55),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.85),
              borderRadius: BorderRadius.circular(AppRadii.button),
            ),
            child: Text(
              '$done / $total',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.ink,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TreasureBag extends StatelessWidget {
  const _TreasureBag({required this.levels, required this.progress});

  final List<Level> levels;
  final ProgressState progress;

  @override
  Widget build(BuildContext context) {
    final found = levels
        .where((l) => progress.collectibles.contains(l.reward.id))
        .toList();

    return Container(
      height: 58,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.85),
        borderRadius: BorderRadius.circular(AppRadii.button),
      ),
      child: Row(
        children: [
          const Text('🎒', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 10),
          Expanded(
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: found.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, i) => Center(
                child: Text(
                  found[i].reward.emoji,
                  style: const TextStyle(fontSize: 28),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _IslandCard extends StatelessWidget {
  const _IslandCard({
    required this.level,
    required this.unlocked,
    required this.stars,
    required this.onTap,
  });

  final Level level;
  final bool unlocked;
  final int stars;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = unlocked ? level.color : AppColors.inkSoft;
    final finished = stars > 0;

    return Material(
      color: Colors.white.withValues(alpha: unlocked ? 1 : 0.6),
      borderRadius: BorderRadius.circular(AppRadii.card),
      elevation: unlocked ? 5 : 0,
      shadowColor: color.withValues(alpha: 0.4),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadii.card),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadii.card),
            border: Border.all(
              color: color.withValues(alpha: unlocked ? 0.5 : 0.2),
              width: 3,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 66,
                height: 66,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.15),
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  unlocked ? level.emoji : '🔒',
                  style: const TextStyle(fontSize: 34),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      level.title,
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w800,
                        color: unlocked ? AppColors.ink : AppColors.inkSoft,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      level.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 6),
                    StarRow(
                      earned: stars,
                      total: level.maxStars,
                      size: 20,
                    ),
                  ],
                ),
              ),
              Icon(
                unlocked
                    ? (finished
                        ? Icons.replay_circle_filled_rounded
                        : Icons.play_circle_fill_rounded)
                    : Icons.lock_rounded,
                size: 40,
                color: color,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
