import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/copy.dart';
import '../../core/providers.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/level.dart';
import '../../widgets/big_button.dart';
import '../../widgets/celebration.dart';
import '../../widgets/mascot.dart';
import '../../widgets/progress_bits.dart';
import '../lesson/lesson_screen.dart';

/// The pay-off: a collectible for the treasure bag and a full row of stars.
class RewardScreen extends ConsumerStatefulWidget {
  const RewardScreen({super.key, required this.level});

  final Level level;

  @override
  ConsumerState<RewardScreen> createState() => _RewardScreenState();
}

class _RewardScreenState extends ConsumerState<RewardScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..forward();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      showCelebration(context);
      ref.read(speechProvider).say(
            '${Copy.islandDone(widget.level.title)} '
            '${Copy.rewardFound(widget.level.reward.name)}',
          );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final level = widget.level;
    final scale = CurvedAnimation(parent: _controller, curve: Curves.elasticOut);

    return Scaffold(
      body: SeaSkyBackground(
        tint: level.color,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 8),
                PipSays(text: Copy.islandDone(level.title)),
                Expanded(
                  child: Center(
                    child: ScaleTransition(
                      scale: scale,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 200,
                            height: 200,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color:
                                      level.color.withValues(alpha: 0.45),
                                  blurRadius: 40,
                                  spreadRadius: 4,
                                ),
                              ],
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              level.reward.emoji,
                              style: const TextStyle(fontSize: 96),
                            ),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            Copy.rewardFound(level.reward.name),
                            textAlign: TextAlign.center,
                            style:
                                Theme.of(context).textTheme.headlineMedium,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            Copy.rewardSub,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          const SizedBox(height: 20),
                          StarRow(
                            earned: level.maxStars,
                            total: level.maxStars,
                            size: 40,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                BigButton(
                  label: Copy.backToMap,
                  icon: Icons.map_rounded,
                  color: AppColors.mint,
                  expand: true,
                  onPressed: () =>
                      Navigator.of(context).popUntil((r) => r.isFirst),
                ),
                const SizedBox(height: 12),
                BigButton(
                  label: Copy.playAgain,
                  icon: Icons.replay_rounded,
                  color: AppColors.sunshine,
                  expand: true,
                  onPressed: () => Navigator.of(context).pushReplacement(
                    MaterialPageRoute<void>(
                      builder: (_) => LessonScreen(level: level),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
