import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/mascot.dart';

/// "Meet the letter" — hear the sound, see the shape, see a picture word.
class LetterIntroView extends ConsumerStatefulWidget {
  const LetterIntroView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final LetterIntroStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<LetterIntroView> createState() => _LetterIntroViewState();
}

class _LetterIntroViewState extends ConsumerState<LetterIntroView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _speakIntro());
  }

  void _speakIntro() => ref.read(speechProvider).say(widget.step.say);

  void _speakSound() {
    final speech = ref.read(speechProvider);
    speech.softHaptic();
    speech.sayLetterSound(widget.step.letter, sound: widget.step.sound);
  }

  void _speakWord() {
    final speech = ref.read(speechProvider);
    speech.softHaptic();
    speech.say(widget.step.exampleWord);
  }

  @override
  Widget build(BuildContext context) {
    final step = widget.step;

    return Column(
      children: [
        PipSays(text: step.say, onTapBubble: _speakIntro),
        const SizedBox(height: 20),
        Expanded(
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: _speakSound,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 44,
                        vertical: 18,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(AppRadii.card),
                        border: Border.all(
                          color: widget.accent.withValues(alpha: 0.4),
                          width: 4,
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            step.letter.toLowerCase(),
                            style: TextStyle(
                              fontSize: 120,
                              height: 1.1,
                              fontWeight: FontWeight.w800,
                              color: widget.accent,
                            ),
                          ),
                          Text(
                            step.letter.toUpperCase(),
                            style: const TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.w700,
                              color: AppColors.inkSoft,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    'says  "${step.sound}"',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 18),
                  GestureDetector(
                    onTap: _speakWord,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          step.exampleEmoji,
                          style: const TextStyle(fontSize: 54),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          step.exampleWord,
                          style:
                              Theme.of(context).textTheme.headlineMedium,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Row(
          children: [
            SoundButton(onPressed: _speakSound, color: widget.accent),
            const SizedBox(width: 16),
            Expanded(
              child: BigButton(
                label: Copy.next,
                icon: Icons.arrow_forward_rounded,
                color: AppColors.mint,
                expand: true,
                onPressed: widget.onDone,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
