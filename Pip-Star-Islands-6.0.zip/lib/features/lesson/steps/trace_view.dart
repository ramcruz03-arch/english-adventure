import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/letter_strokes.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/celebration.dart';
import '../../../widgets/mascot.dart';

/// Trace-the-letter writing practice.
///
/// The letter is a trail of dots. Dragging a finger near a dot lights it up.
/// There is no "wrong" here — the child can go over it as many times as they
/// like, and the finished letter is celebrated at 80% coverage.
class TraceView extends ConsumerStatefulWidget {
  const TraceView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final TraceStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<TraceView> createState() => _TraceViewState();
}

class _TraceViewState extends ConsumerState<TraceView> {
  static const double _touchRadius = 30;
  static const double _successRatio = 0.8;

  late final List<List<Offset>> _strokes = strokesFor(widget.step.letter);
  late final List<List<bool>> _covered = _strokes
      .map((stroke) => List<bool>.filled(stroke.length, false))
      .toList();

  double _boxSize = 280;
  bool _finished = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => ref.read(speechProvider).say(widget.step.say),
    );
  }

  int get _totalPoints =>
      _strokes.fold(0, (sum, stroke) => sum + stroke.length);

  int get _coveredPoints => _covered.fold(
      0, (sum, stroke) => sum + stroke.where((c) => c).length);

  double get _progress =>
      _totalPoints == 0 ? 0 : _coveredPoints / _totalPoints;

  void _handleTouch(Offset local) {
    if (_finished) return;
    var changed = false;

    for (var s = 0; s < _strokes.length; s++) {
      for (var p = 0; p < _strokes[s].length; p++) {
        if (_covered[s][p]) continue;
        final point = _strokes[s][p] * _boxSize;
        if ((point - local).distance <= _touchRadius) {
          _covered[s][p] = true;
          changed = true;
        }
      }
    }

    if (changed) {
      setState(() {});
      if (_progress >= _successRatio) _complete();
    }
  }

  Future<void> _complete() async {
    if (_finished) return;
    _finished = true;
    final speech = ref.read(speechProvider);
    speech.cheerHaptic();
    showCelebration(context);
    await speech.say('${Copy.praise()} You wrote ${widget.step.letter}.');
    await Future<void>.delayed(const Duration(milliseconds: 1000));
    if (mounted) widget.onDone();
  }

  void _clear() {
    setState(() {
      for (final stroke in _covered) {
        stroke.fillRange(0, stroke.length, false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        PipSays(text: widget.step.say),
        const SizedBox(height: 12),
        Expanded(
          child: Center(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final size = constraints.biggest.shortestSide
                    .clamp(200.0, 360.0)
                    .toDouble();
                _boxSize = size;
                return Container(
                  width: size,
                  height: size,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppRadii.card),
                    border: Border.all(
                      color: widget.accent.withValues(alpha: 0.35),
                      width: 3,
                    ),
                  ),
                  child: GestureDetector(
                    onPanStart: (d) => _handleTouch(d.localPosition),
                    onPanUpdate: (d) => _handleTouch(d.localPosition),
                    onTapDown: (d) => _handleTouch(d.localPosition),
                    child: Stack(
                      children: [
                        Center(
                          child: Text(
                            widget.step.letter.toLowerCase(),
                            style: TextStyle(
                              fontSize: size * 0.82,
                              height: 1.0,
                              fontWeight: FontWeight.w800,
                              color: widget.accent.withValues(alpha: 0.10),
                            ),
                          ),
                        ),
                        CustomPaint(
                          size: Size(size, size),
                          painter: _TracePainter(
                            strokes: _strokes,
                            covered: _covered,
                            accent: widget.accent,
                            box: size,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: LinearProgressIndicator(
            value: _progress,
            minHeight: 14,
            backgroundColor: Colors.white,
            valueColor: AlwaysStoppedAnimation<Color>(widget.accent),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            SoundButton(
              onPressed: () =>
                  ref.read(speechProvider).say(widget.step.say),
              color: AppColors.grape,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: BigButton(
                label: Copy.again,
                icon: Icons.refresh_rounded,
                color: AppColors.sunshine,
                onPressed: _clear,
                expand: true,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: BigButton(
                label: Copy.imDone,
                color: AppColors.mint,
                onPressed: widget.onDone,
                expand: true,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _TracePainter extends CustomPainter {
  const _TracePainter({
    required this.strokes,
    required this.covered,
    required this.accent,
    required this.box,
  });

  final List<List<Offset>> strokes;
  final List<List<bool>> covered;
  final Color accent;
  final double box;

  @override
  void paint(Canvas canvas, Size size) {
    final guide = Paint()..color = AppColors.inkSoft.withValues(alpha: 0.35);
    final done = Paint()..color = accent;
    final start = Paint()..color = AppColors.mint;

    for (var s = 0; s < strokes.length; s++) {
      final stroke = strokes[s];
      for (var p = 0; p < stroke.length; p++) {
        final point = stroke[p] * box;
        final isCovered = covered[s][p];
        canvas.drawCircle(point, isCovered ? 9 : 5, isCovered ? done : guide);
      }
      // Green "start here" dot at the top of each unfinished stroke.
      if (!covered[s][0]) {
        canvas.drawCircle(stroke.first * box, 13, start);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _TracePainter oldDelegate) => true;
}
