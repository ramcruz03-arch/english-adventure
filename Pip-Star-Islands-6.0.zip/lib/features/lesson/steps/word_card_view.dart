import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/mascot.dart';

/// Tap-to-learn word cards. Nothing to get wrong: tapping is the whole task.
class WordCardView extends ConsumerStatefulWidget {
  const WordCardView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final WordCardStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<WordCardView> createState() => _WordCardViewState();
}

class _WordCardViewState extends ConsumerState<WordCardView> {
  final Set<int> _heard = <int>{};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => ref.read(speechProvider).say(widget.step.prompt),
    );
  }

  void _tapCard(int index) {
    final word = widget.step.words[index];
    final speech = ref.read(speechProvider);
    speech.softHaptic();
    speech.sayWordThenLetters(word.text);
    setState(() => _heard.add(index));
  }

  @override
  Widget build(BuildContext context) {
    final words = widget.step.words;
    final allHeard = _heard.length == words.length;

    return Column(
      children: [
        PipSays(text: widget.step.prompt),
        const SizedBox(height: 20),
        Expanded(
          child: ListView.separated(
            itemCount: words.length,
            separatorBuilder: (_, __) => const SizedBox(height: 14),
            itemBuilder: (context, index) {
              final word = words[index];
              final heard = _heard.contains(index);
              return _WordCard(
                word: word,
                accent: widget.accent,
                heard: heard,
                onTap: () => _tapCard(index),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        BigButton(
          label: allHeard ? Copy.next : 'Tap the cards',
          icon: allHeard ? Icons.arrow_forward_rounded : Icons.touch_app_rounded,
          color: allHeard ? AppColors.mint : AppColors.inkSoft,
          expand: true,
          onPressed: allHeard ? widget.onDone : null,
        ),
      ],
    );
  }
}

class _WordCard extends StatelessWidget {
  const _WordCard({
    required this.word,
    required this.accent,
    required this.heard,
    required this.onTap,
  });

  final WordItem word;
  final Color accent;
  final bool heard;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(AppRadii.card),
      elevation: heard ? 1 : 5,
      shadowColor: accent.withValues(alpha: 0.4),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadii.card),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadii.card),
            border: Border.all(
              color: heard ? accent : accent.withValues(alpha: 0.25),
              width: heard ? 4 : 2,
            ),
          ),
          child: Row(
            children: [
              Text(word.emoji, style: const TextStyle(fontSize: 52)),
              const SizedBox(width: 18),
              Expanded(
                child: Text(
                  word.text,
                  style: TextStyle(
                    fontSize: 44,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 3,
                    color: accent,
                  ),
                ),
              ),
              Icon(
                heard ? Icons.check_circle_rounded : Icons.volume_up_rounded,
                size: 36,
                color: heard ? AppColors.mint : AppColors.inkSoft,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
