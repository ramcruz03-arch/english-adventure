import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/theme/app_theme.dart';

/// Calm, plain-language progress for a parent. No scores, no rankings,
/// nothing that would make a child feel measured.
class ParentScreen extends ConsumerWidget {
  const ParentScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final progress = ref.watch(progressProvider);
    final levels = ref.watch(levelsProvider);
    final totalIslands = levels.asData?.value.length ?? 0;

    final letters = progress.letterCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final allLevels = levels.asData?.value ?? const [];
    final worlds = <String, List<bool>>{};
    for (final level in allLevels) {
      worlds
          .putIfAbsent(level.world, () => <bool>[])
          .add(progress.isFinished(level.id));
    }

    return Scaffold(
      backgroundColor: AppColors.sand,
      appBar: AppBar(
        title: const Text('Progress'),
        backgroundColor: AppColors.sand,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(
            children: [
              _StatCard(
                label: 'Islands finished',
                value: totalIslands > 0
                    ? '${progress.islandsFinished}/$totalIslands'
                    : '${progress.islandsFinished}',
                icon: Icons.flag_rounded,
                color: AppColors.mint,
              ),
              const SizedBox(width: 12),
              _StatCard(
                label: 'Stars earned',
                value: '${progress.totalStars}',
                icon: Icons.star_rounded,
                color: AppColors.sunshine,
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _StatCard(
                label: 'Treasures found',
                value: '${progress.collectibles.length}',
                icon: Icons.card_giftcard_rounded,
                color: AppColors.grape,
              ),
              const SizedBox(width: 12),
              _StatCard(
                label: 'Time this week',
                value: '${(progress.secondsThisWeek / 60).round()} min',
                icon: Icons.schedule_rounded,
                color: AppColors.skyDeep,
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text('Worlds', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          for (final entry in worlds.entries)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _WorldRow(
                name: entry.key,
                done: entry.value.where((d) => d).length,
                total: entry.value.length,
              ),
            ),
          const SizedBox(height: 24),
          Text('Last 7 days', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          _WeekBars(minutes: progress.weeklySeconds
              .map((s) => (s / 60).round())
              .toList()),
          const SizedBox(height: 24),
          Text(
            'Letters practised',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          if (letters.isEmpty)
            Text(
              'Nothing yet — the first island is a good place to start.',
              style: Theme.of(context).textTheme.bodyMedium,
            )
          else
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: letters
                  .map(
                    (entry) => Chip(
                      backgroundColor: Colors.white,
                      label: Text(
                        '${entry.key}  ·  ${entry.value}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          const SizedBox(height: 28),
          Card(
            child: SwitchListTile(
              value: progress.soundOn,
              title: const Text('Voice and sounds'),
              subtitle: const Text('Letters, words and encouragement'),
              onChanged: (value) =>
                  ref.read(progressProvider.notifier).setSound(value),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.explore_rounded,
                  color: AppColors.skyDeep),
              title: const Text('Starting point'),
              subtitle: Text(_startLabel(progress.startWorld)),
              onTap: () => _chooseStart(context, ref),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.password_rounded,
                  color: AppColors.grape),
              title: const Text('Reset parent PIN'),
              subtitle: const Text('You will choose a new one next time'),
              onTap: () async {
                await ref.read(progressProvider.notifier).clearPin();
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('PIN cleared.')),
                  );
                }
              },
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.restart_alt_rounded,
                  color: AppColors.coral),
              title: const Text('Start the adventure again'),
              subtitle: const Text('Clears stars, treasures and progress'),
              onTap: () => _confirmReset(context, ref),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Everything is stored on this device only. No account, no ads, '
            'no data leaves the app.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }

  static String _startLabel(int world) => switch (world) {
        1 => 'Just starting — from Letter Village',
        2 => 'Knows some letters — from Sound Forest',
        3 => 'Reading small words — from Blending Bridge',
        _ => 'Not set',
      };

  Future<void> _chooseStart(BuildContext context, WidgetRef ref) async {
    final choice = await showDialog<int>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: const Text('Where should the adventure open?'),
        children: [
          for (var world = 1; world <= 3; world++)
            SimpleDialogOption(
              onPressed: () => Navigator.of(dialogContext).pop(world),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(_startLabel(world)),
              ),
            ),
        ],
      ),
    );
    if (choice != null) {
      await ref.read(progressProvider.notifier).setStartWorld(choice);
    }
  }

  Future<void> _confirmReset(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Start again?'),
        content: const Text(
          'This clears all stars, treasures and progress on this device.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Start again'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(progressProvider.notifier).resetEverything();
    }
  }
}

class _WorldRow extends StatelessWidget {
  const _WorldRow({
    required this.name,
    required this.done,
    required this.total,
  });

  final String name;
  final int done;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              name,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
          ),
          SizedBox(
            width: 110,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: total == 0 ? 0 : done / total,
                minHeight: 10,
                backgroundColor: AppColors.inkSoft.withValues(alpha: 0.2),
                valueColor:
                    const AlwaysStoppedAnimation<Color>(AppColors.mint),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Text('$done/$total',
              style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadii.card),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 10),
            Text(
              value,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w800,
              ),
            ),
            Text(label, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }
}

class _WeekBars extends StatelessWidget {
  const _WeekBars({required this.minutes});

  final List<int> minutes;

  static const _labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

  @override
  Widget build(BuildContext context) {
    final maxValue = minutes.fold<int>(1, (m, v) => v > m ? v : m);
    final today = DateTime.now();

    return Container(
      height: 150,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.card),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List<Widget>.generate(minutes.length, (i) {
          final day = today.subtract(Duration(days: 6 - i));
          final label = _labels[(day.weekday - 1) % 7];
          final height = 12 + (minutes[i] / maxValue) * 78;
          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                '${minutes[i]}',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 6),
              Container(
                width: 26,
                height: height,
                decoration: BoxDecoration(
                  color: AppColors.skyDeep.withValues(
                    alpha: minutes[i] == 0 ? 0.2 : 0.85,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              const SizedBox(height: 6),
              Text(label, style: Theme.of(context).textTheme.bodyMedium),
            ],
          );
        }),
      ),
    );
  }
}
