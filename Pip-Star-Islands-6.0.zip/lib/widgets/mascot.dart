import 'package:flutter/material.dart';

import '../core/theme/app_theme.dart';

/// Pip, the little fox who sails between the islands.
///
/// Emoji today so the app ships with zero image assets; swap the [Text] for
/// an `Image.asset` (or Rive/Lottie) when illustrations are ready — nothing
/// else in the app needs to change.
class PipMascot extends StatefulWidget {
  const PipMascot({super.key, this.size = 76, this.emoji = '🦊'});

  final double size;
  final String emoji;

  @override
  State<PipMascot> createState() => _PipMascotState();
}

class _PipMascotState extends State<PipMascot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) => Transform.translate(
        offset: Offset(0, -6 * _controller.value),
        child: child,
      ),
      child: Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: AppColors.ink.withValues(alpha: 0.15),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        alignment: Alignment.center,
        child: Text(
          widget.emoji,
          style: TextStyle(fontSize: widget.size * 0.55),
        ),
      ),
    );
  }
}

/// Pip plus a rounded speech bubble. The app's main way of "talking".
class PipSays extends StatelessWidget {
  const PipSays({
    super.key,
    required this.text,
    this.mascotSize = 64,
    this.onTapBubble,
  });

  final String text;
  final double mascotSize;
  final VoidCallback? onTapBubble;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        PipMascot(size: mascotSize),
        const SizedBox(width: 12),
        Expanded(
          child: GestureDetector(
            onTap: onTapBubble,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadii.card),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.ink.withValues(alpha: 0.10),
                    blurRadius: 12,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Text(
                text,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
