import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// All spoken audio in the app.
///
/// Uses on-device text-to-speech so there are no audio files to ship and
/// nothing to download. Every call is safe to fire and forget: if a device
/// has no voice installed the app simply stays quiet.
class SpeechService {
  final FlutterTts _tts = FlutterTts();
  bool _ready = false;
  bool enabled = true;

  Future<void> init() async {
    if (_ready) return;
    try {
      await _tts.setLanguage('en-US');
      await _tts.setSpeechRate(0.42); // slow and clear for beginners
      await _tts.setPitch(1.15); // friendly, slightly playful
      await _tts.setVolume(1.0);
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  Future<void> say(String text) async {
    if (!enabled || text.trim().isEmpty) return;
    await init();
    try {
      await _tts.stop();
      await _tts.speak(text);
    } catch (_) {
      // Never let audio problems interrupt play.
    }
  }

  /// Says a letter as its *sound*, not its alphabet name, when we have one.
  Future<void> sayLetterSound(String letter, {String? sound}) =>
      say(sound ?? letter);

  /// Says a word, then spells it out slowly.
  Future<void> sayWordThenLetters(String word) async {
    final spelled = word.split('').join(', ');
    await say('$word. $spelled. $word.');
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }

  /// A small buzz that pairs with visual praise.
  void cheerHaptic() => HapticFeedback.mediumImpact();

  void softHaptic() => HapticFeedback.selectionClick();
}
