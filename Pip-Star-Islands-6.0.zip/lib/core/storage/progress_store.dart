import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Everything we remember about the child's journey.
///
/// Deliberately tiny and local: no accounts, no network, no personal data.
class ProgressState {
  const ProgressState({
    this.starsByLevel = const {},
    this.collectibles = const {},
    this.secondsByDay = const {},
    this.letterCounts = const {},
    this.soundOn = true,
    this.startWorld = 0,
    this.pinHash,
  });

  /// levelId -> best number of stars earned.
  final Map<String, int> starsByLevel;

  /// Collectible ids the child has found.
  final Set<String> collectibles;

  /// yyyy-MM-dd -> seconds played that day.
  final Map<String, int> secondsByDay;

  /// letter -> how many times it has been practised.
  final Map<String, int> letterCounts;

  final bool soundOn;

  /// Chosen by a grown-up during setup: worlds up to and including this one
  /// are open from the start. 0 means setup has not happened yet.
  final int startWorld;

  /// SHA-256 of the parent PIN, or null when no PIN has been set.
  final String? pinHash;

  bool get needsSetup => startWorld == 0;

  bool get hasPin => pinHash != null;

  int get totalStars =>
      starsByLevel.values.fold(0, (sum, stars) => sum + stars);

  int get islandsFinished => starsByLevel.length;

  bool isFinished(String levelId) => starsByLevel.containsKey(levelId);

  int starsFor(String levelId) => starsByLevel[levelId] ?? 0;

  int get secondsThisWeek {
    final today = DateTime.now();
    var total = 0;
    for (var i = 0; i < 7; i++) {
      total += secondsByDay[_dayKey(today.subtract(Duration(days: i)))] ?? 0;
    }
    return total;
  }

  /// Seconds played for each of the last 7 days, oldest first.
  List<int> get weeklySeconds {
    final today = DateTime.now();
    return List<int>.generate(7, (i) {
      final day = today.subtract(Duration(days: 6 - i));
      return secondsByDay[_dayKey(day)] ?? 0;
    });
  }

  ProgressState copyWith({
    Map<String, int>? starsByLevel,
    Set<String>? collectibles,
    Map<String, int>? secondsByDay,
    Map<String, int>? letterCounts,
    bool? soundOn,
    int? startWorld,
    String? pinHash,
    bool clearPin = false,
  }) {
    return ProgressState(
      starsByLevel: starsByLevel ?? this.starsByLevel,
      collectibles: collectibles ?? this.collectibles,
      secondsByDay: secondsByDay ?? this.secondsByDay,
      letterCounts: letterCounts ?? this.letterCounts,
      soundOn: soundOn ?? this.soundOn,
      startWorld: startWorld ?? this.startWorld,
      pinHash: clearPin ? null : (pinHash ?? this.pinHash),
    );
  }

  Map<String, dynamic> toJson() => {
    'starsByLevel': starsByLevel,
    'collectibles': collectibles.toList(),
    'secondsByDay': secondsByDay,
    'letterCounts': letterCounts,
    'soundOn': soundOn,
    'startWorld': startWorld,
    'pinHash': pinHash,
  };

  factory ProgressState.fromJson(Map<String, dynamic> json) => ProgressState(
    starsByLevel: _intMap(json['starsByLevel']),
    collectibles: ((json['collectibles'] as List<dynamic>?) ?? const [])
        .map((e) => e as String)
        .toSet(),
    secondsByDay: _intMap(json['secondsByDay']),
    letterCounts: _intMap(json['letterCounts']),
    soundOn: json['soundOn'] as bool? ?? true,
    startWorld: (json['startWorld'] as num?)?.toInt() ?? 0,
    pinHash: json['pinHash'] as String?,
  );

  static Map<String, int> _intMap(Object? raw) {
    if (raw is! Map) return const {};
    return raw.map((key, value) =>
        MapEntry(key.toString(), (value as num?)?.toInt() ?? 0));
  }

  static String _dayKey(DateTime date) {
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '${date.year}-$month-$day';
  }
}

class ProgressController extends StateNotifier<ProgressState> {
  ProgressController(this._prefs) : super(const ProgressState()) {
    _load();
  }

  static const String _key = 'progress_v1';

  final SharedPreferences _prefs;

  void _load() {
    final raw = _prefs.getString(_key);
    if (raw == null) return;
    try {
      state = ProgressState.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      // Corrupt data should never block a child from playing.
      state = const ProgressState();
    }
  }

  Future<void> _save() => _prefs.setString(_key, jsonEncode(state.toJson()));

  /// Keeps the child's best result; replays never take stars away.
  Future<void> finishLevel({
    required String levelId,
    required int stars,
    required String collectibleId,
  }) async {
    final best = <String, int>{...state.starsByLevel};
    final current = best[levelId] ?? 0;
    best[levelId] = stars > current ? stars : current;

    state = state.copyWith(
      starsByLevel: best,
      collectibles: {...state.collectibles, collectibleId},
    );
    await _save();
  }

  Future<void> notePractice(List<String> letters) async {
    final counts = <String, int>{...state.letterCounts};
    for (final letter in letters) {
      final clean = letter.trim().toLowerCase();
      if (clean.isEmpty) continue;
      counts[clean] = (counts[clean] ?? 0) + 1;
    }
    state = state.copyWith(letterCounts: counts);
    await _save();
  }

  Future<void> addPlaySeconds(int seconds) async {
    if (seconds <= 0) return;
    final key = ProgressState._dayKey(DateTime.now());
    final byDay = <String, int>{...state.secondsByDay};
    byDay[key] = (byDay[key] ?? 0) + seconds;
    state = state.copyWith(secondsByDay: byDay);
    await _save();
  }

  Future<void> setSound(bool enabled) async {
    state = state.copyWith(soundOn: enabled);
    await _save();
  }

  Future<void> setStartWorld(int world) async {
    state = state.copyWith(startWorld: world);
    await _save();
  }

  static String hashPin(String pin) =>
      sha256.convert(utf8.encode('pip-salt-' + pin)).toString();

  Future<void> setPin(String pin) async {
    state = state.copyWith(pinHash: hashPin(pin));
    await _save();
  }

  bool checkPin(String pin) => state.pinHash == hashPin(pin);

  Future<void> clearPin() async {
    state = state.copyWith(clearPin: true);
    await _save();
  }

  /// Clears play progress. Keeps the sound setting, the PIN and the chosen
  /// starting world so a grown-up does not have to set those up again.
  Future<void> resetEverything() async {
    state = ProgressState(
      soundOn: state.soundOn,
      startWorld: state.startWorld,
      pinHash: state.pinHash,
    );
    await _save();
  }
}
