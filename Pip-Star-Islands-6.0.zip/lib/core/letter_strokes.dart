import 'dart:math' as math;
import 'dart:ui' show Offset;

/// Hand-authored letter shapes in a unit square (0..1, y grows downward).
///
/// Each letter is a list of strokes; each stroke is an ordered list of guide
/// points. The tracing activity turns these into dots the child colours in
/// with a fingertip, so the shapes only need to be recognisable, not
/// typographically perfect.
///
/// Writing band: ascender 0.14, x-height top 0.42, baseline 0.82,
/// descender 0.97.
const double _xTop = 0.42;
const double _base = 0.82;
const double _asc = 0.14;
const double _desc = 0.97;
const double _pi = math.pi;

List<Offset> _line(Offset a, Offset b, {int steps = 14}) =>
    List<Offset>.generate(steps + 1, (i) => Offset.lerp(a, b, i / steps)!);

/// One continuous stroke through several points (used for v, w, x, y, z).
List<Offset> _poly(List<Offset> points, {int stepsPerLeg = 10}) {
  final result = <Offset>[];
  for (var i = 0; i < points.length - 1; i++) {
    final leg = _line(points[i], points[i + 1], steps: stepsPerLeg);
    result.addAll(i == 0 ? leg : leg.skip(1));
  }
  return result;
}

List<Offset> _arc(
  Offset center,
  double rx,
  double ry,
  double startAngle,
  double sweep, {
  int steps = 26,
}) =>
    List<Offset>.generate(steps + 1, (i) {
      final t = startAngle + sweep * (i / steps);
      return Offset(
        center.dx + rx * math.cos(t),
        center.dy + ry * math.sin(t),
      );
    });

/// Full lowercase alphabet, so any letter in the content can be traced.
final Map<String, List<List<Offset>>> letterStrokes = {
  'a': [
    _arc(const Offset(0.46, 0.62), 0.17, 0.20, -0.25 * _pi, -2.0 * _pi),
    _line(const Offset(0.63, _xTop), const Offset(0.63, _base)),
  ],
  'b': [
    _line(const Offset(0.34, _asc), const Offset(0.34, _base)),
    _arc(const Offset(0.52, 0.62), 0.18, 0.20, -0.5 * _pi, 2.0 * _pi),
  ],
  'c': [
    _arc(const Offset(0.52, 0.62), 0.18, 0.20, -0.25 * _pi, -1.5 * _pi),
  ],
  'd': [
    _arc(const Offset(0.44, 0.62), 0.17, 0.20, -0.25 * _pi, -2.0 * _pi),
    _line(const Offset(0.61, _asc), const Offset(0.61, _base)),
  ],
  'e': [
    _line(const Offset(0.33, 0.62), const Offset(0.68, 0.62)),
    _arc(const Offset(0.50, 0.62), 0.18, 0.20, 0, -1.6 * _pi),
  ],
  'f': [
    _line(const Offset(0.50, 0.27), const Offset(0.50, _base)),
    _arc(const Offset(0.62, 0.27), 0.12, 0.13, _pi, 0.8 * _pi, steps: 16),
    _line(const Offset(0.34, 0.45), const Offset(0.66, 0.45), steps: 10),
  ],
  'g': [
    _arc(const Offset(0.46, 0.62), 0.17, 0.20, -0.25 * _pi, -2.0 * _pi),
    _line(const Offset(0.63, _xTop), const Offset(0.63, 0.92)),
    _arc(const Offset(0.48, 0.92), 0.15, 0.06, 0, 0.9 * _pi, steps: 14),
  ],
  'h': [
    _line(const Offset(0.34, _asc), const Offset(0.34, _base)),
    _arc(const Offset(0.50, 0.55), 0.16, 0.13, _pi, _pi),
    _line(const Offset(0.66, 0.55), const Offset(0.66, _base)),
  ],
  'i': [
    _line(const Offset(0.50, _xTop), const Offset(0.50, _base)),
    _arc(const Offset(0.50, 0.28), 0.025, 0.025, 0, 2.0 * _pi, steps: 10),
  ],
  'j': [
    _line(const Offset(0.55, _xTop), const Offset(0.55, 0.88)),
    _arc(const Offset(0.42, 0.88), 0.13, 0.08, 0, 0.9 * _pi, steps: 16),
    _arc(const Offset(0.55, 0.28), 0.025, 0.025, 0, 2.0 * _pi, steps: 10),
  ],
  'k': [
    _line(const Offset(0.34, _asc), const Offset(0.34, _base)),
    _line(const Offset(0.68, 0.45), const Offset(0.36, 0.64), steps: 12),
    _line(const Offset(0.44, 0.58), const Offset(0.70, _base), steps: 12),
  ],
  'l': [
    _line(const Offset(0.50, _asc), const Offset(0.50, _base)),
  ],
  'm': [
    _line(const Offset(0.24, _xTop), const Offset(0.24, _base)),
    _arc(const Offset(0.37, 0.54), 0.13, 0.12, _pi, _pi, steps: 20),
    _line(const Offset(0.50, 0.54), const Offset(0.50, _base)),
    _arc(const Offset(0.63, 0.54), 0.13, 0.12, _pi, _pi, steps: 20),
    _line(const Offset(0.76, 0.54), const Offset(0.76, _base)),
  ],
  'n': [
    _line(const Offset(0.34, _xTop), const Offset(0.34, _base)),
    _arc(const Offset(0.50, 0.55), 0.16, 0.13, _pi, _pi),
    _line(const Offset(0.66, 0.55), const Offset(0.66, _base)),
  ],
  'o': [
    _arc(const Offset(0.50, 0.62), 0.18, 0.20, -0.5 * _pi, 2.0 * _pi),
  ],
  'p': [
    _line(const Offset(0.34, _xTop), const Offset(0.34, _desc)),
    _arc(const Offset(0.52, 0.62), 0.18, 0.20, -0.5 * _pi, 2.0 * _pi),
  ],
  'q': [
    _arc(const Offset(0.46, 0.62), 0.17, 0.20, -0.25 * _pi, -2.0 * _pi),
    _line(const Offset(0.63, _xTop), const Offset(0.63, _desc)),
  ],
  'r': [
    _line(const Offset(0.38, _xTop), const Offset(0.38, _base)),
    _arc(const Offset(0.52, 0.53), 0.14, 0.11, _pi, 0.7 * _pi, steps: 16),
  ],
  's': [
    _arc(const Offset(0.50, 0.54), 0.15, 0.12, -0.15 * _pi, -1.0 * _pi),
    _arc(const Offset(0.50, 0.70), 0.15, 0.11, 1.21 * _pi, -1.05 * _pi),
  ],
  't': [
    _line(const Offset(0.50, 0.16), const Offset(0.50, _base)),
    _line(const Offset(0.33, _xTop), const Offset(0.67, _xTop), steps: 10),
  ],
  'u': [
    _line(const Offset(0.34, _xTop), const Offset(0.34, 0.72), steps: 10),
    _arc(const Offset(0.50, 0.72), 0.16, 0.10, _pi, -_pi, steps: 20),
    _line(const Offset(0.66, _xTop), const Offset(0.66, _base)),
  ],
  'v': [
    _poly(
      const [Offset(0.32, _xTop), Offset(0.50, _base), Offset(0.68, _xTop)],
      stepsPerLeg: 12,
    ),
  ],
  'w': [
    _poly(const [
      Offset(0.22, _xTop),
      Offset(0.35, _base),
      Offset(0.50, 0.55),
      Offset(0.65, _base),
      Offset(0.78, _xTop),
    ]),
  ],
  'x': [
    _line(const Offset(0.32, _xTop), const Offset(0.68, _base)),
    _line(const Offset(0.68, _xTop), const Offset(0.32, _base)),
  ],
  'y': [
    _line(const Offset(0.32, _xTop), const Offset(0.52, 0.72), steps: 12),
    _line(const Offset(0.70, _xTop), const Offset(0.38, _desc), steps: 18),
  ],
  'z': [
    _poly(const [
      Offset(0.32, 0.45),
      Offset(0.68, 0.45),
      Offset(0.32, 0.80),
      Offset(0.68, 0.80),
    ], stepsPerLeg: 12),
  ],
};

/// Falls back to a gentle circle so a missing letter never crashes the app.
List<List<Offset>> strokesFor(String letter) =>
    letterStrokes[letter.toLowerCase()] ?? letterStrokes['o']!;
