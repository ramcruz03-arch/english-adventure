import 'dart:math';

/// Every word the child sees or hears lives here.
///
/// One place to keep the voice warm, short and pressure-free — and one place
/// to translate later.
class Copy {
  static final _random = Random();

  // Buttons
  static const start = "Let's go!";
  static const next = 'Next';
  static const again = 'Again';
  static const hear = 'Hear it';
  static const backToMap = 'Back to the map';
  static const playAgain = 'Play again';
  static const grownUps = 'Grown-ups';
  static const keepGoing = 'Keep going';
  static const imDone = "I'm done!";

  // Encouragement after a correct or completed action
  static const _praise = [
    'Nice one!',
    'You did it!',
    'Wow!',
    'Super!',
    'Great listening!',
    'Look at you go!',
    'Brilliant!',
    'High five!',
  ];

  /// Gentle nudges. Never "wrong", never "no", never a red X.
  static const _nudges = [
    'Nearly! Try another one.',
    'Good try! Have another go.',
    'Hmm, keep looking!',
    'Almost there!',
    'That one is sleepy. Try again!',
  ];

  static const _hints = [
    'Listen again, then choose.',
    'The first sound helps!',
    'Say it slowly: push the sounds together.',
  ];

  static String praise() => _praise[_random.nextInt(_praise.length)];

  static String nudge() => _nudges[_random.nextInt(_nudges.length)];

  static String hint() => _hints[_random.nextInt(_hints.length)];

  // Rewards
  static String rewardFound(String name) => 'You found the $name!';

  static const rewardSub = 'It goes in your treasure bag.';

  // Map
  static const mapTitle = 'Star Islands';

  static const lockedMessage = 'Finish the island before this one first!';

  static String islandDone(String title) => '$title is all done!';
}
