import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/content_repository.dart';
import '../data/models/level.dart';
import 'audio/speech_service.dart';
import 'storage/progress_store.dart';

/// Overridden in `main()` once SharedPreferences has loaded.
final sharedPreferencesProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('SharedPreferences not initialised'),
);

final contentRepositoryProvider =
    Provider<ContentRepository>((ref) => ContentRepository());

final levelsProvider = FutureProvider<List<Level>>(
  (ref) => ref.watch(contentRepositoryProvider).levels(),
);

final progressProvider =
    StateNotifierProvider<ProgressController, ProgressState>(
  (ref) => ProgressController(ref.watch(sharedPreferencesProvider)),
);

final speechProvider = Provider<SpeechService>((ref) {
  final speech = SpeechService()..init();
  // Keep the voice in sync with the parent's sound switch.
  speech.enabled = ref.watch(progressProvider.select((p) => p.soundOn));
  ref.onDispose(speech.stop);
  return speech;
});
