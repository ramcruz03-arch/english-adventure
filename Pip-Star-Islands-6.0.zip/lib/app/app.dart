import 'package:flutter/material.dart';

import '../core/theme/app_theme.dart';
import '../features/map/map_screen.dart';

class PipIslandsApp extends StatelessWidget {
  const PipIslandsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pip and the Star Islands',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const MapScreen(),
      builder: (context, child) {
        // Children's devices are often set to huge system fonts; clamp so the
        // layout never breaks, but still respect a parent's accessibility
        // choice within a sensible range.
        final media = MediaQuery.of(context);
        return MediaQuery(
          data: media.copyWith(
            textScaler: media.textScaler.clamp(
              minScaleFactor: 0.9,
              maxScaleFactor: 1.3,
            ),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}
