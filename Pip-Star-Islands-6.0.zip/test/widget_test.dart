import 'package:english_adventure/core/letter_strokes.dart';
import 'package:english_adventure/core/storage/progress_store.dart';
import 'package:english_adventure/data/models/level.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('level json parses into typed steps', () {
    final level = Level.fromJson({
      'id': 'isle_test',
      'index': 1,
      'world': 'Letter Village',
      'worldIndex': 1,
      'title': 'Test Island',
      'subtitle': 'Meet s',
      'emoji': '🌞',
      'color': '#FFB703',
      'reward': {'id': 'shell', 'name': 'Shell', 'emoji': '🐚'},
      'steps': [
        {
          'type': 'letterIntro',
          'letter': 's',
          'sound': 'sss',
          'exampleWord': 'sun',
          'exampleEmoji': '🌞',
          'say': 'This is s.',
        },
        {
          'type': 'spell',
          'word': 'sat',
          'emoji': '🪑',
          'distractors': ['p'],
        },
        {
          'type': 'story',
          'emoji': '🐱',
          'sentences': ['The cat sat.'],
          'question': 'Who sat?',
          'options': ['cat', 'dog'],
          'answer': 'cat',
        },
      ],
    });

    expect(level.steps.length, 3);
    expect(level.world, 'Letter Village');
    expect(level.steps.first, isA<LetterIntroStep>());
    expect((level.steps[1] as SpellStep).letters, ['s', 'a', 't']);
    expect(level.steps[2], isA<StoryStep>());
    expect(level.maxStars, 3);
  });

  test('progress keeps the best star result', () {
    var state = const ProgressState(starsByLevel: {'isle_s': 4});
    state = state.copyWith(starsByLevel: {...state.starsByLevel, 'isle_a': 3});

    expect(state.totalStars, 7);
    expect(state.isFinished('isle_s'), isTrue);
    expect(state.isFinished('isle_t'), isFalse);
  });

  test('progress survives a json round trip', () {
    const original = ProgressState(
      starsByLevel: {'isle_s': 4},
      collectibles: {'sun_shell'},
      letterCounts: {'s': 3},
    );
    final restored = ProgressState.fromJson(original.toJson());

    expect(restored.totalStars, 4);
    expect(restored.collectibles, contains('sun_shell'));
    expect(restored.letterCounts['s'], 3);
  });

  test('every letter of the alphabet has traceable strokes', () {
    for (final letter in 'abcdefghijklmnopqrstuvwxyz'.split('')) {
      expect(letterStrokes.containsKey(letter), isTrue, reason: letter);
      expect(strokesFor(letter).isNotEmpty, isTrue, reason: letter);
    }
  });

  test('parent pin hashing is stable and not reversible', () {
    final hash = ProgressController.hashPin('1234');
    expect(hash, ProgressController.hashPin('1234'));
    expect(hash, isNot(ProgressController.hashPin('1235')));
    expect(hash.contains('1234'), isFalse);
  });

  test('placement opens worlds up to the chosen start', () {
    const state = ProgressState(startWorld: 2);
    expect(state.needsSetup, isFalse);
    expect(const ProgressState().needsSetup, isTrue);
  });
}
