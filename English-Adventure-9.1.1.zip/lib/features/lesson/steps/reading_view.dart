import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/celebration.dart';
import '../../../widgets/mascot.dart';

/// Stages of reading the same passage. Independence increases each time,
/// which is where fluency actually comes from.
enum _Stage {
  /// Pip reads, the current sentence highlights.
  listen,

  /// The child reads, tapping any word they need.
  together,

  /// The child reads alone. No help on screen; a long press still helps.
  alone,

  /// One comprehension question.
  question,
}

class ReadingView extends ConsumerStatefulWidget {
  const ReadingView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final ReadingStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<ReadingView> createState() => _ReadingViewState();
}

class _ReadingViewState extends ConsumerState<ReadingView> {
  late _Stage _stage =
      widget.step.independent ? _Stage.alone : _Stage.listen;

  int _spokenSentence = -1;
  bool _reading = false;
  bool _finished = false;
  String _bubble = '';

  /// Sentences with {name} filled in, or a friendly default if the parent
  /// has not set one.
  List<String> get _sentences {
    final name = ref.read(progressProvider).childName;
    return widget.step.sentences
        .map((s) => s.replaceAll('{name}', name.isEmpty ? 'Sam' : name))
        .toList();
  }

  @override
  void initState() {
    super.initState();
    _bubble = widget.step.independent
        ? Copy.readAlone
        : Copy.listenFirst;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(speechProvider).sayNow(_bubble);
    });
  }

  Future<void> _readAloud() async {
    if (_reading) return;
    setState(() => _reading = true);
    final speech = ref.read(speechProvider);

    final sentences = _sentences;
    for (var i = 0; i < sentences.length; i++) {
      if (!mounted) return;
      setState(() => _spokenSentence = i);
      // Bounded: if the engine stalls, the highlight still moves on.
      await speech.say(sentences[i]).timeout(
            const Duration(seconds: 12),
            onTimeout: () {},
          );
      await Future<void>.delayed(const Duration(milliseconds: 250));
    }

    if (!mounted) return;
    setState(() {
      _spokenSentence = -1;
      _reading = false;
      if (_stage == _Stage.listen) {
        _stage = _Stage.together;
        _bubble = Copy.nowYouRead;
      }
    });
    if (_stage == _Stage.together) {
      speech.say(Copy.nowYouRead);
    }
  }

  Future<void> _sayWord(String word) async {
    final clean = word.replaceAll(RegExp(r"[^A-Za-z']"), '');
    if (clean.isEmpty) return;
    final speech = ref.read(speechProvider);
    speech.softHaptic();
    speech.say(clean);
  }

  Future<void> _advance() async {
    final speech = ref.read(speechProvider);

    if (_stage == _Stage.together) {
      setState(() {
        _stage = _Stage.alone;
        _bubble = Copy.readAlone;
      });
      speech.say(Copy.readAlone);
      return;
    }

    if (_stage == _Stage.alone) {
      if (widget.step.hasQuestion) {
        setState(() {
          _stage = _Stage.question;
          _bubble = widget.step.question!;
        });
        speech.say(widget.step.question!);
      } else {
        await _complete();
      }
    }
  }

  Future<void> _answer(String option) async {
    if (_finished) return;
    final speech = ref.read(speechProvider);

    if (option == widget.step.answer) {
      await _complete();
    } else {
      setState(() => _bubble = Copy.readItAgain);
      speech.softHaptic();
      speech.say(Copy.readItAgain);
      await Future<void>.delayed(const Duration(milliseconds: 900));
      if (mounted) {
        setState(() {
          _stage = _Stage.together;
          _bubble = Copy.nowYouRead;
        });
      }
    }
  }

  Future<void> _complete() async {
    if (_finished) return;
    _finished = true;

    final speech = ref.read(speechProvider);
    final progress = ref.read(progressProvider.notifier);
    final name = ref.read(progressProvider).childName;

    // Reading volume is the number that tracks growth.
    await progress.recordReading(widget.step.wordCount);

    // A read with no help on screen is worth remembering.
    if (widget.step.independent) {
      await progress.addMilestone(
        'Read "${widget.step.title}" with no help',
      );
    }

    speech.cheerHaptic();
    showCelebration(context);
    speech.say(Copy.readingPraise(name));
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (mounted) widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    final step = widget.step;
    final sentences = _sentences;

    return Column(
      children: [
        PipSays(text: _bubble),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(step.emoji, style: const TextStyle(fontSize: 40)),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                step.title,
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Expanded(
          child: SingleChildScrollView(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadii.card),
                border: Border.all(
                  color: widget.accent.withValues(alpha: 0.3),
                  width: 3,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (var i = 0; i < sentences.length; i++)
                    _Sentence(
                      text: sentences[i],
                      accent: widget.accent,
                      highlighted: _spokenSentence == i,
                      // Tapping for help is offered while reading together,
                      // and hidden (but still available on a long press)
                      // once the child is reading alone.
                      tapForHelp: _stage == _Stage.together,
                      onWord: _sayWord,
                    ),
                  if (_stage == _Stage.question) ...[
                    const Divider(height: 32),
                    Text(
                      step.question!,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: step.options
                          .map(
                            (option) => BigButton(
                              label: option,
                              color: widget.accent,
                              onPressed: () => _answer(option),
                            ),
                          )
                          .toList(),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_stage == _Stage.listen)
          BigButton(
            label: _reading ? Copy.listening : Copy.readToMe,
            icon: Icons.volume_up_rounded,
            color: AppColors.grape,
            expand: true,
            onPressed: _reading ? null : _readAloud,
          )
        else if (_stage == _Stage.together || _stage == _Stage.alone)
          Row(
            children: [
              if (_stage == _Stage.together) ...[
                SoundButton(onPressed: _readAloud, color: AppColors.grape),
                const SizedBox(width: 12),
              ],
              Expanded(
                child: BigButton(
                  label: Copy.iReadIt,
                  icon: Icons.check_rounded,
                  color: AppColors.mint,
                  expand: true,
                  onPressed: _advance,
                ),
              ),
            ],
          ),
      ],
    );
  }
}

class _Sentence extends StatelessWidget {
  const _Sentence({
    required this.text,
    required this.accent,
    required this.highlighted,
    required this.tapForHelp,
    required this.onWord,
  });

  final String text;
  final Color accent;
  final bool highlighted;
  final bool tapForHelp;
  final ValueChanged<String> onWord;

  @override
  Widget build(BuildContext context) {
    final words = text.split(RegExp(r'\s+'));

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(
        color: highlighted
            ? AppColors.sunshine.withValues(alpha: 0.35)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Wrap(
        spacing: 8,
        runSpacing: 4,
        children: words
            .map(
              (word) => GestureDetector(
                onTap: tapForHelp ? () => onWord(word) : null,
                onLongPress: () => onWord(word),
                child: Text(
                  word,
                  style: TextStyle(
                    fontSize: 27,
                    height: 1.35,
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                    decoration:
                        tapForHelp ? TextDecoration.underline : null,
                    decorationStyle: TextDecorationStyle.dotted,
                    decorationColor: accent.withValues(alpha: 0.5),
                  ),
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}
