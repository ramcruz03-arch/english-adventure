import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/celebration.dart';
import '../../../widgets/mascot.dart';

/// Drag the letter tiles into the word.
///
/// A tile in the wrong place simply hops back with a friendly line. After two
/// tries the correct tile starts to glow, so the child always gets there.
class SpellView extends ConsumerStatefulWidget {
  const SpellView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final SpellStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<SpellView> createState() => _SpellViewState();
}

class _SpellViewState extends ConsumerState<SpellView> {
  late final List<String> _tiles;
  late final List<String?> _slots;
  final Set<int> _usedTiles = <int>{};

  String _bubble = '';
  int _wrongTries = 0;
  bool _finished = false;

  @override
  void initState() {
    super.initState();
    _slots = List<String?>.filled(widget.step.letters.length, null);
    _tiles = [...widget.step.letters, ...widget.step.distractors]..shuffle();
    _bubble = 'Build the word.';
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(speechProvider).sayNow('Build the word ${widget.step.word}.');
    });
  }

  int get _nextEmptySlot => _slots.indexWhere((slot) => slot == null);

  /// The tile the child needs next (used for the gentle glow hint).
  int get _hintTile {
    final slot = _nextEmptySlot;
    if (slot < 0) return -1;
    final wanted = widget.step.letters[slot];
    for (var i = 0; i < _tiles.length; i++) {
      if (!_usedTiles.contains(i) && _tiles[i] == wanted) return i;
    }
    return -1;
  }

  void _onDrop(int slotIndex, int tileIndex) {
    if (_finished || _slots[slotIndex] != null) return;

    final speech = ref.read(speechProvider);
    final letter = _tiles[tileIndex];

    if (letter == widget.step.letters[slotIndex]) {
      setState(() {
        _slots[slotIndex] = letter;
        _usedTiles.add(tileIndex);
        _wrongTries = 0;
        _bubble = Copy.praise();
      });
      speech.cheerHaptic();
      speech.sayPhoneme(letter);
      if (!_slots.contains(null)) _complete();
    } else {
      setState(() {
        _wrongTries++;
        _bubble = _wrongTries >= 2 ? Copy.hint() : Copy.nudge();
      });
      speech.softHaptic();
      speech.say(_bubble);
    }
  }

  Future<void> _complete() async {
    _finished = true;
    final speech = ref.read(speechProvider);
    showCelebration(context);
    speech.say('${widget.step.word}! ${Copy.praise()}');
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (mounted) widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    final hintTile = _wrongTries >= 2 ? _hintTile : -1;

    return Column(
      children: [
        PipSays(text: _bubble),
        const SizedBox(height: 16),
        Text(widget.step.emoji, style: const TextStyle(fontSize: 76)),
        const SizedBox(height: 18),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List<Widget>.generate(_slots.length, (i) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: DragTarget<int>(
                onWillAcceptWithDetails: (_) => _slots[i] == null,
                onAcceptWithDetails: (details) => _onDrop(i, details.data),
                builder: (context, candidate, __) {
                  final hovering = candidate.isNotEmpty;
                  final filled = _slots[i];
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 74,
                    height: 84,
                    decoration: BoxDecoration(
                      color: filled != null
                          ? widget.accent
                          : Colors.white.withValues(alpha: hovering ? 1 : 0.6),
                      borderRadius: BorderRadius.circular(AppRadii.tile),
                      border: Border.all(
                        color: hovering
                            ? AppColors.mint
                            : widget.accent.withValues(alpha: 0.5),
                        width: hovering ? 5 : 3,
                      ),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      filled ?? '',
                      style: const TextStyle(
                        fontSize: 46,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  );
                },
              ),
            );
          }),
        ),
        const Spacer(),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: List<Widget>.generate(_tiles.length, (i) {
            if (_usedTiles.contains(i)) {
              return const SizedBox(width: 74, height: 84);
            }
            final tile = _LetterTile(
              letter: _tiles[i],
              accent: widget.accent,
              glowing: i == hintTile,
            );
            return Draggable<int>(
              data: i,
              feedback: Material(
                color: Colors.transparent,
                child: Transform.scale(
                  scale: 1.15,
                  child: _LetterTile(
                    letter: _tiles[i],
                    accent: widget.accent,
                    glowing: false,
                  ),
                ),
              ),
              childWhenDragging: Opacity(opacity: 0.3, child: tile),
              child: tile,
            );
          }),
        ),
        const SizedBox(height: 20),
        BigButton(
          label: Copy.hear,
          icon: Icons.volume_up_rounded,
          color: AppColors.grape,
          expand: true,
          onPressed: () =>
              ref.read(speechProvider).sayBlend(widget.step.word),
        ),
      ],
    );
  }
}

class _LetterTile extends StatelessWidget {
  const _LetterTile({
    required this.letter,
    required this.accent,
    required this.glowing,
  });

  final String letter;
  final Color accent;
  final bool glowing;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: 74,
      height: 84,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadii.tile),
        border: Border.all(
          color: glowing ? AppColors.sunshine : accent.withValues(alpha: 0.35),
          width: glowing ? 5 : 3,
        ),
        boxShadow: [
          BoxShadow(
            color: (glowing ? AppColors.sunshine : AppColors.ink)
                .withValues(alpha: glowing ? 0.45 : 0.12),
            blurRadius: glowing ? 18 : 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Text(
        letter,
        style: TextStyle(
          fontSize: 46,
          fontWeight: FontWeight.w800,
          color: accent,
        ),
      ),
    );
  }
}
