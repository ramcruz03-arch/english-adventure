import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/letter_strokes.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/celebration.dart';
import '../../../widgets/mascot.dart';

/// Handwriting practice.
///
/// The old version lit up any dot near a fingertip, so scribbling back and
/// forth completed a letter and writing `a` backwards scored the same as
/// writing it correctly. This one teaches formation:
///
/// * Pip demonstrates the stroke first, with a start marker and an arrow.
/// * Strokes must be done in order — stroke 2 will not start before 1 ends.
/// * Points must be met in order, so moving backwards lights nothing.
///   Scribbling simply stops working, quietly, with no error message.
/// * The child's own line stays on screen, so they see the letter they made.
/// * Support fades across the course: full letter, then dots, then memory.
///
/// Worth knowing: a finger on glass is the weakest way to practise writing —
/// pencil on paper beats stylus, which beats finger. This activity is
/// deliberately paired with a nudge towards paper rather than pretending to
/// replace it.
class TraceView extends ConsumerStatefulWidget {
  const TraceView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final TraceStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<TraceView> createState() => _TraceViewState();
}

class _TraceViewState extends ConsumerState<TraceView>
    with SingleTickerProviderStateMixin {
  /// How close a fingertip must come to the next guide point.
  static const double _hitRadius = 34;

  /// How far ahead the finger may jump: enough to allow a quick, smooth
  /// line, not enough to let a swipe across the box count as a stroke.
  static const int _lookAhead = 5;

  /// How far off the path before we start counting it as lost.
  static const double _strayDistance = 95;

  /// Each thing to write, in order: (letter, capital?).
  late final List<(String, bool)> _targets =
      widget.step.targets(ref.read(progressProvider).childName);

  int _target = 0;

  (String, bool) get _current => _targets[_target];

  List<List<Offset>> get _strokes =>
      strokesFor(_current.$1, capital: _current.$2);
  late final AnimationController _demo = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  );

  int _stroke = 0;
  int _point = 0;
  int _strays = 0;
  bool _demoPlaying = false;
  bool _finished = false;

  double _box = 300;
  final List<List<Offset>> _ink = <List<Offset>>[];

  bool get _fromMemory => widget.step.support == TraceSupport.memory;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      ref.read(speechProvider).sayNow(widget.step.say);
      if (_targets.length > 1 && mounted) {
        ref.read(speechProvider).say('Little one first.');
      }
      if (mounted && !_fromMemory) _playDemo();
    });
  }

  @override
  void dispose() {
    _demo.dispose();
    super.dispose();
  }

  Future<void> _playDemo() async {
    if (_demoPlaying || _finished) return;
    setState(() => _demoPlaying = true);

    for (var i = _stroke; i < _strokes.length; i++) {
      if (!mounted) return;
      setState(() => _stroke = i);
      _demo.reset();
      await _demo.forward();
      await Future<void>.delayed(const Duration(milliseconds: 200));
    }

    if (!mounted) return;
    setState(() {
      _stroke = 0;
      _point = 0;
      _strays = 0;
      _demoPlaying = false;
    });
    // Say the sound while the hand moves: linking shape, movement and sound
    // is the part that actually helps reading.
    ref.read(speechProvider).say(Copy.yourTurnToWrite);
  }

  void _onPanStart(Offset local) {
    if (_demoPlaying || _finished) return;
    _ink.add(<Offset>[local]);
    _onPanUpdate(local);
  }

  void _onPanUpdate(Offset local) {
    if (_demoPlaying || _finished) return;
    if (_ink.isNotEmpty) _ink.last.add(local);

    if (_fromMemory) {
      setState(() {});
      return;
    }

    final stroke = _strokes[_stroke];
    var matched = _point;

    // Only points AHEAD of where the child has reached can be lit, so
    // going backwards over the letter earns nothing.
    final limit = (_point + _lookAhead).clamp(0, stroke.length - 1);
    for (var i = _point; i <= limit; i++) {
      if ((stroke[i] * _box - local).distance <= _hitRadius) matched = i;
    }

    if (matched > _point) {
      setState(() {
        _point = matched;
        _strays = 0;
      });
      if (_point >= stroke.length - 1) _completeStroke();
      return;
    }

    final expected = stroke[_point] * _box;
    if ((expected - local).distance > _strayDistance) {
      _strays++;
      if (_strays > 60) _offerHelp();
    }
  }

  void _completeStroke() {
    final speech = ref.read(speechProvider);
    speech.softHaptic();

    if (_stroke >= _strokes.length - 1) {
      if (_target < _targets.length - 1) {
        _nextTarget();
      } else {
        _complete();
      }
      return;
    }
    setState(() {
      _stroke++;
      _point = 0;
      _strays = 0;
    });
  }

  /// Little one done, now the big one — or the next letter of a name.
  Future<void> _nextTarget() async {
    final speech = ref.read(speechProvider);
    speech.cheerHaptic();
    ref.read(sfxProvider).starTouch();

    setState(() {
      _target++;
      _stroke = 0;
      _point = 0;
      _strays = 0;
      _ink.clear();
    });

    final (letter, capital) = _current;
    speech.say(
      capital
          ? 'Now the big one. Big ${letter.toUpperCase()}.'
          : 'Now ${letter.toLowerCase()}.',
    );
    if (mounted && !_fromMemory) _playDemo();
  }

  Future<void> _offerHelp() async {
    _strays = 0;
    ref.read(speechProvider).say(Copy.watchAgain);
    if (mounted) _playDemo();
  }

  Future<void> _complete() async {
    if (_finished) return;
    setState(() => _finished = true);

    final speech = ref.read(speechProvider);
    final name = ref.read(progressProvider).childName;
    speech.cheerHaptic();
    showCelebration(context);
    // Fire and forget: progress must never wait on audio.
    speech.say(Copy.writingPraise(widget.step.letter, name));
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (mounted) widget.onDone();
  }

  void _clear() {
    setState(() {
      _ink.clear();
      _stroke = 0;
      _point = 0;
      _strays = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        PipSays(text: _demoPlaying ? Copy.watchMe : widget.step.say),
        const SizedBox(height: 10),
        Expanded(
          child: Center(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final size = constraints.biggest.shortestSide
                    .clamp(220.0, 340.0)
                    .toDouble();
                _box = size;
                return Container(
                  width: size,
                  height: size,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppRadii.card),
                    border: Border.all(
                      color: widget.accent.withValues(alpha: 0.35),
                      width: 3,
                    ),
                  ),
                  child: GestureDetector(
                    onPanStart: (d) => _onPanStart(d.localPosition),
                    onPanUpdate: (d) => _onPanUpdate(d.localPosition),
                    child: Stack(
                      children: [
                        if (widget.step.support == TraceSupport.guided)
                          Center(
                            child: Text(
                              _current.$2
                                  ? _current.$1.toUpperCase()
                                  : _current.$1.toLowerCase(),
                              style: TextStyle(
                                fontSize: size * 0.8,
                                height: 1.0,
                                fontWeight: FontWeight.w800,
                                color:
                                    widget.accent.withValues(alpha: 0.10),
                              ),
                            ),
                          ),
                        AnimatedBuilder(
                          animation: _demo,
                          builder: (context, _) => CustomPaint(
                            size: Size(size, size),
                            painter: _TracePainter(
                              strokes: _strokes,
                              currentStroke: _stroke,
                              currentPoint: _point,
                              ink: _ink,
                              accent: widget.accent,
                              box: size,
                              support: widget.step.support,
                              demoProgress:
                                  _demoPlaying ? _demo.value : null,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        if (_targets.length > 1) ...[
          Text(
            _targets
                .map((t) => t.$2 ? t.$1.toUpperCase() : t.$1.toLowerCase())
                .join('   '),
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: widget.accent.withValues(alpha: 0.55),
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 6),
        ],
        _StrokeDots(
          total: _strokes.length,
          current: _stroke,
          accent: widget.accent,
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            if (!_fromMemory) ...[
              SoundButton(
                onPressed: _playDemo,
                color: AppColors.grape,
              ),
              const SizedBox(width: 12),
            ],
            Expanded(
              child: BigButton(
                label: Copy.again,
                icon: Icons.refresh_rounded,
                color: AppColors.sunshine,
                expand: true,
                onPressed: _clear,
              ),
            ),
            if (_fromMemory) ...[
              const SizedBox(width: 12),
              Expanded(
                child: BigButton(
                  label: Copy.imDone,
                  color: AppColors.mint,
                  expand: true,
                  onPressed: _complete,
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }
}

/// Which stroke of the letter we are on: one dot per stroke.
class _StrokeDots extends StatelessWidget {
  const _StrokeDots({
    required this.total,
    required this.current,
    required this.accent,
  });

  final int total;
  final int current;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    if (total < 2) return const SizedBox(height: 8);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List<Widget>.generate(total, (i) {
        final done = i < current;
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 5),
          width: i == current ? 16 : 12,
          height: i == current ? 16 : 12,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: done || i == current
                ? accent
                : accent.withValues(alpha: 0.25),
          ),
          child: done
              ? const Icon(Icons.check, size: 9, color: Colors.white)
              : null,
        );
      }),
    );
  }
}

class _TracePainter extends CustomPainter {
  const _TracePainter({
    required this.strokes,
    required this.currentStroke,
    required this.currentPoint,
    required this.ink,
    required this.accent,
    required this.box,
    required this.support,
    this.demoProgress,
  });

  final List<List<Offset>> strokes;
  final int currentStroke;
  final int currentPoint;
  final List<List<Offset>> ink;
  final Color accent;
  final double box;
  final TraceSupport support;

  /// 0..1 while Pip is demonstrating the current stroke, null otherwise.
  final double? demoProgress;

  @override
  void paint(Canvas canvas, Size size) {
    final guide = Paint()..color = AppColors.inkSoft.withValues(alpha: 0.30);
    final doneDot = Paint()..color = accent.withValues(alpha: 0.55);
    final startPaint = Paint()..color = AppColors.mint;

    if (support != TraceSupport.memory) {
      for (var s = 0; s < strokes.length; s++) {
        final stroke = strokes[s];

        // Future strokes stay faint so the child is not pulled ahead.
        final isCurrent = s == currentStroke;
        final isPast = s < currentStroke;
        if (s > currentStroke) continue;

        for (var p = 0; p < stroke.length; p++) {
          final point = stroke[p] * box;
          final reached = isPast || (isCurrent && p <= currentPoint);
          canvas.drawCircle(point, reached ? 7 : 5, reached ? doneDot : guide);
        }

        if (isCurrent) {
          _drawStart(canvas, stroke, startPaint);
        }
      }
    } else if (strokes.isNotEmpty) {
      _drawStart(canvas, strokes.first, startPaint);
    }

    // The child's own line, kept on screen.
    final inkPaint = Paint()
      ..color = accent
      ..strokeWidth = 13
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;

    for (final line in ink) {
      if (line.length < 2) {
        if (line.length == 1) {
          canvas.drawCircle(line.first, 6.5, Paint()..color = accent);
        }
        continue;
      }
      final path = Path()..moveTo(line.first.dx, line.first.dy);
      for (final point in line.skip(1)) {
        path.lineTo(point.dx, point.dy);
      }
      canvas.drawPath(path, inkPaint);
    }

    // Pip's demonstration: a moving pen with a trail.
    final progress = demoProgress;
    if (progress != null && currentStroke < strokes.length) {
      final stroke = strokes[currentStroke];
      final upto = (progress * (stroke.length - 1)).floor().clamp(
            0,
            stroke.length - 1,
          );

      final demoPaint = Paint()
        ..color = AppColors.sunshine
        ..strokeWidth = 11
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke;

      if (upto > 0) {
        final path = Path()
          ..moveTo(stroke.first.dx * box, stroke.first.dy * box);
        for (var i = 1; i <= upto; i++) {
          path.lineTo(stroke[i].dx * box, stroke[i].dy * box);
        }
        canvas.drawPath(path, demoPaint);
      }
      canvas.drawCircle(
        stroke[upto] * box,
        13,
        Paint()..color = AppColors.coral,
      );
    }
  }

  /// Green dot plus an arrow showing which way the stroke goes.
  void _drawStart(Canvas canvas, List<Offset> stroke, Paint paint) {
    final start = stroke.first * box;
    canvas.drawCircle(start, 13, paint);

    if (stroke.length < 4) return;
    final next = stroke[3] * box;
    final angle = (next - start).direction;

    canvas.save();
    canvas.translate(start.dx, start.dy);
    canvas.rotate(angle);
    final arrow = Path()
      ..moveTo(6, -5)
      ..lineTo(14, 0)
      ..lineTo(6, 5)
      ..close();
    canvas.drawPath(arrow, Paint()..color = Colors.white);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _TracePainter oldDelegate) => true;
}
