import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/copy.dart';
import '../../../core/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/level.dart';
import '../../../widgets/big_button.dart';
import '../../../widgets/mascot.dart';

/// Meeting a new letter, run the way a phonics class runs.
///
/// A teacher does not say "this is m" and move on. They model the sound,
/// show the mouth shape, ask the child to say it back, then use it in a
/// word. That sequence — **my turn, your turn, our turn** — is what this
/// activity now follows.
///
/// The app cannot hear the child, so "your turn" is a real pause with
/// encouragement rather than a scored response. That is honest: we are
/// prompting practice, not assessing it.
class LetterIntroView extends ConsumerStatefulWidget {
  const LetterIntroView({
    super.key,
    required this.step,
    required this.accent,
    required this.onDone,
  });

  final LetterIntroStep step;
  final Color accent;
  final VoidCallback onDone;

  @override
  ConsumerState<LetterIntroView> createState() => _LetterIntroViewState();
}

enum _Phase { myTurn, yourTurn, theWord }

class _LetterIntroViewState extends ConsumerState<LetterIntroView> {
  _Phase _phase = _Phase.myTurn;
  bool _speaking = false;

  /// How the mouth makes each sound. Children who are told what to do with
  /// their lips and tongue get there faster than children who only hear it.
  static const Map<String, String> _mouthCues = {
    's': 'Teeth together. Hiss like a snake.',
    'a': 'Open your mouth wide.',
    't': 'Tongue behind your teeth. A quick tap.',
    'p': 'Lips together, then pop them open.',
    'i': 'A tiny smile, a short sound.',
    'n': 'Tongue up. Let it hum through your nose.',
    'm': 'Lips together and hum.',
    'd': 'Tongue behind your teeth. Turn your voice on.',
    'g': 'Back of the tongue up. A short growl.',
    'o': 'Round your mouth like an egg.',
    'c': 'Back of the tongue up. A quick click.',
    'k': 'Back of the tongue up. A quick click.',
    'e': 'Mouth a little open, quick and short.',
    'u': 'Mouth relaxed, a short grunt.',
    'r': 'Curl your tongue back and growl.',
    'h': 'Just breathe out, like fogging a window.',
    'b': 'Lips together, then pop with your voice on.',
    'f': 'Top teeth on your bottom lip. Blow.',
    'l': 'Tongue tip up behind your teeth. Sing it.',
    'j': 'Lips forward. A short buzz.',
    'v': 'Top teeth on your bottom lip. Buzz.',
    'w': 'Round your lips, then open them.',
    'y': 'Smile and push the sound out.',
    'z': 'Teeth together and buzz like a bee.',
    'qu': 'Round your lips: k and w together.',
    'x': 'At the end of a word: k and s together.',
  };

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(speechProvider).interrupt();
      _modelSound();
    });
  }

  /// My turn: Pip says the sound, twice, slowly.
  Future<void> _modelSound() async {
    if (_speaking) return;
    setState(() => _speaking = true);

    final speech = ref.read(speechProvider);
    final step = widget.step;

    // Queued, not awaited one by one: the child should reach "your turn"
    // even if the voice is slow or unavailable on this device.
    speech.say(Copy.myTurn);
    speech.sayPhoneme(step.letter, sound: step.sound);
    speech.sayPhoneme(step.letter, sound: step.sound);
    speech.say(
      'Big ${step.letter.toUpperCase()} and little '
      '${step.letter.toLowerCase()} both say it.',
    );

    await Future<void>.delayed(const Duration(milliseconds: 2200));
    if (!mounted) return;

    setState(() {
      _speaking = false;
      if (_phase == _Phase.myTurn) _phase = _Phase.yourTurn;
    });

    if (_phase == _Phase.yourTurn) speech.say(Copy.yourTurn);
  }

  Future<void> _saidIt() async {
    final speech = ref.read(speechProvider);
    speech.cheerHaptic();
    setState(() => _phase = _Phase.theWord);
    speech.say(Copy.praise());
    speech.sayPhoneme(widget.step.letter, sound: widget.step.sound);
    speech.say('${widget.step.exampleWord}. Listen for it at the start.');
  }

  Future<void> _sayWord() async {
    final speech = ref.read(speechProvider);
    speech.softHaptic();
    speech.sayNow(widget.step.exampleWord);
  }

  @override
  Widget build(BuildContext context) {
    final step = widget.step;
    final cue = _mouthCues[step.letter.toLowerCase()];

    return Column(
      children: [
        PipSays(
          text: switch (_phase) {
            _Phase.myTurn => Copy.myTurn,
            _Phase.yourTurn => Copy.yourTurn,
            _Phase.theWord => 'It is in a word too!',
          },
          onTapBubble: _modelSound,
        ),
        const SizedBox(height: 16),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                GestureDetector(
                  onTap: () => ref
                      .read(speechProvider)
                      .sayPhoneme(step.letter, sound: step.sound),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 14,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(AppRadii.card),
                      border: Border.all(
                        color: _speaking
                            ? AppColors.sunshine
                            : widget.accent.withValues(alpha: 0.4),
                        width: _speaking ? 6 : 4,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          step.letter.toLowerCase(),
                          style: TextStyle(
                            fontSize: 108,
                            height: 1.1,
                            fontWeight: FontWeight.w800,
                            color: widget.accent,
                          ),
                        ),
                        const SizedBox(height: 2),
                        // Both forms, taught as a pair: a child who only
                        // meets lowercase cannot read the capital that
                        // starts every sentence.
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _CaseChip(
                              label: step.letter.toUpperCase(),
                              caption: 'big',
                              accent: widget.accent,
                            ),
                            const SizedBox(width: 14),
                            _CaseChip(
                              label: step.letter.toLowerCase(),
                              caption: 'little',
                              accent: widget.accent,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  'says  "${step.sound}"',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                if (cue != null) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.grape.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(AppRadii.button),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('👄', style: TextStyle(fontSize: 22)),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            cue,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                              color: AppColors.ink,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                if (_phase == _Phase.theWord) ...[
                  const SizedBox(height: 18),
                  GestureDetector(
                    onTap: _sayWord,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          step.exampleEmoji,
                          style: const TextStyle(fontSize: 52),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          step.exampleWord,
                          style:
                              Theme.of(context).textTheme.headlineMedium,
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            SoundButton(
              onPressed: _modelSound,
              color: widget.accent,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: switch (_phase) {
                _Phase.myTurn => BigButton(
                    label: Copy.listening,
                    color: AppColors.inkSoft,
                    expand: true,
                    onPressed: null,
                  ),
                _Phase.yourTurn => BigButton(
                    label: Copy.iSaidIt,
                    icon: Icons.record_voice_over_rounded,
                    color: AppColors.mint,
                    expand: true,
                    onPressed: _saidIt,
                  ),
                _Phase.theWord => BigButton(
                    label: Copy.next,
                    icon: Icons.arrow_forward_rounded,
                    color: AppColors.mint,
                    expand: true,
                    onPressed: widget.onDone,
                  ),
              },
            ),
          ],
        ),
      ],
    );
  }
}

/// The big/little pair, shown side by side and labelled.
class _CaseChip extends StatelessWidget {
  const _CaseChip({
    required this.label,
    required this.caption,
    required this.accent,
  });

  final String label;
  final String caption;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 54,
          height: 54,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: accent.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 30,
              height: 1.0,
              fontWeight: FontWeight.w800,
              color: accent,
            ),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          caption,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.inkSoft,
          ),
        ),
      ],
    );
  }
}
