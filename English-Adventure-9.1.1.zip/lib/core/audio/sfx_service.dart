import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart' show AssetManifest, rootBundle;

/// Short sound effects: the star sounds and the island flourish.
///
/// Separate from [SpeechService] on purpose — a chime should be able to ring
/// while Pip is still talking, and effects must never queue behind speech.
///
/// Every call is defensive: a device that cannot play audio simply stays
/// quiet rather than interrupting a child's turn with an error.
class SfxService {
  SfxService();

  final AudioPlayer _player = AudioPlayer(playerId: 'sfx');

  /// Separate player so a phoneme and a chime never cut each other off.
  final AudioPlayer _phonemePlayer = AudioPlayer(playerId: 'phoneme');

  /// Pre-generated voice lines, when they have been added.
  final AudioPlayer _voicePlayer = AudioPlayer(playerId: 'voice');

  Map<String, String>? _voiceClips;

  /// slug -> asset path, read once from the bundle.
  Future<Map<String, String>> _availableVoice() async {
    final cached = _voiceClips;
    if (cached != null) return cached;

    final found = <String, String>{};
    try {
      final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
      for (final key in manifest.listAssets()) {
        if (!key.startsWith('assets/audio/vo/')) continue;
        found[key.split('/').last.split('.').first] = key;
      }
    } catch (_) {
      // no clips yet: fall back to the synthetic voice
    }

    _voiceClips = found;
    return found;
  }

  /// Plays a pre-generated line if one exists, and waits for it to finish so
  /// that lines stay in order. Returns false when there is no clip.
  Future<bool> playVoice(String slug) async {
    if (!enabled) return false;

    final clips = await _availableVoice();
    final path = clips[slug];
    if (path == null) return false;

    try {
      await _voicePlayer.stop();
      await _voicePlayer.play(
        AssetSource(path.replaceFirst('assets/', '')),
        volume: 1.0,
      );
      await _waitFor(_voicePlayer, fallback: 2500);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Waits roughly as long as the clip lasts, and never longer than a few
  /// seconds, whatever the platform reports.
  Future<void> _waitFor(AudioPlayer player, {required int fallback}) async {
    var millis = fallback;
    try {
      final duration = await player
          .getDuration()
          .timeout(const Duration(milliseconds: 400));
      if (duration != null && duration.inMilliseconds > 0) {
        millis = duration.inMilliseconds + 80;
      }
    } catch (_) {
      // keep the fallback
    }
    if (millis > 4000) millis = 4000;
    await Future<void>.delayed(Duration(milliseconds: millis));
  }

  Future<void> stopVoice() async {
    try {
      await _voicePlayer.stop();
    } catch (_) {}
  }

  bool enabled = true;

  /// Which phoneme recordings actually ship in this build.
  ///
  /// Checked once from the asset manifest. Without this, every single sound
  /// tried to load a file that is not there — and a failed asset load per
  /// phoneme is slow enough to feel like the app has hung.
  Set<String>? _recordedPhonemes;

  Future<Set<String>> _availablePhonemes() async {
    final cached = _recordedPhonemes;
    if (cached != null) return cached;

    var found = <String>{};
    try {
      // AssetManifest.json was replaced by AssetManifest.bin in Flutter
      // 3.16. Reading the old path silently found nothing, which meant the
      // recorded sounds never played and the app quietly fell back to the
      // device voice — the exact thing the recordings were meant to fix.
      final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
      found = manifest
          .listAssets()
          .where((key) => key.startsWith('assets/audio/phonemes/'))
          .map((key) => key.split('/').last.split('.').first)
          .toSet();
    } catch (_) {
      found = <String>{};
    }

    _recordedPhonemes = found;
    return found;
  }

  /// A star is awarded: a rising three-note sparkle.
  Future<void> starAward() => _play('audio/star_award.wav');

  /// The child touches the star: a bright glassy ping.
  Future<void> starTouch() => _play('audio/star_touch.wav');

  /// An island is finished.
  Future<void> islandComplete() => _play('audio/island_complete.wav');

  /// Plays a recorded phoneme if one has been added to the project.
  ///
  /// Drop `assets/audio/phonemes/m.wav` in and the app uses it instead of
  /// text-to-speech, with no code change. Returns false when no recording
  /// exists, so the caller can fall back to the synthetic voice.
  ///
  /// This matters: a speech engine will never say an isolated /m/ crisply,
  /// because it is built to read words. Around thirty short recordings are
  /// the single biggest available improvement to how the app sounds.
  Future<bool> playPhoneme(String grapheme) async {
    if (!enabled) return false;

    final name = grapheme.toLowerCase();
    final available = await _availablePhonemes();
    if (!available.contains(name)) return false;

    try {
      await _phonemePlayer.stop();
      await _phonemePlayer.play(
        AssetSource('audio/phonemes/$name.wav'),
        volume: 1.0,
      );
      // Wait the clip's own length rather than for an onPlayerComplete
      // event: some devices never emit it, and waiting on one that never
      // arrives is indistinguishable from the app freezing.
      await _waitFor(_phonemePlayer, fallback: 900);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _play(String asset) async {
    if (!enabled) return;
    try {
      await _player.stop();
      await _player.play(AssetSource(asset), volume: 0.9);
    } catch (_) {
      // No audio on this device: carry on silently.
    }
  }

  Future<void> dispose() async {
    try {
      await _player.dispose();
      await _phonemePlayer.dispose();
      await _voicePlayer.dispose();
    } catch (_) {}
  }
}
