import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../app/theme.dart';
import 'guide.dart';

/// The main child-facing adventure map.
///
/// The map deliberately uses Flutter vector painting instead of heavy image
/// assets so it stays crisp, offline-first and friendly on low-end phones.
class AdventureWorld extends StatefulWidget {
  const AdventureWorld({super.key, required this.mastered, this.onStart});

  final int mastered;
  final VoidCallback? onStart;

  @override
  State<AdventureWorld> createState() => _AdventureWorldState();
}

class _AdventureWorldState extends State<AdventureWorld>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2600),
  )..repeat(reverse: true);

  int? _selectedStop;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _selectStop(int index) {
    setState(() => _selectedStop = index);
    final unlocked = widget.mastered >= [0, 2, 4][index];
    final names = ['Sound Garden', 'Sound Cave', 'Story Tree'];
    if (!unlocked) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Keep exploring to unlock ${names[index]}!'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final unlocked = widget.mastered.clamp(0, 26);
    final reduceMotion = MediaQuery.maybeOf(context)?.disableAnimations ?? false;

    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFBFE5EA), Color(0xFFF7E7C8), Color(0xFFE8F2D8)],
        ),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: const Color(0xFF9ECDB8), width: 2),
        boxShadow: [
          BoxShadow(
            color: Tokens.ink.withValues(alpha: .08),
            blurRadius: 22,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
              child: Row(
                children: [
                  const _WorldBadge(
                    icon: Icons.explore_rounded,
                    label: 'ANIL\'S WORLD',
                  ),
                  const Spacer(),
                  _StarCounter(count: unlocked),
                ],
              ),
            ),
            SizedBox(
              height: 360,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned.fill(
                    child: CustomPaint(
                      painter: _WorldPainter(
                        shimmer: reduceMotion ? 0 : _controller.value,
                      ),
                    ),
                  ),
                  Positioned(
                    left: 26,
                    top: 34,
                    child: _FloatingCloud(
                      amount: reduceMotion ? 0 : _controller.value,
                    ),
                  ),
                  Positioned(
                    right: 36,
                    top: 42,
                    child: _FloatingCloud(
                      amount: reduceMotion ? 0 : (1 - _controller.value),
                      small: true,
                    ),
                  ),
                  Positioned(
                    left: 46,
                    bottom: 68,
                    child: _StopButton(
                      icon: Icons.local_florist_rounded,
                      label: 'Sound Garden',
                      unlocked: true,
                      selected: _selectedStop == 0,
                      onTap: () => _selectStop(0),
                    ),
                  ),
                  Positioned(
                    left: 152,
                    bottom: 126,
                    child: _StopButton(
                      icon: Icons.hearing_rounded,
                      label: 'Sound Cave',
                      unlocked: unlocked >= 2,
                      selected: _selectedStop == 1,
                      onTap: () => _selectStop(1),
                    ),
                  ),
                  Positioned(
                    right: 30,
                    bottom: 58,
                    child: _StopButton(
                      icon: Icons.menu_book_rounded,
                      label: 'Story Tree',
                      unlocked: unlocked >= 4,
                      selected: _selectedStop == 2,
                      onTap: () => _selectStop(2),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0,
                    child: IgnorePointer(
                      child: AnimatedBuilder(
                        animation: _controller,
                        builder: (_, __) {
                          final lift = reduceMotion ? 0.0 : math.sin(_controller.value * math.pi) * 6;
                          return Align(
                            alignment: Alignment(0.0, -0.20),
                            child: Transform.translate(
                              offset: Offset(0, -lift),
                              child: const AnilGuide(size: 94),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Positioned(
                    left: 20,
                    right: 20,
                    bottom: 8,
                    child: Row(
                      children: [
                        Expanded(child: _StickerStrip(unlocked: unlocked)),
                        const SizedBox(width: 10),
                        _TreasureChest(
                          unlocked: unlocked >= 1,
                          onTap: () => _showTreasure(context, unlocked),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 18),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      unlocked == 0
                          ? 'Your first adventure is waiting!'
                          : '$unlocked learning stars are shining in your world.',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  FilledButton.icon(
                    onPressed: widget.onStart,
                    icon: const Icon(Icons.play_arrow_rounded),
                    label: const Text('Play'),
                    style: FilledButton.styleFrom(
                      backgroundColor: Tokens.leaf,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(112, 54),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showTreasure(BuildContext context, int unlocked) {
    final stickerCount = (unlocked / 2).floor().clamp(0, 12);
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Tokens.paper,
        title: Row(
          children: [
            const Icon(Icons.inventory_2_rounded, color: Tokens.marigold, size: 32),
            const SizedBox(width: 8),
            Text('Anil\'s treasure', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
        content: Text(
          stickerCount == 0
              ? 'Finish an adventure to discover your first sticker!'
              : 'You have found $stickerCount sticker${stickerCount == 1 ? '' : 's'} so far. Keep exploring!'
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Keep exploring'),
          ),
        ],
      ),
    );
  }
}

class _WorldBadge extends StatelessWidget {
  const _WorldBadge({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .88),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white, width: 2),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: Tokens.leaf),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
          ],
        ),
      );
}

class _StarCounter extends StatelessWidget {
  const _StarCounter({required this.count});
  final int count;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF4CF),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFF2D98B), width: 2),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.star_rounded, color: Tokens.marigold, size: 22),
            const SizedBox(width: 5),
            Text('$count', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
          ],
        ),
      );
}

class _FloatingCloud extends StatelessWidget {
  const _FloatingCloud({required this.amount, this.small = false});
  final double amount;
  final bool small;

  @override
  Widget build(BuildContext context) {
    final dy = math.sin(amount * math.pi) * 5;
    final scale = small ? .72 : 1.0;
    return Transform.translate(
      offset: Offset(0, dy),
      child: Transform.scale(
        scale: scale,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _cloudBubble(30),
            _cloudBubble(42),
            _cloudBubble(28),
          ],
        ),
      ),
    );
  }

  Widget _cloudBubble(double size) => Container(
        width: size,
        height: size,
        margin: const EdgeInsets.only(right: 2),
        decoration: const BoxDecoration(color: Color(0xEFFFFFFF), shape: BoxShape.circle),
      );
}

class _StopButton extends StatelessWidget {
  const _StopButton({
    required this.icon,
    required this.label,
    required this.unlocked,
    required this.selected,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final bool unlocked;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        label: '$label, ${unlocked ? 'unlocked' : 'locked'}',
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(22),
          child: SizedBox(
            width: 102,
            child: Column(
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  width: selected ? 76 : 68,
                  height: selected ? 76 : 68,
                  decoration: BoxDecoration(
                    color: unlocked ? Colors.white : Tokens.paperDeep,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: selected ? Tokens.marigold : (unlocked ? Tokens.leafLight : Tokens.paperDeep),
                      width: selected ? 4 : 3,
                    ),
                    boxShadow: const [
                      BoxShadow(blurRadius: 8, offset: Offset(0, 4), color: Color(0x22000000)),
                    ],
                  ),
                  child: Icon(
                    unlocked ? icon : Icons.lock_rounded,
                    size: 34,
                    color: unlocked ? Tokens.leaf : Tokens.inkSoft,
                  ),
                ),
                const SizedBox(height: 5),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .88),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    label,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class _StickerStrip extends StatelessWidget {
  const _StickerStrip({required this.unlocked});
  final int unlocked;

  @override
  Widget build(BuildContext context) {
    final stickers = [
      Icons.local_florist_rounded,
      Icons.favorite_rounded,
      Icons.pets_rounded,
      Icons.wb_sunny_rounded,
      Icons.auto_awesome_rounded,
    ];
    final count = (unlocked / 2).floor().clamp(0, stickers.length);
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .84),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white, width: 2),
      ),
      child: Row(
        children: [
          const Icon(Icons.stars_rounded, color: Tokens.marigold, size: 25),
          const SizedBox(width: 5),
          ...List.generate(stickers.length, (i) {
            final active = i < count;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: CircleAvatar(
                radius: 19,
                backgroundColor: active ? const Color(0xFFFFF1BE) : Tokens.paperDeep,
                child: Icon(
                  active ? stickers[i] : Icons.lock_outline_rounded,
                  size: 20,
                  color: active ? Tokens.leaf : Tokens.inkSoft.withValues(alpha: .5),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

class _TreasureChest extends StatefulWidget {
  const _TreasureChest({required this.unlocked, required this.onTap});
  final bool unlocked;
  final VoidCallback onTap;

  @override
  State<_TreasureChest> createState() => _TreasureChestState();
}

class _TreasureChestState extends State<_TreasureChest>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1200),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    return Semantics(
      button: true,
      label: widget.unlocked ? 'Open treasure chest' : 'Locked treasure chest',
      child: InkWell(
        onTap: widget.onTap,
        borderRadius: BorderRadius.circular(20),
        child: AnimatedBuilder(
          animation: _controller,
          builder: (_, child) {
            final lift = reduceMotion || !widget.unlocked ? 0.0 : math.sin(_controller.value * math.pi) * 3;
            return Transform.translate(offset: Offset(0, -lift), child: child);
          },
          child: Container(
            width: 78,
            height: 72,
            decoration: BoxDecoration(
              color: widget.unlocked ? const Color(0xFFFFD25E) : Tokens.paperDeep,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: widget.unlocked ? const Color(0xFFE0A52D) : Tokens.paperDeep, width: 3),
            ),
            child: Icon(
              widget.unlocked ? Icons.inventory_2_rounded : Icons.lock_rounded,
              size: 36,
              color: widget.unlocked ? Tokens.ink : Tokens.inkSoft,
            ),
          ),
        ),
      ),
    );
  }
}

class _WorldPainter extends CustomPainter {
  const _WorldPainter({required this.shimmer});
  final double shimmer;

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..style = PaintingStyle.fill;

    // Distant sky hills.
    p.color = const Color(0xFF9BCB89);
    final hill = Path()
      ..moveTo(0, size.height * .62)
      ..quadraticBezierTo(size.width * .24, size.height * .44, size.width * .48, size.height * .62)
      ..quadraticBezierTo(size.width * .78, size.height * .78, size.width, size.height * .56)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(hill, p);

    p.color = const Color(0xFF70AE67);
    final hill2 = Path()
      ..moveTo(0, size.height * .78)
      ..quadraticBezierTo(size.width * .30, size.height * .58, size.width * .62, size.height * .76)
      ..quadraticBezierTo(size.width * .84, size.height * .9, size.width, size.height * .68)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(hill2, p);

    // Sun and soft rays.
    p.color = const Color(0xFFF6C95F);
    canvas.drawCircle(Offset(size.width - 54, 54), 27, p);
    p.color = const Color(0x66F6C95F);
    canvas.drawCircle(Offset(size.width - 54, 54), 36 + shimmer * 2, p);

    // Trees.
    for (final x in [18.0, 102.0, size.width - 122, size.width - 34]) {
      p.color = const Color(0xFF6C9D58);
      canvas.drawRect(Rect.fromLTWH(x, size.height * .52, 8, 48), p);
      canvas.drawCircle(Offset(x + 4, size.height * .50), 25, p);
      canvas.drawCircle(Offset(x - 10, size.height * .55), 18, p);
      canvas.drawCircle(Offset(x + 18, size.height * .55), 18, p);
    }

    // Winding golden trail.
    final pathPaint = Paint()
      ..color = const Color(0xFFE7CC8F)
      ..strokeWidth = 18
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final path = Path()
      ..moveTo(48, size.height * .73)
      ..cubicTo(size.width * .24, size.height * .52, size.width * .40, size.height * .82, size.width * .58, size.height * .64)
      ..cubicTo(size.width * .74, size.height * .48, size.width * .82, size.height * .76, size.width * .96, size.height * .61);
    canvas.drawPath(path, pathPaint);

    // Tiny flowers/stars along the trail.
    final sparkle = Paint()..color = const Color(0xFFFFE5A0);
    final points = [
      Offset(size.width * .20, size.height * .67),
      Offset(size.width * .43, size.height * .67),
      Offset(size.width * .70, size.height * .60),
      Offset(size.width * .86, size.height * .67),
    ];
    for (var i = 0; i < points.length; i++) {
      final r = 4.0 + math.sin((shimmer * math.pi) + i) * 1.0;
      canvas.drawCircle(points[i], r, sparkle);
    }
  }

  @override
  bool shouldRepaint(covariant _WorldPainter oldDelegate) => oldDelegate.shimmer != shimmer;
}
