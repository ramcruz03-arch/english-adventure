import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/providers.dart';
import '../../app/theme.dart';
import '../../domain/entities/skill_state.dart';
import '../session/session_screen.dart';
import '../parent/parent_dashboard_screen.dart';
import '../shared/big_button.dart';
import '../shared/guide.dart';
import '../shared/adventure_world.dart';
import '../shared/reward_world.dart';

/// Child-first home: one clear action, a calm garden, and no competitive
/// metrics. The parent dashboard remains behind the adult gate.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final childId = ref.watch(activeChildProvider);
    final skills = ref.watch(_skillsProvider(childId));
    final resume = ref.watch(unfinishedSessionProvider(childId));
    final savedSession = resume.asData?.value;
    final busy = resume.isLoading;

    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight - 38),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        const _BrandMark(),
                        const Spacer(),
                        Semantics(
                          button: true,
                          label: 'Parent area',
                          child: IconButton.filledTonal(
                            iconSize: 28,
                            onPressed: () => _parentGate(context),
                            icon: const Icon(Icons.family_restroom_rounded),
                            tooltip: 'Parents',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    const AnilGuide(size: 88, line: "Ready for today's adventure?") ,
                    const SizedBox(height: 18),
                    skills.when(
                      loading: () => const _GardenCard(mastered: 0),
                      error: (_, __) => const _GardenCard(mastered: 0),
                      data: (list) => _GardenCard(
                        mastered: list.where((s) =>
                            s.skillType == 'grapheme' && s.status == SkillStatus.mastered).length,
                      ),
                    ),
                    const SizedBox(height: 18),
                    skills.when(
                      loading: () => const AdventureWorld(mastered: 0),
                      error: (_, __) => const AdventureWorld(mastered: 0),
                      data: (list) => AdventureWorld(
                        mastered: list.where((s) => s.skillType == 'grapheme' && s.status == SkillStatus.mastered).length,
                        onStart: busy ? null : () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SessionScreen(resumeSession: savedSession))),
                      ),
                    ),
                    const SizedBox(height: 14),
                    const _TreasurePreview(),
                    const SizedBox(height: 18),
                    _AdventureCard(
                      resume: savedSession != null,
                      busy: busy,
                      onPressed: busy
                          ? null
                          : resume.hasError
                              ? () => ref.invalidate(unfinishedSessionProvider(childId))
                              : () => Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => SessionScreen(resumeSession: savedSession),
                                    ),
                                  ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _parentGate(BuildContext context) {
    final answer = TextEditingController();
    showDialog(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: Tokens.paper,
        title: const Text('For grown-ups'),
        content: TextField(
          controller: answer,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Year you were born',
            hintText: 'Example: 1985',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final year = int.tryParse(answer.text.trim());
              final age = year == null ? 0 : DateTime.now().year - year;
              if (age >= 18 && age <= 100) {
                Navigator.pop(c);
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ParentDashboardScreen()));
              }
            },
            style: FilledButton.styleFrom(backgroundColor: Tokens.leaf),
            child: const Text('Continue'),
          ),
        ],
      ),
    );
  }
}

final _skillsProvider = FutureProvider.family<List<SkillState>, String>((ref, childId) {
  ref.watch(progressDataRevisionProvider);
  return ref.watch(progressRepositoryProvider).allSkills(childId);
});

class _BrandMark extends StatelessWidget {
  const _BrandMark();

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: Tokens.marigold,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.auto_stories_rounded, color: Tokens.ink, size: 28),
          ),
          const SizedBox(width: 10),
          Text('English Adventure', style: Theme.of(context).textTheme.titleLarge),
        ],
      );
}

class _GardenCard extends StatelessWidget {
  const _GardenCard({required this.mastered});
  final int mastered;

  @override
  Widget build(BuildContext context) {
    final grown = mastered.clamp(0, 26);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFEAF5E9), Color(0xFFF8F0DD)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Tokens.leafLight, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.local_florist_rounded, color: Tokens.leaf, size: 30),
            const SizedBox(width: 8),
            Text('Your learning garden', style: Theme.of(context).textTheme.titleLarge),
          ]),
          const SizedBox(height: 12),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: List.generate(13, (i) => Icon(
              i < ((grown + 1) ~/ 2) ? Icons.eco_rounded : Icons.circle_outlined,
              size: 27,
              color: i < ((grown + 1) ~/ 2) ? Tokens.leaf : Tokens.paperDeep,
            )),
          ),
          const SizedBox(height: 8),
          Text(
            grown == 0 ? 'Your first leaf is waiting.' : '$grown sounds are growing stronger.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}


class _TreasurePreview extends StatefulWidget {
  const _TreasurePreview();
  @override
  State<_TreasurePreview> createState() => _TreasurePreviewState();
}

class _TreasurePreviewState extends State<_TreasurePreview>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF5D8),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: const Color(0xFFF0D795), width: 2),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _controller,
            builder: (_, child) => Transform.translate(
              offset: Offset(0, reduceMotion ? 0 : -math.sin(_controller.value * math.pi) * 3),
              child: child,
            ),
            child: Container(
              width: 62,
              height: 62,
              decoration: BoxDecoration(
                color: const Color(0xFFFFD25E),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFFE0A52D), width: 3),
              ),
              child: const Icon(Icons.inventory_2_rounded, size: 32, color: Tokens.ink),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Treasure & stickers', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 2),
                Text('Every little effort can unlock a new surprise.', style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
          const SizedBox(width: 8),
          const Icon(Icons.auto_awesome_rounded, color: Tokens.marigold, size: 28),
        ],
      ),
    );
  }
}

class _AdventureCard extends StatelessWidget {
  const _AdventureCard({required this.resume, required this.busy, required this.onPressed});
  final bool resume;
  final bool busy;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(28),
          boxShadow: [BoxShadow(color: Tokens.ink.withValues(alpha: .08), blurRadius: 18, offset: const Offset(0, 7))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(color: Tokens.marigold.withValues(alpha: .2), shape: BoxShape.circle),
                child: const Icon(Icons.explore_rounded, color: Tokens.ink, size: 30),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Today\'s adventure', style: Theme.of(context).textTheme.titleLarge),
                Text('10–15 minutes • little steps', style: Theme.of(context).textTheme.bodyMedium),
              ])),
            ]),
            const SizedBox(height: 16),
            BigButton(
              label: busy ? 'Getting ready…' : resume ? 'Continue adventure' : 'Start adventure',
              icon: resume ? Icons.play_arrow_rounded : Icons.rocket_launch_rounded,
              onPressed: onPressed,
            ),
          ],
        ),
      );
}

class _TinyPathPreview extends StatelessWidget {
  const _TinyPathPreview();
  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          _PathDot(icon: Icons.hearing_rounded, label: 'Listen'),
          _PathLine(),
          _PathDot(icon: Icons.touch_app_rounded, label: 'Play'),
          _PathLine(),
          _PathDot(icon: Icons.menu_book_rounded, label: 'Read'),
          _PathLine(),
          _PathDot(icon: Icons.star_rounded, label: 'Celebrate'),
        ],
      );
}

class _PathDot extends StatelessWidget {
  const _PathDot({required this.icon, required this.label});
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Column(children: [
        Icon(icon, color: Tokens.leaf, size: 25),
        const SizedBox(height: 3),
        Text(label, style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 13)),
      ]);
}

class _PathLine extends StatelessWidget {
  const _PathLine();
  @override
  Widget build(BuildContext context) => Container(width: 18, height: 2, margin: const EdgeInsets.only(bottom: 19), color: Tokens.leafLight);
}
