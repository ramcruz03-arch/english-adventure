package com.ramcruz.englishadventure

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
