import java.util.Properties

plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

// Release signing is opt-in. Create android/key.properties (see
// key.properties.example) and the release build is signed with your upload
// key. If the file is absent - as it is on a clean CI runner - we fall back to
// the debug key so `flutter build apk --release` still produces an installable
// APK for sideloading.
val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
val hasUploadKey = keystorePropertiesFile.exists()
if (hasUploadKey) {
    keystorePropertiesFile.inputStream().use { keystoreProperties.load(it) }
}

android {
    namespace = "com.ramcruz.englishadventure"
    // Keep these values explicit so the Android project builds on clean CI
    // runners as well as locally. The Flutter Gradle extension is still used
    // below to locate the Dart project.
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        // Permanent once published to Play - it can never be changed for this
        // listing. Must not be com.example.*, which Play rejects outright.
        applicationId = "com.ramcruz.englishadventure"
        minSdk = 21
        targetSdk = 35
        // Driven by `version:` in pubspec.yaml (0.1.0+1 -> name 0.1.0, code 1)
        // so bumping the version in one place is enough and Android treats new
        // builds as genuine upgrades.
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        if (hasUploadKey) {
            create("release") {
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
                storeFile = (keystoreProperties["storeFile"] as String?)?.let { file(it) }
                storePassword = keystoreProperties["storePassword"] as String
            }
        }
    }

    buildTypes {
        release {
            signingConfig = if (hasUploadKey) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }
}

flutter {
    source = "../.."
}
