import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/providers.dart';
import '../../app/theme.dart';
import '../../domain/content/mini_story.dart';
import '../../domain/entities/skill_state.dart';
import '../shared/big_button.dart';

/// The Story Tree, as its own tab.
///
/// The 3.0 prototype shipped a hard-coded five-line story ("Anil sat. A sun sat
/// up.") with a read-aloud button wired to an empty callback. Two things were
/// wrong with that beyond the dead button: the text was not checked against
/// what the child had been taught, and 'sun' needs /u/, which the curriculum
/// introduces well after that screen would have shown it.
///
/// This shelf instead reads the curated catalog and only opens a story once
/// every grapheme in it has been introduced. A locked story still shows its
/// title, so the shelf reads as a promise rather than a wall.
class StoryShelfScreen extends ConsumerWidget {
  const StoryShelfScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final childId = ref.watch(activeChildProvider);
    final skills = ref.watch(skillsProvider(childId));

    return skills.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (_, __) => const _Shelf(taught: {}),
      data: (list) => _Shelf(
        taught: list
            .where((s) =>
                s.skillType == 'grapheme' && s.status != SkillStatus.untouched)
            .map((s) => s.skillId)
            .toSet(),
      ),
    );
  }
}

class _Shelf extends StatelessWidget {
  const _Shelf({required this.taught});

  final Set<String> taught;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 28),
      children: [
        Text('Story Tree', style: Theme.of(context).textTheme.headlineLarge),
        const SizedBox(height: 6),
        Text('Every word here uses sounds you already know.',
            style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 18),
        for (final story in miniStories)
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: _StoryCard(
              story: story,
              available: story.isAvailable(taught),
            ),
          ),
      ],
    );
  }
}

class _StoryCard extends ConsumerWidget {
  const _StoryCard({required this.story, required this.available});

  final MiniStory story;
  final bool available;

  /// Turns 'story:garden-friends' into 'Garden Friends' so the catalog does
  /// not have to carry a display title before lesson packs add one.
  String get _title => story.id
      .split(':')
      .last
      .split('-')
      .map((w) => w.isEmpty ? w : '${w[0].toUpperCase()}${w.substring(1)}')
      .join(' ');

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: available ? Colors.white : Tokens.paperDeep,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(
          color: available ? Tokens.leafLight : Tokens.paperDeep,
          width: 2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                available ? Icons.menu_book_rounded : Icons.lock_rounded,
                color: available ? Tokens.berry : Tokens.inkSoft,
                size: 30,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(_title,
                    style: Theme.of(context).textTheme.titleLarge),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (!available)
            Text(
              'A few more sounds and this story opens.',
              style: Theme.of(context).textTheme.bodyMedium,
            )
          else ...[
            for (final page in story.pages)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Text(
                  page.text,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ),
            const SizedBox(height: 14),
            ReplayButton(
              label: 'Read it to me',
              onPressed: () async {
                final speech = ref.read(speechProvider);
                for (final page in story.pages) {
                  await speech.speak(page.text);
                }
              },
            ),
          ],
        ],
      ),
    );
  }
}
