import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../domain/entities/garden_stats.dart';

/// Treasure Chest and Sticker Shop, the two reward stops on the map.
///
/// Nothing here can be bought, and nothing expires. The "shop" is a wall the
/// child already owns: stickers appear as sounds grow and then stay. There is
/// no currency, no timer and no purchase surface anywhere in this file, which
/// is what keeps the app truthful about being ad-free and IAP-free in the
/// store listing.
class RewardsScreen extends StatelessWidget {
  const RewardsScreen({super.key, required this.stats});

  final GardenStats stats;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 28),
      children: [
        Text('Your treasure', style: Theme.of(context).textTheme.headlineLarge),
        const SizedBox(height: 14),
        _Chest(stars: stats.stars, opened: stats.sessionsFinished > 0),
        const SizedBox(height: 20),
        Row(
          children: [
            const Icon(Icons.storefront_rounded, color: Tokens.marigold, size: 28),
            const SizedBox(width: 8),
            Text('Sticker Shop', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          stats.stickers == 0
              ? 'Grow two sounds to find your first sticker.'
              : 'You have found ${stats.stickers} of ${_stickers.length}.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 14),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 4,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          children: [
            for (var i = 0; i < _stickers.length; i++)
              _StickerTile(
                icon: _stickers[i].$1,
                name: _stickers[i].$2,
                found: i < stats.stickers,
              ),
          ],
        ),
      ],
    );
  }

  static const _stickers = <(IconData, String)>[
    (Icons.local_florist_rounded, 'Flower'),
    (Icons.wb_sunny_rounded, 'Sun'),
    (Icons.pets_rounded, 'Paw'),
    (Icons.favorite_rounded, 'Heart'),
    (Icons.park_rounded, 'Tree'),
    (Icons.water_drop_rounded, 'Drop'),
    (Icons.auto_awesome_rounded, 'Sparkle'),
    (Icons.emoji_nature_rounded, 'Bee'),
    (Icons.cloud_rounded, 'Cloud'),
    (Icons.nightlight_round, 'Moon'),
    (Icons.grass_rounded, 'Grass'),
    (Icons.star_rounded, 'Star'),
  ];
}

class _Chest extends StatefulWidget {
  const _Chest({required this.stars, required this.opened});

  final int stars;
  final bool opened;

  @override
  State<_Chest> createState() => _ChestState();
}

class _ChestState extends State<_Chest> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1600),
  );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _syncTicker();
  }

  @override
  void didUpdateWidget(covariant _Chest oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Stats arrive asynchronously, so the chest usually starts closed and
    // becomes open one frame later. Without this the lid would never lift.
    if (oldWidget.opened != widget.opened) _syncTicker();
  }

  void _syncTicker() {
    final reduceMotion =
        MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    if (reduceMotion || !widget.opened) {
      if (_controller.isAnimating) _controller.stop();
      _controller.value = 0;
    } else if (!_controller.isAnimating) {
      _controller.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFFF3CE), Color(0xFFFFE49B)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Tokens.chestGoldDeep, width: 2),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _controller,
            builder: (_, child) => Transform.translate(
              offset: Offset(
                0,
                reduceMotion || !widget.opened
                    ? 0
                    : -math.sin(_controller.value * math.pi) * 4,
              ),
              child: child,
            ),
            child: Container(
              width: 88,
              height: 82,
              decoration: BoxDecoration(
                color: widget.opened ? Tokens.chestGold : Tokens.zoneLocked,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: widget.opened
                      ? Tokens.chestGoldDeep
                      : Tokens.zoneLocked,
                  width: 3,
                ),
              ),
              child: Icon(
                widget.opened
                    ? Icons.inventory_2_rounded
                    : Icons.lock_rounded,
                size: 42,
                color: widget.opened ? Tokens.ink : Tokens.inkSoft,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.opened ? 'Great job!' : 'Still locked',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 4),
                Text(
                  widget.opened
                      ? 'You have earned ${widget.stars} star${widget.stars == 1 ? '' : 's'} so far.'
                      : 'Finish one adventure to lift the lid.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StickerTile extends StatelessWidget {
  const _StickerTile({
    required this.icon,
    required this.name,
    required this.found,
  });

  final IconData icon;
  final String name;
  final bool found;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: found ? '$name sticker, found' : '$name sticker, not found yet',
      excludeSemantics: true,
      child: Container(
        decoration: BoxDecoration(
          color: found ? const Color(0xFFFFF1BE) : Tokens.paperDeep,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: found ? Tokens.marigold : Tokens.paperDeep,
            width: 2,
          ),
        ),
        child: Icon(
          found ? icon : Icons.lock_outline_rounded,
          size: 30,
          color: found ? Tokens.leaf : Tokens.inkSoft.withValues(alpha: .5),
        ),
      ),
    );
  }
}
