import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../app/theme.dart';

/// Reusable reward visuals for the child journey.
class StickerBurst extends StatefulWidget {
  const StickerBurst({super.key, required this.visible, this.count = 1});
  final bool visible;
  final int count;

  @override
  State<StickerBurst> createState() => _StickerBurstState();
}

class _StickerBurstState extends State<StickerBurst> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );

  @override
  void initState() {
    super.initState();
    if (widget.visible) _controller.forward();
  }

  @override
  void didUpdateWidget(covariant StickerBurst oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.visible && !oldWidget.visible) _controller.forward(from: 0);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.visible) return const SizedBox.shrink();
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) => CustomPaint(
        painter: _BurstPainter(_controller.value, widget.count),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _BurstPainter extends CustomPainter {
  _BurstPainter(this.progress, this.count);
  final double progress;
  final int count;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint()..style = PaintingStyle.fill;
    final random = math.Random(11);
    for (var i = 0; i < 14; i++) {
      final angle = (math.pi * 2 * i / 14) + .15;
      final distance = 22 + Curves.easeOut.transform(progress) * (70 + random.nextDouble() * 30);
      final pos = center + Offset(math.cos(angle), math.sin(angle)) * distance;
      paint.color = [Tokens.marigold, Tokens.leaf, Tokens.berry, Tokens.sky][i % 4];
      final radius = (1 - progress) * 5 + 2;
      canvas.drawCircle(pos, radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _BurstPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.count != count;
}
