import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../domain/entities/garden_stats.dart';

/// The counter strip across the top of the world, as drawn in the 3.0 art:
/// stars, stickers, hearts, and the way through to the grown-up area.
///
/// The settings cog in the artwork is the adult door. It is deliberately the
/// smallest, plainest target here - a child should be able to find everything
/// else on this row faster than they find this.
class WorldHud extends StatelessWidget {
  const WorldHud({super.key, required this.stats, required this.onAdultTap});

  final GardenStats stats;
  final VoidCallback onAdultTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _Counter(
            icon: Icons.star_rounded,
            tint: Tokens.marigold,
            value: '${stats.stars}',
            semantic: '${stats.stars} stars earned',
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _Counter(
            icon: Icons.auto_awesome_rounded,
            tint: Tokens.leaf,
            value: '${stats.stickers}',
            semantic: '${stats.stickers} stickers collected',
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _Counter(
            icon: Icons.favorite_rounded,
            tint: Tokens.berry,
            value: stats.hearts == GardenStats.heartsMax
                ? 'Full'
                : '${stats.hearts}',
            semantic: stats.hearts == GardenStats.heartsMax
                ? 'Energy full'
                : '${stats.hearts} energy left today',
          ),
        ),
        const SizedBox(width: 8),
        Semantics(
          button: true,
          label: 'Grown-up area',
          child: SizedBox(
            width: 52,
            height: 52,
            child: IconButton.filledTonal(
              onPressed: onAdultTap,
              iconSize: 24,
              icon: const Icon(Icons.settings_rounded),
              tooltip: 'For grown-ups',
              style: IconButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Tokens.inkSoft,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _Counter extends StatelessWidget {
  const _Counter({
    required this.icon,
    required this.tint,
    required this.value,
    required this.semantic,
  });

  final IconData icon;
  final Color tint;
  final String value;
  final String semantic;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: semantic,
      excludeSemantics: true,
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: Tokens.hudCream, width: 2),
          boxShadow: [
            BoxShadow(
              color: Tokens.ink.withValues(alpha: .10),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: tint, size: 24),
            const SizedBox(width: 6),
            Flexible(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  value,
                  maxLines: 1,
                  style: const TextStyle(
                    fontFamily: Tokens.uiFace,
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                    color: Tokens.ink,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
