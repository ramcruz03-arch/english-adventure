import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../domain/entities/zone.dart';
import 'guide.dart';

/// The child-facing adventure map.
///
/// 3.0 changes what this widget shows - six named places instead of three
/// unnamed stops - but not how it is drawn. The map stays Flutter vector
/// painting rather than the illustrated artwork from the store graphic,
/// because that promo image is a 1536px landscape render: shipping the bitmap
/// would cost megabytes, blur on tall phones, and undo the offline-first
/// install size. The painting reads as the same world at any density.
class AdventureWorld extends StatefulWidget {
  const AdventureWorld({
    super.key,
    required this.soundsGrown,
    this.onZoneTap,
  });

  /// Mastered graphemes. Drives every unlock on the map.
  final int soundsGrown;

  final void Function(Zone zone)? onZoneTap;

  @override
  State<AdventureWorld> createState() => _AdventureWorldState();
}

class _AdventureWorldState extends State<AdventureWorld>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2600),
  );

  String? _selected;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Reduce-motion stops the ticker outright rather than animating to a zero
    // offset. A controller that repeats forever pins a frame request every
    // vsync, which costs battery for the very users who asked for less motion
    // and leaves widget tests unable to reach a settled frame.
    final reduceMotion =
        MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    if (reduceMotion) {
      if (_controller.isAnimating) _controller.stop();
      _controller.value = 0;
    } else if (!_controller.isAnimating) {
      _controller.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _tap(Zone zone) {
    setState(() => _selected = zone.id);
    if (!zone.unlockedFor(widget.soundsGrown)) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text(zone.blurb),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Tokens.leaf,
          ),
        );
      return;
    }
    widget.onZoneTap?.call(zone);
  }

  /// Fractional positions along the trail, matching the promo layout: garden
  /// upper-left, forest upper-right, writing mid-left, story mid-right, chest
  /// lower-centre, sticker shop lower-right.
  static const _spots = <String, Offset>{
    'zone:phonics-garden': Offset(0.17, 0.14),
    'zone:word-forest': Offset(0.74, 0.13),
    'zone:writing-world': Offset(0.13, 0.50),
    'zone:story-tree': Offset(0.79, 0.47),
    'zone:treasure-chest': Offset(0.38, 0.79),
    'zone:sticker-shop': Offset(0.76, 0.80),
  };

  @override
  Widget build(BuildContext context) {
    final grown = widget.soundsGrown;
    final reduceMotion = MediaQuery.maybeOf(context)?.disableAnimations ?? false;

    return LayoutBuilder(
      builder: (context, constraints) {
        // Tall enough for six stops without crowding; the map grows a little
        // on tablets rather than stretching the artwork.
        final height = constraints.maxWidth > 620 ? 520.0 : 430.0;

        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: Tokens.grassDeep, width: 2),
            boxShadow: [
              BoxShadow(
                color: Tokens.ink.withValues(alpha: .10),
                blurRadius: 22,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: SizedBox(
              height: height,
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, _) {
                  final shimmer = reduceMotion ? 0.0 : _controller.value;
                  return Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned.fill(
                        child: CustomPaint(
                          painter: _WorldPainter(shimmer: shimmer),
                        ),
                      ),
                      for (final zone in adventureZones)
                        _positioned(zone, constraints.maxWidth, height, grown),
                      Positioned(
                        left: 14,
                        bottom: 12,
                        child: _AnilBubble(
                          lift: reduceMotion
                              ? 0
                              : math.sin(shimmer * math.pi) * 4,
                          line: grown == 0
                              ? "Hi! I'm Anil. Let's learn together!"
                              : 'Keep learning!',
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _positioned(Zone zone, double width, double height, int grown) {
    final spot = _spots[zone.id] ?? const Offset(0.5, 0.5);
    const stopWidth = 108.0;
    // Keep every stop fully inside the card even on a narrow phone.
    final maxLeft = math.max(6.0, width - stopWidth - 6.0);
    final left = (spot.dx * width - stopWidth / 2).clamp(6.0, maxLeft).toDouble();
    return Positioned(
      left: left,
      top: spot.dy * height,
      child: _ZoneStop(
        zone: zone,
        unlocked: zone.unlockedFor(grown),
        selected: _selected == zone.id,
        onTap: () => _tap(zone),
      ),
    );
  }
}

/// Icons live here rather than on [Zone] so the domain layer stays free of
/// Flutter imports.
IconData _iconFor(String zoneId) => switch (zoneId) {
      'zone:phonics-garden' => Icons.local_florist_rounded,
      'zone:word-forest' => Icons.park_rounded,
      'zone:writing-world' => Icons.edit_rounded,
      'zone:story-tree' => Icons.menu_book_rounded,
      'zone:treasure-chest' => Icons.inventory_2_rounded,
      'zone:sticker-shop' => Icons.storefront_rounded,
      _ => Icons.explore_rounded,
    };

Color _tintFor(String zoneId) => switch (zoneId) {
      'zone:phonics-garden' => Tokens.leaf,
      'zone:word-forest' => Tokens.grassDeep,
      'zone:writing-world' => Tokens.sky,
      'zone:story-tree' => Tokens.berry,
      'zone:treasure-chest' => Tokens.chestGoldDeep,
      'zone:sticker-shop' => Tokens.marigold,
      _ => Tokens.leaf,
    };

class _ZoneStop extends StatelessWidget {
  const _ZoneStop({
    required this.zone,
    required this.unlocked,
    required this.selected,
    required this.onTap,
  });

  final Zone zone;
  final bool unlocked;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tint = _tintFor(zone.id);
    return Semantics(
      button: true,
      label: '${zone.label}, ${unlocked ? 'open' : 'locked'}',
      excludeSemantics: true,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: SizedBox(
          width: 108,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                // Comfortably past the 64dp floor even unselected.
                width: selected ? 76 : 70,
                height: selected ? 76 : 70,
                decoration: BoxDecoration(
                  color: unlocked ? Colors.white : Tokens.zoneLocked,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: selected
                        ? Tokens.marigold
                        : (unlocked ? tint : Tokens.zoneLocked),
                    width: selected ? 5 : 3,
                  ),
                  boxShadow: const [
                    BoxShadow(
                      blurRadius: 8,
                      offset: Offset(0, 4),
                      color: Color(0x33000000),
                    ),
                  ],
                ),
                child: Icon(
                  unlocked ? _iconFor(zone.id) : Icons.lock_rounded,
                  size: 34,
                  color: unlocked ? tint : Tokens.inkSoft,
                ),
              ),
              const SizedBox(height: 5),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: unlocked
                      ? Tokens.zoneLabel
                      : Tokens.inkSoft.withValues(alpha: .75),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  zone.label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: Tokens.uiFace,
                    fontSize: 12,
                    height: 1.15,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Anil's greeting, lifted from the promo art's speech bubble.
class _AnilBubble extends StatelessWidget {
  const _AnilBubble({required this.lift, required this.line});

  final double lift;
  final String line;

  @override
  Widget build(BuildContext context) {
    return Transform.translate(
      offset: Offset(0, -lift),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const AnilGuide(size: 62),
          const SizedBox(width: 8),
          Container(
            constraints: const BoxConstraints(maxWidth: 190),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Tokens.paperDeep, width: 2),
            ),
            child: Text(
              line,
              style: const TextStyle(
                fontFamily: Tokens.learningFace,
                fontSize: 15,
                height: 1.25,
                fontWeight: FontWeight.w700,
                color: Tokens.ink,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WorldPainter extends CustomPainter {
  const _WorldPainter({required this.shimmer});
  final double shimmer;

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..style = PaintingStyle.fill;

    // Sky.
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Tokens.skyTop, Tokens.skyBottom],
        ).createShader(Offset.zero & size),
    );

    // Meadow.
    p.color = Tokens.grass;
    final meadow = Path()
      ..moveTo(0, size.height * .30)
      ..quadraticBezierTo(size.width * .26, size.height * .20,
          size.width * .52, size.height * .29)
      ..quadraticBezierTo(
          size.width * .80, size.height * .38, size.width, size.height * .26)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(meadow, p);

    p.color = Tokens.grassDeep;
    final ridge = Path()
      ..moveTo(0, size.height * .58)
      ..quadraticBezierTo(size.width * .34, size.height * .48,
          size.width * .66, size.height * .60)
      ..quadraticBezierTo(
          size.width * .86, size.height * .68, size.width, size.height * .56)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(ridge, p);

    // Sun with a soft breathing halo.
    p.color = const Color(0xFFFFE07A);
    canvas.drawCircle(Offset(size.width * .50, size.height * .10), 24, p);
    p.color = const Color(0x55FFE07A);
    canvas.drawCircle(
        Offset(size.width * .50, size.height * .10), 33 + shimmer * 3, p);

    // The winding trail that links the six stops.
    final trail = Paint()
      ..color = Tokens.trail
      ..strokeWidth = 22
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final trailEdge = Paint()
      ..color = Tokens.trailEdge
      ..strokeWidth = 26
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final route = Path()
      ..moveTo(size.width * .17, size.height * .24)
      ..cubicTo(size.width * .40, size.height * .20, size.width * .58,
          size.height * .16, size.width * .74, size.height * .23)
      ..cubicTo(size.width * .86, size.height * .30, size.width * .30,
          size.height * .40, size.width * .13, size.height * .58)
      ..cubicTo(size.width * .05, size.height * .72, size.width * .55,
          size.height * .58, size.width * .79, size.height * .56)
      ..cubicTo(size.width * .95, size.height * .70, size.width * .55,
          size.height * .86, size.width * .38, size.height * .88);
    canvas.drawPath(route, trailEdge);
    canvas.drawPath(route, trail);

    // Trees around the edges.
    final canopy = Paint()..color = const Color(0xFF3F8A34);
    final trunk = Paint()..color = const Color(0xFF8A5A44);
    final treeSpots = <Offset>[
      Offset(size.width * .04, size.height * .36),
      Offset(size.width * .93, size.height * .35),
      Offset(size.width * .58, size.height * .70),
      Offset(size.width * .06, size.height * .84),
    ];
    for (final o in treeSpots) {
      canvas.drawRect(
        Rect.fromCenter(center: o.translate(0, 24), width: 8, height: 30),
        trunk,
      );
      canvas.drawCircle(o, 22, canopy);
      canvas.drawCircle(o.translate(-14, 8), 15, canopy);
      canvas.drawCircle(o.translate(14, 8), 15, canopy);
    }

    // Flowers along the route.
    final petal = Paint()..color = const Color(0xFFFFF0A8);
    final bloom = <Offset>[
      Offset(size.width * .30, size.height * .32),
      Offset(size.width * .48, size.height * .43),
      Offset(size.width * .66, size.height * .34),
      Offset(size.width * .24, size.height * .66),
      Offset(size.width * .88, size.height * .74),
    ];
    for (var i = 0; i < bloom.length; i++) {
      final r = 5.0 + math.sin((shimmer * math.pi) + i) * 1.2;
      canvas.drawCircle(bloom[i], r, petal);
    }
  }

  @override
  bool shouldRepaint(covariant _WorldPainter oldDelegate) =>
      oldDelegate.shimmer != shimmer;
}
