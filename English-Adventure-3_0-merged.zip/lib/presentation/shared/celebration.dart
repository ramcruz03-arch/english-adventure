import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../app/theme.dart';

class AdventureCelebration extends StatefulWidget {
  const AdventureCelebration({super.key, required this.child, this.enabled = true});
  final Widget child;
  final bool enabled;
  @override
  State<AdventureCelebration> createState() => _AdventureCelebrationState();
}

class _AdventureCelebrationState extends State<AdventureCelebration>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this, duration: const Duration(milliseconds: 850));
  late final Animation<double> _scale = CurvedAnimation(parent: _controller, curve: Curves.elasticOut);
  @override void initState() { super.initState(); if (widget.enabled) _controller.forward(); }
  @override void dispose() { _controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    builder: (context, child) => Stack(fit: StackFit.expand, children: [
      Transform.scale(scale: 0.92 + (_scale.value * 0.08), child: child),
      if (_controller.value > 0 && _controller.value < 1)
        IgnorePointer(child: CustomPaint(painter: _SparklePainter(_controller.value))),
    ]), child: widget.child);
}

class _SparklePainter extends CustomPainter {
  _SparklePainter(this.progress); final double progress;
  @override void paint(Canvas canvas, Size size) {
    final random = math.Random(7); final paint = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < 18; i++) {
      final x = size.width * (0.08 + random.nextDouble() * 0.84);
      final y = size.height * (0.12 + random.nextDouble() * 0.65) - progress * 28;
      paint.color = [Tokens.marigold, Tokens.leaf, Tokens.sky, Tokens.berry][i % 4];
      canvas.drawCircle(Offset(x, y), 2.5 + random.nextDouble() * 3, paint);
    }
  }
  @override bool shouldRepaint(covariant _SparklePainter oldDelegate) => oldDelegate.progress != progress;
}

class FriendlyHint extends StatelessWidget {
  const FriendlyHint({super.key, required this.text}); final String text;
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
    decoration: BoxDecoration(color: Tokens.paper, borderRadius: BorderRadius.circular(18),
      boxShadow: const [BoxShadow(blurRadius: 10, offset: Offset(0, 4), color: Color(0x18000000))]),
    child: Row(children: [const Icon(Icons.favorite_rounded, color: Tokens.berry), const SizedBox(width: 8),
      Expanded(child: Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)))]));
}
