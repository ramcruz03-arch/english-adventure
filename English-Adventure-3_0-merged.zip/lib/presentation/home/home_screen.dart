import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/providers.dart';
import '../../app/theme.dart';
import '../../domain/entities/activity.dart';
import '../../domain/entities/garden_stats.dart';
import '../../domain/entities/zone.dart';
import '../shared/adventure_world.dart';

/// The Garden tab: the map, and how much of it has opened so far.
///
/// This used to be the whole app - brand row, guide, garden card, map,
/// treasure preview and start button stacked in one scroll. The 3.0 shell
/// takes over the chrome (HUD on top, tabs below), so what is left here is the
/// world itself and one honest line about growth.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({
    super.key,
    required this.stats,
    required this.onZoneTap,
    required this.onPlay,
  });

  final GardenStats stats;
  final void Function(Zone zone) onZoneTap;
  final Future<void> Function({GameMode? focus}) onPlay;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final childId = ref.watch(activeChildProvider);
    final resume = ref.watch(unfinishedSessionProvider(childId));
    final busy = resume.isLoading;
    final grown = stats.soundsGrown;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        AdventureWorld(soundsGrown: grown, onZoneTap: onZoneTap),
        const SizedBox(height: 16),
        _GrowthStrip(grown: grown),
        const SizedBox(height: 16),
        SizedBox(
          height: 78,
          child: FilledButton.icon(
            onPressed: busy ? null : () => onPlay(),
            icon: const Icon(Icons.play_arrow_rounded, size: 34),
            label: Text(
              busy ? 'Getting ready…' : 'Play',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            ),
            style: FilledButton.styleFrom(
              backgroundColor: Tokens.leaf,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(Tokens.radius),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// A leaf per two sounds grown. No percentage, no comparison, no streak - the
/// only thing a child is shown about themselves is that something is growing.
class _GrowthStrip extends StatelessWidget {
  const _GrowthStrip({required this.grown});

  final int grown;

  @override
  Widget build(BuildContext context) {
    final leaves = ((grown + 1) ~/ 2).clamp(0, 13);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFEAF5E9), Color(0xFFF8F0DD)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Tokens.leafLight, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.local_florist_rounded,
                  color: Tokens.leaf, size: 30),
              const SizedBox(width: 8),
              Text('Your learning garden',
                  style: Theme.of(context).textTheme.titleLarge),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: List.generate(
              13,
              (i) => Icon(
                i < leaves ? Icons.eco_rounded : Icons.circle_outlined,
                size: 27,
                color: i < leaves ? Tokens.leaf : Tokens.paperDeep,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            grown == 0
                ? 'Your first leaf is waiting.'
                : '$grown sound${grown == 1 ? '' : 's'} growing stronger.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}
