import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/providers.dart';
import '../../app/theme.dart';
import '../../domain/entities/activity.dart';
import '../../domain/entities/garden_stats.dart';
import '../../domain/entities/zone.dart';
import '../home/home_screen.dart';
import '../parent/parent_dashboard_screen.dart';
import '../rewards/rewards_screen.dart';
import '../session/session_screen.dart';
import '../shared/world_hud.dart';
import '../story/story_shelf_screen.dart';

/// Root of the child experience.
///
/// 3.0 introduces the bottom bar. It carries three of the four destinations
/// from that design - Garden, Learn, Story - and replaces the fourth.
///
/// The 3.0 prototype put "Parents" in the child's bottom bar with no gate at
/// all. That cannot ship: an app in the Play Families programme has to keep
/// the adult area behind a check a young child will not pass, and a dashboard
/// of a child's performance is also simply not something to hand a four year
/// old between two games. The slot is now Rewards, and the grown-up door is
/// the cog in the HUD, behind the 2.0 birth-year gate.
class AdventureShell extends ConsumerStatefulWidget {
  const AdventureShell({super.key});

  @override
  ConsumerState<AdventureShell> createState() => _AdventureShellState();
}

class _AdventureShellState extends ConsumerState<AdventureShell> {
  int _tab = 0;

  void _openZone(Zone zone) {
    switch (zone.kind) {
      case ZoneKind.reward:
        setState(() => _tab = 3);
      case ZoneKind.game:
        if (zone.mode == GameMode.miniStory) {
          setState(() => _tab = 2);
          return;
        }
        _startSession(focus: zone.mode);
    }
  }

  Future<void> _startSession({GameMode? focus}) async {
    final childId = ref.read(activeChildProvider);
    final saved = ref.read(unfinishedSessionProvider(childId)).asData?.value;

    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SessionScreen(
          resumeSession: saved,
          focusMode: focus,
        ),
      ),
    );

    // A finished session changes stars, sounds grown and what is unlocked.
    // Refresh once here rather than in each tab.
    if (!mounted) return;
    ref.invalidate(gardenStatsProvider(childId));
    ref.invalidate(skillsProvider(childId));
    ref.invalidate(unfinishedSessionProvider(childId));
  }

  @override
  Widget build(BuildContext context) {
    final childId = ref.watch(activeChildProvider);
    final stats = ref.watch(gardenStatsProvider(childId));
    final resolved = stats.asData?.value ?? const GardenStats();

    final pages = <Widget>[
      HomeScreen(stats: resolved, onZoneTap: _openZone, onPlay: _startSession),
      _LearnTab(stats: resolved, onPlay: _startSession),
      const StoryShelfScreen(),
      RewardsScreen(stats: resolved),
    ];

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
              child: WorldHud(
                stats: resolved,
                onAdultTap: () => _adultGate(context),
              ),
            ),
            Expanded(
              child: IndexedStack(index: _tab, children: pages),
            ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        height: 74,
        backgroundColor: Colors.white,
        indicatorColor: Tokens.leafLight,
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.map_outlined),
            selectedIcon: Icon(Icons.map_rounded),
            label: 'Garden',
          ),
          NavigationDestination(
            icon: Icon(Icons.auto_stories_outlined),
            selectedIcon: Icon(Icons.auto_stories_rounded),
            label: 'Learn',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined),
            selectedIcon: Icon(Icons.menu_book_rounded),
            label: 'Story',
          ),
          NavigationDestination(
            icon: Icon(Icons.card_giftcard_outlined),
            selectedIcon: Icon(Icons.card_giftcard_rounded),
            label: 'Rewards',
          ),
        ],
      ),
    );
  }

  /// The 2.0 birth-year gate, kept verbatim. A wrong answer simply does
  /// nothing: no error, no retry counter, nothing for a child to play with
  /// until it opens.
  void _adultGate(BuildContext context) {
    final answer = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: Tokens.paper,
        title: const Text('For grown-ups'),
        content: TextField(
          controller: answer,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Year you were born',
            hintText: 'Example: 1985',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final year = int.tryParse(answer.text.trim());
              final age = year == null ? 0 : DateTime.now().year - year;
              if (age >= 18 && age <= 100) {
                Navigator.pop(c);
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const ParentDashboardScreen(),
                  ),
                );
              }
            },
            style: FilledButton.styleFrom(backgroundColor: Tokens.leaf),
            child: const Text('Continue'),
          ),
        ],
      ),
    );
  }
}

/// The Learn tab: what today's adventure actually contains, then one button.
///
/// 3.0 hard-coded four letters here (S, M, A, T) with a dead speaker icon.
/// This shows the real planned path instead, so the preview cannot drift from
/// what the session engine is about to run.
class _LearnTab extends ConsumerWidget {
  const _LearnTab({required this.stats, required this.onPlay});

  final GardenStats stats;
  final Future<void> Function({GameMode? focus}) onPlay;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final childId = ref.watch(activeChildProvider);
    final resume = ref.watch(unfinishedSessionProvider(childId));
    final saved = resume.asData?.value;
    final busy = resume.isLoading;

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 28),
      children: [
        Text("Today's adventure",
            style: Theme.of(context).textTheme.headlineLarge),
        const SizedBox(height: 6),
        Text('10–15 minutes • little steps • stop any time',
            style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 20),
        for (final step in _steps)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _StepCard(step: step),
          ),
        const SizedBox(height: 8),
        SizedBox(
          height: 78,
          child: FilledButton.icon(
            onPressed: busy ? null : () => onPlay(),
            icon: Icon(
              saved != null
                  ? Icons.play_arrow_rounded
                  : Icons.rocket_launch_rounded,
              size: 32,
            ),
            label: Text(
              busy
                  ? 'Getting ready…'
                  : saved != null
                      ? 'Continue adventure'
                      : 'Start adventure',
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w700),
            ),
            style: FilledButton.styleFrom(
              backgroundColor: Tokens.leaf,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(Tokens.radius),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Text('No rush. You can try again whenever you like.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium),
      ],
    );
  }

  static const _steps = <(IconData, String, String)>[
    (Icons.hearing_rounded, 'Listen', 'Hear a sound and find it'),
    (Icons.extension_rounded, 'Build', 'Put sounds together into words'),
    (Icons.edit_rounded, 'Write', 'Trace the letter shape'),
    (Icons.menu_book_rounded, 'Read', 'Read a tiny story'),
    (Icons.star_rounded, 'Celebrate', 'Collect your stars'),
  ];
}

class _StepCard extends StatelessWidget {
  const _StepCard({required this.step});

  final (IconData, String, String) step;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Tokens.paperDeep, width: 2),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: Tokens.leafLight,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(step.$1, color: Tokens.leaf, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(step.$2,
                    style: Theme.of(context).textTheme.titleLarge),
                Text(step.$3,
                    style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
