import 'activity.dart';

/// A destination on the adventure map.
///
/// The 3.0 artwork names six places. Each one has to resolve to something the
/// 2.0 engine can actually run, otherwise the map promises a child a room that
/// does not exist. Two of the six are reward rooms rather than games, so
/// [mode] is nullable by design.
enum ZoneKind { game, reward }

class Zone {
  const Zone({
    required this.id,
    required this.label,
    required this.kind,
    required this.unlocksAt,
    required this.blurb,
    this.mode,
  });

  final String id;
  final String label;
  final ZoneKind kind;

  /// Sounds grown before this place opens.
  final int unlocksAt;

  /// Said to the child when the place is still locked. Never a scolding, and
  /// never a number - "two more sounds" is a target, "you have 2/4" is a score.
  final String blurb;

  final GameMode? mode;

  bool unlockedFor(int soundsGrown) => soundsGrown >= unlocksAt;
}

/// The map, in the order a child meets it.
///
/// Gates are deliberately shallow. A child who plays twice should see a new
/// place open; a map that stays grey for a week reads as a locked door, not an
/// invitation.
const adventureZones = <Zone>[
  Zone(
    id: 'zone:phonics-garden',
    label: 'Phonics Garden',
    kind: ZoneKind.game,
    mode: GameMode.letterGarden,
    unlocksAt: 0,
    blurb: 'Where every sound starts.',
  ),
  Zone(
    id: 'zone:word-forest',
    label: 'Word Forest',
    kind: ZoneKind.game,
    mode: GameMode.wordBuilder,
    unlocksAt: 2,
    blurb: 'Grow two sounds and the trees open up.',
  ),
  Zone(
    id: 'zone:writing-world',
    label: 'Writing World',
    kind: ZoneKind.game,
    mode: GameMode.traceWrite,
    unlocksAt: 3,
    blurb: 'One more sound and you can write it too.',
  ),
  Zone(
    id: 'zone:story-tree',
    label: 'Story Tree',
    kind: ZoneKind.game,
    mode: GameMode.miniStory,
    unlocksAt: 6,
    blurb: 'The tree has a story waiting for you.',
  ),
  Zone(
    id: 'zone:treasure-chest',
    label: 'Treasure Chest',
    kind: ZoneKind.reward,
    unlocksAt: 1,
    blurb: 'Finish one adventure to lift the lid.',
  ),
  Zone(
    id: 'zone:sticker-shop',
    label: 'Sticker Shop',
    kind: ZoneKind.reward,
    unlocksAt: 2,
    blurb: 'Stickers arrive as your sounds grow.',
  ),
];
