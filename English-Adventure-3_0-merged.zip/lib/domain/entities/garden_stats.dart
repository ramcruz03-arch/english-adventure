/// Lifetime totals shown in the child-facing HUD.
///
/// The 3.0 visual identity puts a star, sticker and heart counter across the
/// top of the world. Those numbers must come from stored progress, never from
/// a literal in the widget tree: a counter that resets on relaunch teaches a
/// child that their effort did not stick.
class GardenStats {
  const GardenStats({
    this.stars = 0,
    this.sessionsFinished = 0,
    this.soundsGrown = 0,
    this.playedToday = false,
  });

  /// Sum of stars_earned across every finished session.
  final int stars;

  final int sessionsFinished;

  /// Graphemes at mastered status. Drives zone unlocks.
  final int soundsGrown;

  final bool playedToday;

  /// Stickers are earned, not granted: one per two sounds grown, so the
  /// sticker wall can only move when real mastery moves.
  int get stickers => (soundsGrown / 2).floor();

  /// Hearts are energy, not lives. They never run out as a punishment - they
  /// simply show how much of today's gentle session is still ahead. A child
  /// who has already played today sees them part-spent, not empty.
  int get hearts => playedToday ? 3 : 5;

  static const heartsMax = 5;
}
