# English Adventure 3.0 — merge notes

The 3.0 visual identity has been merged **onto** the 2.0 codebase. 2.0 is the
base: its architecture, persistence, audio seam, content pack, accessibility
work, tests and release kit are all intact. 3.0 contributed the shape of the
UI, not the engine.

Nothing in this package has been compiled. It was assembled in an environment
with no Flutter SDK, so `flutter analyze` and `flutter test` are the first
things to run, not a formality.

---

## What 3.0 contributed

| From the 3.0 prototype / promo art | Where it now lives |
| --- | --- |
| Bottom navigation shell | `lib/presentation/shell/adventure_shell.dart` |
| Star / sticker / heart counter strip | `lib/presentation/shared/world_hud.dart` |
| Six named map destinations | `lib/presentation/shared/adventure_world.dart` |
| Treasure Chest + Sticker Shop | `lib/presentation/rewards/rewards_screen.dart` |
| Story as its own destination | `lib/presentation/story/story_shelf_screen.dart` |
| Bright saturated world palette | `Tokens` world section in `lib/app/theme.dart` |

New domain types: `lib/domain/entities/zone.dart`,
`lib/domain/entities/garden_stats.dart`.

## What was rewritten rather than copied

**`home_screen.dart`** is now only the Garden tab — the map plus the growth
strip. The brand row, guide row, treasure preview and start card it used to
stack in one scroll are either in the shell chrome now or gone.

**`adventure_world.dart`** was rebuilt for six stops instead of three, with
fractional positioning so nothing falls off a narrow phone. It is still
Flutter vector painting. The promo image was **not** bundled: it is a 1536px
landscape render, and shipping it would cost megabytes, blur on tall phones,
and undo the offline-first install size. The painting reads as the same world
at any density.

## Four decisions worth reviewing

**1. The Parents tab was removed.**
The 3.0 prototype put a child-progress dashboard in the child's bottom bar with
no gate at all. That is not shippable under Play Families expectations, and a
performance dashboard is not something to hand a four-year-old between two
games. The fourth slot is now **Rewards**. The grown-up door is the cog in the
HUD, behind the unchanged 2.0 birth-year gate. The store listing already
describes a gated dashboard, so this keeps the listing truthful.

**2. HUD counters read stored progress.**
3.0 hard-coded `stars = 12`, stickers `7`, chest `2`. `ProgressRepository`
gained `gardenStats()`, implemented in the sqflite repository against tables
that already existed: `SUM(stars_earned)` over finished sessions, and a count
of mastered graphemes. Unfinished sessions are excluded, so a chest cannot be
earned by opening the app and walking away.

Stickers are derived (one per two sounds grown) rather than stored, so the
sticker wall can only move when real mastery moves. Hearts are framed as
today's remaining energy, never as lives that run out — nothing in this app
punishes a child for playing.

**3. Zone taps bias the daily path, they do not replace it.**
`SessionScreen` gained an optional `focusMode`. It moves matching activities to
the front and leaves the rest of the planned path behind them. Two rules are
deliberate: the easy win stays last, because a session that ends on something
hard is the one a child does not come back to; and if nothing in today's path
matches the tapped zone, the path is returned untouched rather than emptied.
Tapping a place on the map can never produce an empty session.

**4. The Story tab reads the real catalog.**
3.0 shipped a hard-coded five-line story with a read-aloud button wired to an
empty callback. Beyond the dead button, the text was never checked against what
the child had been taught — and `sun` needs /u/, which the curriculum
introduces well after that screen would have appeared. The shelf now gates each
story on `MiniStory.isAvailable(taught)` and speaks through the existing
`SpeechService` seam.

---

## Two pre-existing issues found while merging

**`test/parent_data_deletion_control_test.dart` was already failing.** It
asserts on the strings `'Continue your adventure'` and `"Today's Adventure"`.
Neither string exists anywhere in the 2.0 home screen. The test has been
rewired to drive `AdventureShell` and assert on widget types instead of copy,
which is less brittle, but the original breakage predates this merge.

**Three ambient animations never actually respected reduce-motion.**
`AdventureWorld`, `AnilGuide` and the treasure chest called
`.repeat(reverse: true)` unconditionally and only zeroed the *offset* when
`disableAnimations` was set. The ticker kept requesting a frame every vsync —
burning battery for exactly the users who asked for less motion, and making
`pumpAndSettle` unreachable in widget tests. All three now stop the ticker
itself in `didChangeDependencies`.

---

## Open: which Anil ships?

`lib/app/theme.dart` documents Anil as a three-striped palm squirrel, and
`lib/presentation/shared/guide.dart` paints one. The 3.0 promo art shows Anil
as a boy in a yellow shirt with a name badge.

The squirrel was kept, because it is what the existing code, the design
rationale and the store copy are built around. **This means the feature graphic
currently advertises a character the app does not contain.** Resolve before
uploading — either repaint `_AnilPainter`, or regenerate the store art.

## Also open

- `lib/presentation/shared/reward_world.dart` (`StickerBurst`) is now unused.
  It appears to have been unused in 2.0 as well. Keep it for the celebration
  moment or delete it — it is a one-shot animation, so it costs nothing idle.
- `pubspec.yaml` version bumped `0.1.0+1` → `3.0.0+1`. Confirm before your
  first upload: Play will not accept a lower `versionCode` afterwards.
- Screenshot list in `release/store-listing-en.md` still names 2.0 screens.
  The new Garden, Rewards and Story tabs are worth capturing.
