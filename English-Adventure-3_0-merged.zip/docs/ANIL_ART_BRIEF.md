# Anil — character and promo art brief

For regenerating the English Adventure 3.0 promo graphic and character assets.
Everything here is taken from the shipping code, not invented: colours are the
literal values in `lib/app/theme.dart`, and the character description is the
one the app has been built around since 2.0.

**The single correction driving this brief:** the current promo graphic shows
Anil as a human boy in a yellow shirt with an `ANIL` name badge. The app does
not contain that character. Anil is a squirrel, in ~10 files of code and in the
store listing. The art needs to match the app, not the other way round.

---

## 1. Who Anil is

**A three-striped Indian palm squirrel.** Small, warm, a bit round. Not an owl,
not a fox, not a cartoon child.

The choice is deliberate and worth preserving: the animal was picked over the
default owl/fox mascot because a child in South India should recognise it from
her own courtyard. A generic mascot loses the entire point.

### Defining features — these must survive any restyling

| Feature | Detail |
| --- | --- |
| Three pale stripes | Along the back. This is the recognisable feature. Three, not two, not four. |
| Fur | Warm mid-brown, `#9A6548` |
| Belly | Pale cream, `#F4D3A8` |
| Stripes | Pale wheat, `#F8E8C6` |
| Tail | Curled and bushy, roughly body-height |
| Ears | Two small pointed tufts |
| Face | Two round dark eyes, small nose, simple smile. No eyebrows, no teeth. |
| Scarf | Hibiscus red, `#D3455B` — **the only** place this colour appears in the whole product |

The scarf rule matters: hibiscus is reserved for Anil alone and is never used
as an error or warning colour anywhere in the app. Don't spend it on flowers,
buttons or background elements in the artwork either.

### Tone

Encouraging, never instructing. Anil is a companion on the path, not a teacher
at the front. He is never disappointed, never surprised at a wrong answer,
never waiting impatiently. If a pose reads as "hurry up" or "not quite", it's
the wrong pose.

---

## 2. Palette

Two palettes, and they do different jobs. Do not mix them.

### Reading surfaces — accessibility decisions wearing an aesthetic coat

| Role | Hex |
| --- | --- |
| Paper (background) | `#F7EFE2` |
| Paper deep (wells) | `#EDE0CB` |
| Ink (body text) | `#33241A` |
| Ink soft (secondary) | `#6B5847` |

Warm oat rather than white, bark brown rather than black. Both avoid the glare
and visual crowding that pure white/black cause for readers with dyslexia-like
difficulties. **Never put letters, words or sentences on a bright saturated
background** in any asset — that undoes the decision.

### World / map / HUD — bright, saturated, looked at rather than read

| Role | Hex |
| --- | --- |
| Sky top → bottom | `#7EC8F2` → `#BFE7F7` |
| Grass | `#7FC24E` |
| Grass deep | `#4E9B3C` |
| Trail | `#E3C88A` |
| Trail edge | `#C9A868` |
| Leaf green (growth, "you did it") | `#2F7D4F` |
| Leaf light | `#BFE0CB` |
| Marigold (stars, reward) | `#F2A63B` |
| Chest gold | `#FFC93C` |
| Chest gold deep | `#D79A16` |
| Berry (hearts, celebration) | `#D66A78` |
| Sky blue (audio affordances) | `#7FB6D9` |
| Zone label green | `#3E7D34` |
| Locked grey | `#C7CDBE` |

Sky blue means "listen" throughout the app. Don't use it decoratively on
something that isn't an audio control.

---

## 3. Poses needed

Six, reusable across the store assets and future in-app illustration:

1. **Waving hello** — the greeting pose, used with the speech bubble
2. **Pointing at something** — for directing attention to a zone or a letter
3. **Cheering** — arms up, celebration after a finished activity
4. **Listening** — head tilted, one paw near ear (pairs with audio moments)
5. **Sitting calmly** — the idle/resting pose
6. **Holding a star** — for reward and treasure moments

All six at the same scale and line weight so they're interchangeable.

---

## 4. The feature graphic

Everything in the existing graphic **except the character** already matches the
merged build. Keep:

- The six zone names, exactly as worded: Phonics Garden, Word Forest, Writing
  World, Story Tree, Treasure Chest, Sticker Shop
- The star / sticker / heart HUD strip across the top
- The six feature rows down the right
- The bottom badge strip: Kid Friendly, No Ads, Works Offline, Safe & Secure,
  For Ages 4+

### Changes required

**Replace the boy with the squirrel** in two places: the waving character at
lower-left, and the small avatar in the Parent Dashboard panel.

**Drop the `ANIL` name badge.** It was lettering on the boy's shirt. A squirrel
doesn't wear one, and the speech bubble already introduces him.

**Move or de-emphasise the Parent Dashboard panel.** It currently sits
alongside the child-facing cards as though it's another room in the app. It's
behind a birth-year gate. Showing it as a peer of Phonics Garden oversells it
as a child-visible screen.

**Fix the age range.** The graphic says *For Ages 4+*; `store-listing-en.md`
says the app is made for children aged 5 to 9. Pick one and make the listing,
the graphic and the Play content-rating answers agree — a mismatch here is the
kind of thing that gets flagged in a Families review.

### Speech bubble copy

Use the line the app actually shows on first run:

> Hi! I'm Anil. Let's learn together!

---

## 5. Other assets in the release kit

| Asset | Spec | Note |
| --- | --- | --- |
| App icon | 512×512 PNG, 32-bit, no alpha | Anil's **face** on a leaf-green circle. Must stay legible at 48dp — a full-body squirrel will turn to mush at that size. |
| Feature graphic | 1024×500 PNG/JPG, no alpha | No text smaller than 24pt. |
| Phone screenshots | 2–8, min 1080px short side | Capture the new Garden, Rewards and Story tabs alongside the games. |

**Never put a real child's face or real name in any screenshot.**

---

## 6. Anti-brief — what this is not

- No leaderboards, scores, percentages or streak counters in any artwork. The
  app deliberately has none, and the graphic shouldn't imply otherwise.
- No sad, crying or disappointed Anil. There is no failure state to illustrate.
- No timers, countdowns or urgency cues.
- No coins, gems or anything that reads as purchasable currency. The app has no
  IAP and the listing says so.
- No hibiscus red on anything except Anil's scarf.
