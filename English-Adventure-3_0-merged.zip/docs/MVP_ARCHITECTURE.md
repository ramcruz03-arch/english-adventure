# English Adventure — MVP Architecture & Implementation Contract

## Decision

Flutter/Dart remains the only application framework. The supplied project is already a working vertical slice, so the MVP is an incremental upgrade rather than a rewrite.

## Child experience

`Home → Daily Adventure → 3–5 short activities → Reward Room`

The MVP priority order is:
1. Letter sounds
2. Sound matching
3. CVC blending / Word Builder
4. Trace & Write
5. One short illustrated story + picture comprehension
6. Parent progress dashboard

## Layers

- **Presentation:** screens, animations, child-safe interaction patterns.
- **Domain:** phonics rules, mastery, adaptive path, activity contracts.
- **Data:** JSON content, SQLite progress, optional future sync queue.
- **Core:** speech, accessibility, praise, safety helpers.

## Pedagogical invariants

1. A decodable word is only shown when every required grapheme has been taught.
2. At most one new grapheme is introduced per daily session.
3. A difficult session suppresses new material until confidence recovers.
4. One error receives a hint; repeated difficulty receives a demonstration and lower difficulty.
5. Speed never reduces mastery.
6. Finishing an activity earns the reward; correctness is not used as punishment.
7. Stories must declare prerequisite graphemes and remain decodable except for explicitly marked sight words.

## Offline-first contract

The child experience must work without connectivity. Content is bundled; progress is SQLite-backed. The existing `sync_queue` is reserved for an opt-in parent cloud-sync implementation and must not block local learning.

## Audio contract

`SpeechService` is the only child-facing speech entry point. MVP uses TTS with explicit phoneme fallback strings. Recorded native voices can later replace the implementation without changing game screens.

## Accessibility contract

- Andika for child reading content.
- Adjustable text size, letter spacing, line height and reduced motion.
- Large touch targets.
- Replay on all important audio.
- No timer, lives, leaderboard, failure screen or negative wording.

## MVP content contract

Lessons are stored separately from UI. The included `assets/content/lessons/mvp_lessons.json` is an editable seed pack describing the first ten lessons. Future lesson packs can be added without changing game logic.

## Release gate

The project is not considered store-ready until it has been exercised on real low/mid-range Android and iOS hardware, offline, with TTS in release mode, and observed with at least five children in the target age range. The existing release checklist remains the source of truth for final store submission.
