import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/audio/audio_service.dart';
import '../../providers/providers.dart';

class StoryScreen extends ConsumerStatefulWidget {
  const StoryScreen({super.key});
  @override
  ConsumerState<StoryScreen> createState() => _StoryScreenState();
}

class _StoryScreenState extends ConsumerState<StoryScreen> {
  int story = 0;
  int sentence = 0;

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(storiesProvider);
    return async.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (_, __) => const Center(child: Text('Story time is getting ready.')),
      data: (items) {
        final s = items[story.clamp(0, items.length - 1).toInt()];
        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Center(child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: Column(children: [
              Text(s.title, style: const TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text(s.level, style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 20),
              Card(child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(children: [
                  const Text('📖', style: TextStyle(fontSize: 58)),
                  for (var i = 0; i < s.sentences.length; i++) Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    child: Text(
                      s.sentences[i],
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 22, height: 1.35, fontWeight: i == sentence ? FontWeight.w900 : FontWeight.w500),
                    ),
                  ),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    FilledButton.icon(
                      onPressed: () => ref.read(audioServiceProvider).speak(s.sentences[sentence]),
                      icon: const Icon(Icons.volume_up),
                      label: const Text('Hear'),
                    ),
                    const SizedBox(width: 10),
                    FilledButton.tonal(
                      onPressed: () => setState(() {
                        if (sentence < s.sentences.length - 1) {
                          sentence++;
                        } else {
                          sentence = 0;
                          story = (story + 1) % items.length;
                        }
                      }),
                      child: const Text('Next'),
                    ),
                  ]),
                ]),
              )),
              const SizedBox(height: 18),
              Card(color: const Color(0xFFFFF3C7), child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(children: [
                  Text(s.question, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  Wrap(spacing: 10, children: s.options.map((o) => ChoiceChip(label: Text(o), selected: false, onSelected: (_) {})).toList()),
                ]),
              )),
            ]),
          )),
        );
      },
    );
  }
}
