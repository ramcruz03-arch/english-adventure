import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_tts/flutter_tts.dart';

final audioServiceProvider = Provider<AudioService>((ref) => AudioService());

class AudioService {
  final FlutterTts _tts = FlutterTts();
  bool _ready = false;

  Future<void> init() async {
    await _tts.setSpeechRate(0.42);
    await _tts.setPitch(1.05);
    await _tts.setVolume(1);
    _ready = true;
  }

  Future<void> speak(String text) async {
    if (!_ready) {
      await init();
    }
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stop() => _tts.stop();
  Future<void> setLanguage(String code) => _tts.setLanguage(code);
}
